package backend;

import java.util.List;

public class Vaccine {

    // Attributes -------------------------------------------------

    private int vaccineID;
    private String vaccineName;
    private String prodCompany;
    private String prodCountry;
    private String vaccineInfo;
    private VaccineDAO CRUDController;

    // Methods ----------------------------------------------------

    public Vaccine(){CRUDController = new VaccineDAO();}

    // Parametrized Constructor
    public Vaccine(int vaccineID, String vaccineName, String prodCompany, String prodCountry, String vaccineInfo) {
        this.vaccineID = vaccineID;
        this.vaccineName = vaccineName;
        this.prodCompany = prodCompany;
        this.prodCountry = prodCountry;
        this.vaccineInfo = vaccineInfo;
        CRUDController = new VaccineDAO();
    }

    // Getters & Setters
    public int getVaccineID() {
        return vaccineID;
    }

    public void setVaccineInfo(String vaccineInfo) {
        this.vaccineInfo = vaccineInfo;
    }

    public String getVaccineInfo() {
        return vaccineInfo;
    }

    public void setVaccineID(int vaccineID) {
        this.vaccineID = vaccineID;
    }

    public String getVaccineName() {
        return vaccineName;
    }

    public void setVaccineName(String vaccineName) {
        this.vaccineName = vaccineName;
    }

    public String getProdCompany() {
        return prodCompany;
    }

    public void setProdCompany(String prodCompany) {
        this.prodCompany = prodCompany;
    }

    public String getProdCountry() {
        return prodCountry;
    }

    public void setProdCountry(String prodCountry) {
        this.prodCountry = prodCountry;
    }

    // Other methods

    // This function gets the total list to display to at the combo box
    public List<String> getVaccineList(int vaccineeID){
        return CRUDController.create_VaccineList(vaccineeID);
    }

    public Vaccine getVaccine(int vaccineID){
        return CRUDController.gettingVaccine(vaccineID);
    }

    // This function gets the total list to display to at the combo box
    public List<String> getVaccineList(){
        return CRUDController.create_VaccineList();
    }
}
