package backend;
import java.util.ArrayList;
import java.util.List;

public class Center
{
    // Attributes ----------------------------------------------------------

    private int centerID;
    private String centerName;
    private String centerAddress;
    private int centerCapacity;
    private ArrayList<Appointment> appointments;
    private ArrayList<Appointment> missedAppointments;
    private ArrayList<HealthWorker> assignedHealthWorkers;
    private ArrayList<Vaccinee> attendedVaccinee;
    private CenterDAO CRUDController;

    // Methods -------------------------------------------------------------

    // Default Constructor
    public Center(){CRUDController = new CenterDAO();}

    // Parametrized Constructor
    public Center(int centerID, String centerName, String centerAddress, int centerCapacity)
    {
        this.centerID = centerID;
        this.centerName = centerName;
        this.centerAddress = centerAddress;
        this.centerCapacity = centerCapacity;

        appointments = new ArrayList<>();
        missedAppointments = new ArrayList<>();
        assignedHealthWorkers = new ArrayList<>();
        attendedVaccinee = new ArrayList<>();
    }

    // Setters -------

    public void setCenterID(int centerID) {
        this.centerID = centerID;
    }
    public void setCenterCapacity(int centerCapacity) {
        this.centerCapacity = centerCapacity;
    }
    public void setCenterName(String centerName) {
        this.centerName = centerName;
    }
    public void setCenterAddress(String centerAddress) {
        this.centerAddress = centerAddress;
    }
    // Implementation Methods ----------

    // This function gets the total list to display to at the combo box
    public List<String> getCenterList(){
        return CRUDController.create_CenterList();
    }

    public int getCenterID(){
        return centerID;
    }

    // getting a specific center of a healthworker
    public Center getCenter(int centerID){
        return CRUDController.gettingCenter(centerID);
    }

    // This function calls DAO to increment the center capacity
    public void UpdateCenterCapacity(int centerID){
        CRUDController.updateCenterCapacity(centerID);
    }

    // Getting the center line
    public String getCenterline(int centerID){
        return CRUDController.extractCenterLine(centerID);
    }

    public boolean logVisitedVaccinee(int vaccineeID, int centerID, int appointmentID){
        return CRUDController.addVisitedVaccinee(centerID, vaccineeID,appointmentID);
    }

    public void displayReservedAppointment() {
        // Code to display reserved appointments yuve made
    }

    public Appointment getAppointment(int appointmentID) {
        // Code to get an appointment by iDs
        return null;
    }

    public boolean checkAvailability(int appointmentID) {
        //  to check if an appointment is available atm
        return false;
    }

    public void displayWorkingHealthworkers() {
        //  to display working health workers
    }

    public void checkIn(int userID, int appointmentID) {
        //  to check in a user for an appointment
    }

    public boolean verifyAppointment(int userID, int appointmentID) {
        //  to verify an appointment for a user
        return false;
    }

    public void confirmSuccessfulVaccine(int userID) {
        //  to confirm successful vaccination for a user
    }
}
