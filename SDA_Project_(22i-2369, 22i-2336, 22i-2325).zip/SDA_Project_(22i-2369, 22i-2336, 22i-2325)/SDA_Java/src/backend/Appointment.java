package backend;
import java.util.Date;
import java.time.LocalTime;
import java.util.List;


public class Appointment
{
    // Attributes -----------------------------------------------------

    private int appointmentID;
    private Vaccine vaccine;
    private LocalTime startTime;
    private LocalTime endTime;
    private Center center;
    private boolean reserved;
    private Date appointmentDate;
    private AppointmentDAO CRUDController;

    // Methods --------------------------------------------------------

    public Appointment(){
        CRUDController = new AppointmentDAO();
    }

    // This is Constructor
    public Appointment(int appointmentID, Vaccine vaccine, LocalTime startTime, LocalTime endTime, Center center, boolean reserved, Date appointmentDate)
    {
        this.appointmentID = appointmentID;
        this.vaccine = vaccine;
        this.startTime = startTime;
        this.endTime = endTime;
        this.center = center;
        this.reserved = reserved;
        this.appointmentDate = appointmentDate;
        CRUDController = new AppointmentDAO();
    }

    // Getter and setter for each attribute

    public int getAppointmentID() {
        return appointmentID;
    }

    public void setAppointmentID(int appointmentID) {
        this.appointmentID = appointmentID;
    }

    public Vaccine getVaccine() {
        return vaccine;
    }

    public void setVaccine(Vaccine vaccine) {
        this.vaccine = vaccine;
    }

    public LocalTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalTime startTime) {
        this.startTime = startTime;
    }

    public LocalTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalTime endTime) {
        this.endTime = endTime;
    }

    public Center getCenter() {
        return center;
    }

    public void setCenter(Center center) {
        this.center = center;
    }

    public boolean isReserved() {
        return reserved;
    }

    public void setReserved(boolean reserved) {
        this.reserved = reserved;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(Date appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    // Implementation Method

    public List<application.Appointment> getAvaliableAppointments(Center center, int vaccineID) {
        // to display available appointment based on vaccineID
        return CRUDController.getAppointments(center,vaccineID);
    }

    public List<application.Appointment> getPersonalAppointments(int vaccineeID){
        return CRUDController.getAppointments(vaccineeID);
    }

    public boolean bookAppointment(){
        return CRUDController.bookingAppointment(this);
    }

    public boolean addBookedAppointment(Appointment apt, Vaccinee vaccinee){
        return CRUDController.addbookedAppointment(apt,vaccinee);
    }

    public Appointment getAppointment(int appointmentID)
    {
        // to return an appointment based on appointmentID
        return CRUDController.getAppointment(appointmentID);
    }

    public boolean checkAvailability(int appointmentID)
    {
        // to check if the appointment is available
        return false;
    }

    public void confirmAvailability(int appointmentID)
    {
        // to confirm the availability of the appointment
    }

    public void selectCancelAppointment(int appointmentID)
    {
        // to select and cancel the appointment
    }

    public void confirmCancellation(int appointmentID)
    {
        // to confirm the cancellation of the appointment
    }

    public boolean removeBookedAppointment (int appointmentID){
        return CRUDController.removeAppointment(appointmentID);
    }
}
