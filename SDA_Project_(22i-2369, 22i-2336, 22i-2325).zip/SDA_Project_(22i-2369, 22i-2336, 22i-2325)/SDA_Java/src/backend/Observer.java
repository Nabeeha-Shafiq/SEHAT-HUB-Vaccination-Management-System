package backend;

public interface Observer {
	String pullSystemNotification();
}
