package backend;
import application.Appointment;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AppointmentDAO {

    // Connection Strings here! ---------------------------

    // This is Wania's
    protected static final String JDBC_URL = "jdbc:sqlserver://ENVIOUS\\SQLEXPRESS:1433;databaseName=VaccinationSystem;integratedSecurity=true;encrypt=true;trustServerCertificate=true";
    // This is Emaan's

    // This is Nabeeha's (bebo)
    // protected static final String JDBC_URL = "jdbc:sqlserver://DESKTOP-J49GPGC\\SQLEXPRESS;databaseName=VaccinationSystem;integratedSecurity=true;encrypt=false;";

    // -------------------------------------------------------------------------

    public AppointmentDAO(){}

    public List<Appointment> getAppointments(Center center, int vaccineID){

        Connection connection = null;
        List<Appointment> app_list = new ArrayList<>();

        if(vaccineID == 0){

            try{
                connection = DriverManager.getConnection(JDBC_URL);

                String query = "select A.appointmentID, A.startTime, A.reserved, A.appointmentDate from Appointment A inner join Vaccinee_pendingAppointment VPA on A.appointmentID = VPA.appointmentID where centerID = ?";

                PreparedStatement execute_query = connection.prepareStatement(query);

                execute_query.setInt(1,center.getCenterID());

                ResultSet result = execute_query.executeQuery();

                while (result.next()) {

                    if (result.getBoolean("reserved") == true) {
                        Appointment temp = new Appointment(result.getInt("appointmentID"), String.valueOf(result.getDate("appointmentDate")), String.valueOf(result.getTime("startTime")), "Booked");
                        app_list.add(temp);
                    } else {
                        Appointment temp = new Appointment(result.getInt("appointmentID"), String.valueOf(result.getDate("appointmentDate")), String.valueOf(result.getTime("startTime")), "Available");
                        app_list.add(temp);
                    }

                }

            }catch (SQLException e){
                e.printStackTrace();
            }

        }else {

            try {
                connection = DriverManager.getConnection(JDBC_URL);

                String query = "select appointmentID, startTime, reserved, appointmentDate from Appointment where vaccineID = ? and centerID = ?;";

                PreparedStatement execute_query = connection.prepareStatement(query);

                execute_query.setInt(1, vaccineID);
                execute_query.setInt(2, center.getCenterID());

                ResultSet result = execute_query.executeQuery();

                while (result.next()) {

                    if (result.getBoolean("reserved") == true) {
                        Appointment temp = new Appointment(result.getInt("appointmentID"), String.valueOf(result.getDate("appointmentDate")), String.valueOf(result.getTime("startTime")), "Booked");
                        app_list.add(temp);
                    } else {
                        Appointment temp = new Appointment(result.getInt("appointmentID"), String.valueOf(result.getDate("appointmentDate")), String.valueOf(result.getTime("startTime")), "Available");
                        app_list.add(temp);
                    }

                }

            } catch (SQLException e) {
                e.printStackTrace();
            }

        }

        return app_list;
    }


    // update the now booked appointment
    public boolean bookingAppointment(backend.Appointment apt){

        Connection connection = null;
        boolean booked = true;

        try{
            connection = DriverManager.getConnection(JDBC_URL);

            String query = "update Appointment set reserved = 1 where appointmentID = ?";

            PreparedStatement execute_query = connection.prepareStatement(query);

            execute_query.setInt(1,apt.getAppointmentID());

            execute_query.executeUpdate();


        }catch (SQLException e){
            e.printStackTrace();
        }
        return booked;
    }

    public boolean addbookedAppointment(backend.Appointment apt, Vaccinee vaccinee){

        Connection connection = null;
        boolean booked = true;

        try{
            connection = DriverManager.getConnection(JDBC_URL);

            String query = "insert into Vaccinee_pendingAppointment values (?,?);";

            PreparedStatement execute_query = connection.prepareStatement(query);

            execute_query.setInt(1,vaccinee.userID);
            execute_query.setInt(2,apt.getAppointmentID());

            execute_query.executeUpdate();


        }catch (SQLException e){
            e.printStackTrace();
        }
        return booked;
    }

    // getting appointment based on appointment ID
    public backend.Appointment getAppointment(int appointmentID){

        Connection connection = null;
        backend.Appointment appt = new backend.Appointment();

        try{
            connection = DriverManager.getConnection(JDBC_URL);

            String query = "select * from Appointment where appointmentID = ?";

            PreparedStatement execute_query = connection.prepareStatement(query);

            execute_query.setInt(1,appointmentID);

            ResultSet result = execute_query.executeQuery();

            while(result.next()){

                appt.setAppointmentID(result.getInt("appointmentID"));
                appt.setAppointmentDate(result.getDate("appointmentDate"));
                appt.setStartTime(result.getTime("startTime").toLocalTime());
                appt.setEndTime(result.getTime("endTime").toLocalTime());
                appt.setReserved(result.getBoolean("reserved"));
                break;
            }

        }catch (SQLException e){
            e.printStackTrace();
        }

        return appt;
    }

    public List<Appointment> getAppointments(int vaccineeID){

        Connection connection = null;
        List<Appointment> appointList = new ArrayList<>();

        try{
            connection = DriverManager.getConnection(JDBC_URL);

            String query = "select * from Appointment inner join Vaccinee_pendingAppointment VPA on Appointment.appointmentID = VPA.appointmentID where vaccineeID = ?";

            PreparedStatement execute_query = connection.prepareStatement(query);

            execute_query.setInt(1,vaccineeID);

            ResultSet result = execute_query.executeQuery();

            while(result.next()){
                Appointment temp = new Appointment();
                temp.setAppointmentID(result.getInt("appointmentID"));
                temp.setDate(String.valueOf(result.getDate("appointmentDate")));
                temp.setTime(String.valueOf(result.getTime("startTime").toLocalTime()));
                temp.setAvailability("Booked");
                appointList.add(temp);
            }

        }catch (SQLException e){
            e.printStackTrace();
        }

        return appointList;
    }

    public boolean removeAppointment(int appointmentID){

        Connection connection = null;
        boolean removed = true;

        try{
            connection = DriverManager.getConnection(JDBC_URL);

            String query = "update Appointment set reserved = 0 where appointmentID = ?";
            String query1 = "delete from Vaccinee_pendingAppointment where appointmentID = ?";

            PreparedStatement execute_query1 = connection.prepareStatement(query1);
            PreparedStatement execute_query = connection.prepareStatement(query);

            execute_query.setInt(1,appointmentID);
            execute_query.executeUpdate();

            execute_query1.setInt(1,appointmentID);
            execute_query1.executeUpdate();

        }catch (SQLException e){
            e.printStackTrace();
        }
        return removed;

    }
}
