package backend;
import application.UserData;

import java.util.ArrayList;
import java.util.List;
import application.ReportData;

// Ministry of Health (Pakistan)

public class MOH {

    // Attributes ------------------------------------------------

    private ArrayList<HealthWorker> registeredHealthWorkers;
    private ArrayList<Vaccine> vaccineObject ;
    private ArrayList<Vaccinee> registeredVaccinee;
    private ArrayList<Center> registeredCenters;
    private MinistryOfHealthDAO objDB = new MinistryOfHealthDAO();

    // Methods ---------------------------------------------------

    // Parametrized Constructor
    public MOH(ArrayList<HealthWorker> registeredHealthWorkers, ArrayList<Vaccine> vaccineObject, ArrayList<Vaccinee> registeredVaccinee, ArrayList<Center> registeredCenters) {
        this.registeredHealthWorkers = registeredHealthWorkers;
        this.vaccineObject = vaccineObject;
        this.registeredVaccinee = registeredVaccinee;
        this.registeredCenters = registeredCenters;
    }

    public MOH() {}

    // Getter & Setters
    public ArrayList<HealthWorker> getRegisteredHealthWorkers() {
        return registeredHealthWorkers;
    }

    public ArrayList<Vaccine> getVaccineObject() {
        return vaccineObject;
    }

    public ArrayList<Vaccinee> getRegisteredVaccinee() {
        return registeredVaccinee;
    }

    public ArrayList<Center> getRegisteredCenters() {
        return registeredCenters;
    }

    public void setRegisteredHealthWorkers(ArrayList<HealthWorker> registeredHealthWorkers) {
        this.registeredHealthWorkers = registeredHealthWorkers;
    }

    public void setVaccineObject(ArrayList<Vaccine> vaccineObject) {
        this.vaccineObject = vaccineObject;
    }

    public void setRegisteredVaccinee(ArrayList<Vaccinee> registeredVaccinee) {
        this.registeredVaccinee = registeredVaccinee;
    }

    public void setRegisteredCenters(ArrayList<Center> registeredCenters) {
        this.registeredCenters = registeredCenters;
    }

    public void pushSystemNotification(String message) {
        objDB.pushSystemNotification(message);
    }
    //report displayUnvaccinatedReports(filter) //this function would diplay Reports related to vaccinations in our system , sorted/filtered geographically , population wise , gender wise etc
    public ArrayList<ReportData> generateReport() {
        return objDB.fetchReportData();
    }


    public List<UserData> getVaccineSideEffects() {
        MinistryOfHealthDAO dao=new MinistryOfHealthDAO();
        return dao.fetchVaccineSideEffects();
    }

//report displayUnvaccinatedReports(filter) //this function would diplay Reports related to vaccinations in our system , sorted/filtered geographically , population wise , gender wise etc
}
