package backend;
import application.VaccineCenterData;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class HealthWorker extends User implements Observer{

    // Attributes ----------------------------------------------
    protected int centerID;
    protected String licenseNumber;
    private HealthworkerDAO CRUDcontroller;

    // Methods -------------------------------------------------

    // default constructor
    public HealthWorker(){ CRUDcontroller = new HealthworkerDAO(); }

    // parametrized constructor
    public HealthWorker(String userUsername, String userPassword, String userFName, String userLName, LocalDate userDOB, String userGender, String userPhone, String licenseNumber, String userEmail, int centerID){
        super(userUsername, userPassword, userFName,userLName,userDOB,userGender,userPhone, userEmail);
        this.licenseNumber = licenseNumber;
        this.centerID = centerID;
        CRUDcontroller = new HealthworkerDAO();
    }

    // call the HealthworkerDAO for CRUD operations -------

    // GETTERS ---
    public String getLicenseNumber() {
        return licenseNumber;
    }

    public int getCenterID() {
        return centerID;
    }

    // SETTERS --

    public void setFirstName(String fName) {
        this.userFName=fName;

    }

    public void setLastName(String lName) {
        this.userLName=lName;

    }

    public void setDob(LocalDate dob) {
        this.userDOB=dob;
    }

    public void setGender(String gender) {
        this.userGender=gender;

    }

    public void setPhone(String phone) {
        this.userPhone=phone;

    }

    public void setLicenseNumber(String licenseNo) {
        this.licenseNumber=licenseNo;

    }

    public void setCenterID(int centerId2) {
        this.centerID=centerId2;
    }

    // create Healthworker
    public boolean registerUser(User newuser){
        HealthWorker healthworker = (HealthWorker) newuser;
        return CRUDcontroller.createUser(healthworker);
    }

    // update Healthworker
    public boolean updateUser(User newuser){
        HealthWorker healthworker = (HealthWorker) newuser;
        return CRUDcontroller.updatingHealthworker(healthworker);
    }

    // delete Healthworker
    public boolean deleteUser(User newuser){
        HealthWorker healthworker = (HealthWorker) newuser;
        return CRUDcontroller.deletingHealthworker(healthworker);
    }

    // Check for unique username
    public boolean checkUsername(String userUsername){
        // 1 means that username is correct to use and 0 means that username is taken
        return CRUDcontroller.UsernameChecker(userUsername);
    }

    // this function is called for addition/ update
    public boolean[] validateUser(User newuser, int functionNum){

        HealthWorker newhealthworker = (HealthWorker) newuser;

        boolean result[] = {true,true,true,true,true,true,true,true,true,true,true};

        // Regexs for checking
        String regex_name = "^[a-zA-Z\\s]+$";
        String regex_name_num = "^[a-zA-Z0-9\\s]+$";
        String regex_phone = "^\\d{10}$";
        String regex_password = "^[a-zA-Z0-9!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?`~]{5,}$";
        String regex_email = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,6}$";
        String regex_license = "^\\d{10}$";

        if (!newhealthworker.userFName.matches(regex_name)){
            result[0] = false; // First Name is wrong
        }
        if(!newhealthworker.userLName.matches(regex_name)){
            result[1] = false; // Second Name is wrong
        }
        if(!newhealthworker.userUsername.matches(regex_name_num)){
            result[2] = false; // Username is wrong
        }
        if(functionNum == 1) {
            if (!newhealthworker.checkUsername(userUsername)) {
                result[10] = false; // Username is taken
            }
        }
        if(newhealthworker.userGender == null){
            result[3] = false; // Gender is wrong
        }
        if(!newhealthworker.userPhone.matches(regex_phone)){
            result[4] = false; // Phone number is wrong
        }
        if(newhealthworker.userDOB == null || newuser.userDOB.plusYears(18).isAfter(LocalDate.now())){
            result[5] = false; // date of birth is wrong
        }
        if(!newhealthworker.userPassword.matches(regex_password)){
            result[6] = false; // Password format is wrong
        }
        if(!newhealthworker.userEmail.matches(regex_email)){
            result[7] = false; // Email Format is wrong
        }
        if(!newhealthworker.licenseNumber.matches(regex_license)){
            result[8] = false; // License number is wrong
        }
        if(newhealthworker.centerID == 0){
            result[9] = false; // Center is not assigned
        }

        return result;
    }

    // validate Healthworker for login
    public int validateUser(String username, String password){

        // retrieve the username and password from the database here!
        String checkpassword = null;
        checkpassword = CRUDcontroller.getUsernamePassword(username);

        if (Objects.equals(checkpassword, password)){
            return 3;
        } else if (checkpassword == null) {
            return 2; // Healthworker does not exist
        }else{
            return 1; // Incorrect Password written
        }
    }

    // returning the object of healthworker
    public HealthWorker gethealthworker(String username){
        // call the DAO to get the Healthworker based on unique username
        return CRUDcontroller.getHealthworker(username);
    }

    @Override
    public String pullSystemNotification() {
        return CRUDcontroller.pullSystemNotification();
    }

    public List<VaccineCenterData> getVaccinationData() {
        //NNNNNNNNNNNNNNNNNNN
        //CRUDcontroller=new HealthworkerDAO();
        //int HealthWorkerID=1;

        return CRUDcontroller.fetchVaccinationDataForHealthWorker(this.userID);
    }
}
