package backend;
import application.Descendant;
import application.VaccineeData;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.sql.SQLException;

public class Vaccinee extends User implements Observer{

    // Attributes -----------------------------------------------

    private ArrayList<Vaccinee> children;
    private ArrayList<Vaccine> vaccineSchedule;
    private ArrayList<Vaccine> rejectedVaccine;
    private ArrayList<Appointment> pendingAppointment;
    private ArrayList<Appointment> completedAppointment;
    private ArrayList<Appointment> missedAppointment;
    private VaccineeDAO CRUDcontroller;

    // Methods --------------------------------------------------

    // default constructor
    public Vaccinee() throws SQLException{
        CRUDcontroller = new VaccineeDAO();
    }

    // parametrized constructor
    public Vaccinee(String userUsername, String userPassword, String userFName, String userLName, LocalDate userDOB, String userGender, String userPhone, String userEmail) throws SQLException {
        super(userUsername, userPassword, userFName,userLName,userDOB,userGender,userPhone, userEmail);
        CRUDcontroller = new VaccineeDAO();
    }

    public int getVaccineeID()
    {
        System.out.print("Vaccinee id : "+getUserID());
        return getUserID();
    }

    // call the VaccineeDAO for the CRUD Operations!! -----

    // create Vaccinee
    public boolean registerUser(User newuser){
        Vaccinee vacc = (Vaccinee) newuser;
        return CRUDcontroller.createUser(vacc);
    }

    // add children in this
    public boolean addchild(Vaccinee vaccinee){
        return CRUDcontroller.addingchild(this,vaccinee);
    }

    // update Vaccinee
    public boolean updateUser(User newuser){
        Vaccinee vacc = (Vaccinee) newuser;
        return CRUDcontroller.updatingVaccinee(vacc);
    }

    // delete Vaccinee
    public boolean deleteUser(User newuser){
        Vaccinee vacc = (Vaccinee) newuser;
        return CRUDcontroller.deletingVaccinee(vacc);
    }

    // Check for unique username
    public boolean checkUsername(String userUsername){
        // 1 means that username is correct to use and 0 means that username is taken
        return CRUDcontroller.UsernameChecker(userUsername);
    }

    // validate Vaccinee for addition / updation
    public boolean[] validateUser(User newuser, int functionNum){

        Vaccinee newvaccinee = (Vaccinee) newuser;

        boolean result[] = {true,true,true,true,true,true,true,true,true};

        // Regexs for checking
        String regex_name = "^[a-zA-Z\\s]+$";
        String regex_name_num = "^[a-zA-Z0-9\\s]+$";
        String regex_phone = "^\\d{10}$";
        String regex_password = "^[a-zA-Z0-9!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?`~]{5,}$";
        String regex_email = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,6}$";

        if (!newvaccinee.userFName.matches(regex_name)){
            result[0] = false; // First Name is wrong
        }
        if(!newvaccinee.userLName.matches(regex_name)){
            result[1] = false; // Second Name is wrong
        }
        if(!newvaccinee.userUsername.matches(regex_name_num)){
            result[2] = false; // Username is wrong
        }
        if(functionNum == 1 || functionNum == 3){
            if(!newvaccinee.checkUsername(userUsername)){
            result[8] = false; // Username is taken
            }
        }
        if(newvaccinee.userGender == null){
            result[3] = false; // Gender is wrong
        }
        if(!newvaccinee.userPhone.matches(regex_phone)){
            result[4] = false; // Phone number is wrong
        }
        if(functionNum == 3){
            if(newvaccinee.userDOB == null || newuser.userDOB.isAfter(LocalDate.now())){
                result[5] = false; // date of birth is wrong
            }
        }else{
            if(newvaccinee.userDOB == null || newuser.userDOB.plusYears(18).isAfter(LocalDate.now())){
                result[5] = false; // date of birth is wrong
            }
        }
        if(!newvaccinee.userPassword.matches(regex_password)){
            result[6] = false; // Password format is wrong
        }
        if(!newvaccinee.userEmail.matches(regex_email)){
            result[7] = false; // Email Format is wrong
        }
        return result;
    }

    // getting children from DAO
    public List<Descendant> getchildren(){
        return CRUDcontroller.gettingChildren(this);
    }

    // checking for children
    public boolean checkChild(){
        return CRUDcontroller.checkingChildren(this);
    }

    // validate Vaccinee for login
    public int validateUser(String username, String password){

        // retrieve the username and password from the database here!
        String checkpassword = null;
        checkpassword = CRUDcontroller.getUsernamePassword(username);
        
        if (Objects.equals(checkpassword, password)){
            return 3;
        } else if (checkpassword == null) {
            return 2; // Vaccinee does not exist
        }else{
            return 1; // Incorrect Password written
        }
    }

    public static List<Vaccine> getDueVaccines(int vaccineeId) {
        return VaccineeDAO.getDueVaccines(vaccineeId);
    }

    public static List<Appointment> getDueAppointments(int vaccineeId) {
        return VaccineeDAO.getDueAppointments(vaccineeId);
    }

    @Override
    public String pullSystemNotification() {
        return CRUDcontroller.pullSystemNotification();
    }

    public Map<String, int[]> getVaccinationProgress(int vaccineeID) throws Exception {
        return CRUDcontroller.fetchVaccinationProgress(vaccineeID);
    }

    public String generateVaccinationReport(int vaccineeID) throws Exception {
        Map<String, int[]> progressData = getVaccinationProgress(vaccineeID);
        StringBuilder report = new StringBuilder("Vaccination Progress Report:\n");

        for (Map.Entry<String, int[]> entry : progressData.entrySet()) {
            String vaccineName = entry.getKey();
            int dosesDone = entry.getValue()[0];
            int dosesPending = entry.getValue()[1];
            int totalDoses = dosesDone + dosesPending;

            report.append(String.format("""
                - %s:
                  * Doses Completed: %d
                  * Doses Pending: %d
                  * Total Doses: %d
                """, vaccineName, dosesDone, dosesPending, totalDoses));
        }
        return report.toString();
    }

    public List<String> getVaccines() {
        return CRUDcontroller.getVaccines();
    }

    public List<String> getSymptoms() {
        return CRUDcontroller.getSymptoms();
    }

    public List<String> getCenters() {
        return CRUDcontroller.getCenters();
    }

    public void reportSideEffect(int vaccineID, int vaccineeID, String symptom, String additionalDetails) {
        CRUDcontroller.insertSideEffect(vaccineID, vaccineeID, symptom, additionalDetails);
    }

    // returning the object of vaccinee
    public Vaccinee getvaccinee(String username) throws SQLException {
        // call the DAO to get the Vaccinee based on unique username
        return CRUDcontroller.getVaccinee(username);
    }

    // returning the object of vaccinee
    public Vaccinee getvaccinee(int vaccineeID) throws SQLException {
        // call the DAO to get the Vaccinee based on vaccinee ID
        return CRUDcontroller.getVaccinee(vaccineeID);
    }

    public List<String> gettingVaccineeList(){
        return CRUDcontroller.gettingMissedVaccinee();
    }

    public List<VaccineeData> gettingVaccineeDataList(int centerID, int vaccineID){
        return CRUDcontroller.extractingDailyAppointments(centerID,vaccineID);
    }

    public boolean markCompletedAppointment (int appointmentID, int vaccineeID){
        return CRUDcontroller.makeCompletedAppointment(appointmentID, vaccineeID);
    }

    public boolean updateDose(int vaccineeID, int vaccineID){
        return CRUDcontroller.UpdateDose(vaccineeID, vaccineID);
    }

    public boolean removeMissedAppointment(int centerID, int vaccineID){
        return CRUDcontroller.filterAppointments(centerID, vaccineID);
    }

    public int gettingVaccineefromAppointment(int appointmentID){
        return CRUDcontroller.getVaccineeAppointment(appointmentID);
    }

    public boolean addchildSchedule(Vaccinee vaccinee){
        return CRUDcontroller.AddChildSchedule(vaccinee);
    }

}
