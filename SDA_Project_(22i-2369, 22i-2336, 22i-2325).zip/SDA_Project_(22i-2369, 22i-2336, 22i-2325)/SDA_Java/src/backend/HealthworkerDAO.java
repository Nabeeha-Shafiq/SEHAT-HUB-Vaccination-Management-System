package backend;
import application.VaccineCenterData;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static java.sql.DriverManager.getConnection;

public class HealthworkerDAO implements Observer{

    // Connection Strings here! ---------------------------

    // This is Wania's
    protected static final String JDBC_URL = "jdbc:sqlserver://ENVIOUS\\SQLEXPRESS:1433;databaseName=VaccinationSystem;integratedSecurity=true;encrypt=true;trustServerCertificate=true";
    // This is Emaan's

    // This is Nabeeha's (bebo)
    // protected static final String JDBC_URL = "jdbc:sqlserver://DESKTOP-J49GPGC\\SQLEXPRESS;databaseName=VaccinationSystem;integratedSecurity=true;encrypt=false;";
    static Connection connectionNabs;
    // -------------------------------------------------------------------------

    // default constructor
    public HealthworkerDAO(){

        try {
            // Load SQL Server JDBC driver and establish a connection
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            connectionNabs = getConnection(JDBC_URL);

            // Check if the connection is successfully established
            if (connectionNabs != null) {
                System.out.println("Connected to SQL Server Successfully");
            }
        } catch (ClassNotFoundException e) {
            // This exception handles the case where the JDBC driver isn't found
            System.err.println("Could not load JDBC driver: " + e.getMessage());
            e.printStackTrace();
        } catch (SQLException e) {
            // This exception handles SQL errors during connection setup
            System.err.println("SQL Exception: " + e.getMessage());
            e.printStackTrace();
        }

    }

    // All the CRUD + DATABASE implementations of the Healthworker will be implemented here ------------------------

    // Nabeeha's Method
    public List<VaccineCenterData> fetchVaccinationDataForHealthWorker(int healthWorkerId) {
        List<VaccineCenterData> vaccinationData = new ArrayList<>();
        String query = """
            SELECT 
                c.centerName,
                v.vaccineeFName + ' ' + v.vaccineeLName AS VaccineeName,
                vac.vaccineName,
                vs.doses_done AS DosesCompleted,
                vs.doses_needed - vs.doses_done AS DosesDue
            FROM 
                Center c
            JOIN 
                Center_AttendedVaccinee cav ON c.centerID = cav.centerID
            JOIN 
                Vaccinee v ON cav.vaccineeID = v.vaccineeID
            JOIN 
                Vaccinee_VaccineSchedule vs ON v.vaccineeID = vs.vaccineeID
            JOIN
                Vaccine vac ON vs.vaccineID = vac.vaccineID
            WHERE 
                c.centerID = (SELECT centerID FROM HealthWorker WHERE healthworkerID = ?)
            ORDER BY 
                c.centerName, v.vaccineeFName, v.vaccineeLName;
        """;

        try (PreparedStatement stmt = connectionNabs.prepareStatement(query)) {
            stmt.setInt(1, healthWorkerId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String centerName = rs.getString("centerName");
                String vaccineeName = rs.getString("VaccineeName");
                String vaccineName = rs.getString("vaccineName");
                int dosesCompleted = rs.getInt("DosesCompleted");
                int dosesDue = rs.getInt("DosesDue");
                vaccinationData.add(new VaccineCenterData(centerName, vaccineeName, vaccineName, dosesCompleted, dosesDue));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return vaccinationData;
    }


    public boolean createUser(HealthWorker newhealthworker){

        // establishing connection here
        Connection connection = null;

        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            connection = getConnection(JDBC_URL);

            // checking the connection
            if (connection != null){
                System.out.println("\tConnected to SQL Server Successfully");
            }

            // get the latest entry for the Healthworker to get the Healthworker ID
            String query1 = "select MAX(healthworkerID) as maxHealthworkerID from HealthWorker";

            PreparedStatement execute_query1 = connection.prepareStatement(query1);
            ResultSet resultset = execute_query1.executeQuery();

            int maxHealthworkerID = 0;
            if(resultset.next()){
                maxHealthworkerID = resultset.getInt("maxHealthworkerID");
            }

            maxHealthworkerID++;

            resultset.close();
            execute_query1.close();

            // Now add the new entry into the table HealthWorker
            String query2 = "insert into HealthWorker values (?,?,?,?,?,?,?,?,?,?,?,?);";

            PreparedStatement execute_query2 = connection.prepareStatement(query2);

            execute_query2.setInt(1, maxHealthworkerID);
            execute_query2.setString(2,newhealthworker.userFName);
            execute_query2.setString(3, newhealthworker.userLName);
            execute_query2.setDate(4, Date.valueOf(newhealthworker.userDOB));
            execute_query2.setString(5, newhealthworker.userGender);
            execute_query2.setString(6, newhealthworker.userPhone);
            execute_query2.setString(7, newhealthworker.licenseNumber);
            execute_query2.setInt(8,newhealthworker.centerID);
            execute_query2.setString(9, newhealthworker.userUsername);
            execute_query2.setString(10,newhealthworker.userPassword);
            execute_query2.setString(11,newhealthworker.userEmail);
            execute_query2.setBoolean(12,true);

            execute_query2.executeUpdate();

        } catch (ClassNotFoundException e) {
            System.out.println("ERROR - SQL Server JDBC Driver failed");
            e.printStackTrace();
        } catch(SQLException e){
            e.printStackTrace();
        }
        return true;
    }

    // retrieve the username and password from the Healthworker Database here
    public String getUsernamePassword(String userName){

        Connection connection = null;
        String password = null;

        try{
            connection = getConnection(JDBC_URL);

            String query = "select healthworkerPassword as userPassword from HealthWorker where healthworkerUserName = ? and healthworkerActive = 1";

            PreparedStatement execute_query = connection.prepareStatement(query);

            execute_query.setString(1,userName);

            ResultSet result = execute_query.executeQuery();

            if(result.next()){
                password = result.getString("userPassword");
            }

        }catch(SQLException e){
            e.printStackTrace();
        }

        return password;
    }

    @Override
    public String pullSystemNotification() {
        StringBuilder notifications = new StringBuilder();
        String sql = "SELECT message FROM SystemNotifications ORDER BY created_at DESC";
        try (PreparedStatement stmt = connectionNabs.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                if (notifications.length() > 0) {
                    notifications.append("\n");  // Add a newline between messages if there is more than one
                }
                notifications.append(rs.getString("message"));
            }
        } catch (SQLException e) {
            System.err.println("Error pulling notifications: " + e.getMessage());
            return "Failed to pull notifications: " + e.getMessage();
        }
        return notifications.toString();
    }

    public static HealthWorker getHealthWorkerObjectFromID(int healthWorkerId) {
        Connection connection = null;
        HealthWorker healthWorker = null;

        try {
            // Load SQL Server JDBC driver and establish a connection
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            connection = DriverManager.getConnection(JDBC_URL);

            // Check if the connection is successfully established
            if (connection != null) {
                System.out.println("Connected to SQL Server Successfully");
            }

            String sql = """
                SELECT healthworkerFName, healthworkerLName, healthworkerDOB, healthworkerGender, 
                       healthworkerPhone, healthworkerLicenseNo, centerID 
                FROM HealthWorker 
                WHERE healthworkerID = ?
            """;


            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, healthWorkerId);
                ResultSet rs = pstmt.executeQuery();

                if (rs.next()) {
                    String fName = rs.getString("healthworkerFName");
                    String lName = rs.getString("healthworkerLName");
                    LocalDate dob = rs.getDate("healthworkerDOB").toLocalDate();
                    String gender = rs.getString("healthworkerGender");
                    String phone = rs.getString("healthworkerPhone");
                    String licenseNo = rs.getString("healthworkerLicenseNo");
                    int centerId = rs.getInt("centerID");

                    healthWorker = new HealthWorker(); // Assume a parameterless constructor or appropriate constructor
                    healthWorker.setFirstName(fName);
                    healthWorker.setLastName(lName);
                    healthWorker.setDob(dob);
                    healthWorker.setGender(gender);
                    healthWorker.setPhone(phone);
                    healthWorker.setLicenseNumber(licenseNo);
                    healthWorker.setCenterID(centerId);
                }
                rs.close();
            }
        } catch (ClassNotFoundException e) {
            System.err.println("Could not load JDBC driver: " + e.getMessage());
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("SQL Error: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                System.err.println("Failed to close connection: " + e.getMessage());
            }
        }

        return healthWorker;
    }

    // checking whether username is taken or not
    public boolean UsernameChecker(String currentUsername){

        Connection connection = null;
        boolean istaken = true;

        try{
            connection = getConnection(JDBC_URL);

            String query = "select healthworkerUserName as usernames from HealthWorker where healthworkerActive = 1";

            PreparedStatement execute_query = connection.prepareStatement(query);

            ResultSet result = execute_query.executeQuery();

            while(result.next()){
                if(currentUsername.matches(result.getString("usernames"))){
                    istaken = false;
                    break;
                }
            }

        }catch (SQLException e){
            e.printStackTrace();
        }

        return istaken;
    }

    // getting the specific healthworker based on their username
    public HealthWorker getHealthworker(String username){

        Connection connection = null;
        HealthWorker logged_healthworker = new HealthWorker();

        try{
            connection = getConnection(JDBC_URL);

            String query = "select * from HealthWorker where healthworkerUserName = ?";

            PreparedStatement execute_query = connection.prepareStatement(query);

            execute_query.setString(1,username);

            ResultSet result = execute_query.executeQuery();


            if(result.next()){
                logged_healthworker.userID = result.getInt("healthworkerID");
                logged_healthworker.userFName = result.getString("healthworkerFName");
                logged_healthworker.userLName = result.getString("healthworkerLName");
                logged_healthworker.userDOB = result.getDate("healthworkerDOB").toLocalDate();
                logged_healthworker.userGender = result.getString("healthworkerGender");
                logged_healthworker.userPhone = result.getString("healthworkerPhone");
                logged_healthworker.licenseNumber = result.getString("healthworkerLicenseNo");
                logged_healthworker.centerID = result.getInt("centerID");
                logged_healthworker.userUsername = result.getString("healthworkerUserName");
                logged_healthworker.userPassword = result.getString("healthworkerPassword");
                logged_healthworker.userEmail = result.getString("healthworkerEmail");
                boolean trash = result.getBoolean("healthworkerActive");
            }


        }catch (SQLException e){
            e.printStackTrace();
        }

        return logged_healthworker;
    }

    // This function is for updating the healthworker
    public boolean updatingHealthworker(HealthWorker healthworker){

        Connection connection = null;
        boolean updated = true;

        try{
            connection = getConnection(JDBC_URL);

            String query = "update HealthWorker set healthworkerFName = ?, healthworkerLName = ?, healthworkerDOB = ?, healthworkerGender = ?, healthworkerPhone = ?, healthworkerLicenseNo = ?, centerID = ?, healthworkerEmail = ? where healthworkerUserName = ?";

            PreparedStatement execute_query = connection.prepareStatement(query);

            execute_query.setString(1, healthworker.userFName);
            execute_query.setString(2, healthworker.userLName);
            execute_query.setDate(3, Date.valueOf(healthworker.userDOB));
            execute_query.setString(4, healthworker.userGender);
            execute_query.setString(5, healthworker.userPhone);
            execute_query.setString(6, healthworker.licenseNumber);
            execute_query.setInt(7,healthworker.centerID);
            execute_query.setString(8, healthworker.userEmail);
            execute_query.setString(9, healthworker.userUsername);

            execute_query.executeUpdate();

        }catch(SQLException e){
            e.printStackTrace();
        }

        return updated;
    }

    // deleteing the healthworker (turning active bit from 1 to 0)
    public boolean deletingHealthworker(HealthWorker healthworker){

        Connection connection = null;
        boolean deleted = true;

        try{
            connection = getConnection(JDBC_URL);

            String query = "Update HealthWorker set healthworkerActive = 0 where healthworkerUserName = ?";

            PreparedStatement execute_query = connection.prepareStatement(query);

            execute_query.setString(1, healthworker.userUsername);

            execute_query.executeUpdate();

        }catch (SQLException e){
            e.printStackTrace();
        }

        return deleted;
    }
}
