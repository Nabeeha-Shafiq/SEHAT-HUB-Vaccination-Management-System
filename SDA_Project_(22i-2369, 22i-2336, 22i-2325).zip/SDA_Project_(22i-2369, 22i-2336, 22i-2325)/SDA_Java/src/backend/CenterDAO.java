package backend;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CenterDAO {

    // Connection Strings here! ---------------------------

    // This is Wania's
    protected static final String JDBC_URL = "jdbc:sqlserver://ENVIOUS\\SQLEXPRESS:1433;databaseName=VaccinationSystem;integratedSecurity=true;encrypt=true;trustServerCertificate=true";
    // This is Emaan's

    // This is Nabeeha's (bebo)
    // protected static final String JDBC_URL = "jdbc:sqlserver://DESKTOP-J49GPGC\\SQLEXPRESS;databaseName=VaccinationSystem;integratedSecurity=true;encrypt=false;";

    // -------------------------------------------------------------------------

    // default constructor
    public CenterDAO(){}

    // All DATABASE implementations of the center will be implemented ----------------

    public List<String> create_CenterList(){

        Connection connection = null;
        List<String> center_list = new ArrayList<>();

        try{
            connection = DriverManager.getConnection(JDBC_URL);

            String query = "select centerID as cID, centerName as cname,centerAddress as caddress from Center where centerCapacity < 10;\n";

            PreparedStatement execute_query = connection.prepareStatement(query);

            ResultSet result = execute_query.executeQuery();

            while(result.next()){
                center_list.add(result.getString("cID") + ", " + result.getString("cname") + ", " + result.getString("caddress"));
            }

        }catch (SQLException e){
            e.printStackTrace();
        }

        return center_list;
    }

    // This function increases the center capacity
    public void updateCenterCapacity(int centerID){

        Connection connection = null;

        try{
            connection = DriverManager.getConnection(JDBC_URL);

            String query = "update Center set centerCapacity = centerCapacity + 1 where centerID = ?";

            PreparedStatement execute_query = connection.prepareStatement(query);

            execute_query.setInt(1,centerID);

            execute_query.executeUpdate();

        }catch(SQLException e){
            e.printStackTrace();
        }

    }

    // This function gets the Center line
    public String extractCenterLine(int centerID){

        Connection connection = null;
        String centerLine = "";

        try{
            connection = DriverManager.getConnection(JDBC_URL);

            String query = "select centerName as cname,centerAddress as caddress from Center where centerID = ?;";

            PreparedStatement execute_query = connection.prepareStatement(query);

            execute_query.setInt(1,centerID);

            ResultSet result = execute_query.executeQuery();

            centerLine += centerID;

            while(result.next()){
                centerLine += ", " + result.getString("cname") + ", " + result.getString("caddress");
            }

        }catch (SQLException e){
            e.printStackTrace();
        }

        return centerLine;
    }

    // getting the center
    public Center gettingCenter(int centerID){

        Connection connection = null;
        Center assignedCenter = new Center();

        try{
            connection = DriverManager.getConnection(JDBC_URL);

            String query = "select * from Center where centerID = ?";

            PreparedStatement execute_query = connection.prepareStatement(query);

            execute_query.setInt(1,centerID);

            ResultSet result = execute_query.executeQuery();

            while(result.next()){
                assignedCenter.setCenterID(result.getInt("centerID"));
                assignedCenter.setCenterName(result.getString("centerName"));
                assignedCenter.setCenterAddress(result.getString("centerAddress"));
                assignedCenter.setCenterCapacity(result.getInt("centerCapacity"));
            }

        }catch (SQLException e){
            e.printStackTrace();
        }

        return assignedCenter;
    }

    public boolean addVisitedVaccinee(int centerID,int vaccineeID, int appointmentID){

        Connection connection = null;
        boolean visited = true;

        try{
            connection = DriverManager.getConnection(JDBC_URL);

            String query = "insert into Center_AttendedVaccinee values (?,?,?)";

            PreparedStatement execute_query = connection.prepareStatement(query);

            execute_query.setInt(1,centerID);
            execute_query.setInt(2,vaccineeID);
            execute_query.setInt(3,appointmentID);

            execute_query.executeUpdate();

        }catch(SQLException e){
            e.printStackTrace();
        }

        return visited;
    }
}
