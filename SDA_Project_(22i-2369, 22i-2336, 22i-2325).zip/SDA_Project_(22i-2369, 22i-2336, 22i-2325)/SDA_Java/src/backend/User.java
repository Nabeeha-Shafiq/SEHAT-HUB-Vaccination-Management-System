package backend;
import java.time.LocalDate;

// This is Main USER
public abstract class User {

    // Attributes -----------------------------------------------------
    protected int userID;
    protected String userUsername;
    protected String userPassword;
    protected String userFName;
    protected String userLName;
    protected LocalDate userDOB;
    protected String userGender;
    protected String userPhone;
    protected String userEmail;
    protected static String userManualData;

    // Methods --------------------------------------------------------

    // default constructor
    public User(){}

    // parametrized constructor
    public User(String userUsername, String userPassword, String userFName, String userLName, LocalDate userDOB, String userGender, String userPhone, String email){
        this.userUsername = userUsername;
        this.userPassword = userPassword;
        this.userFName = userFName;
        this.userLName = userLName;
        this.userDOB = userDOB;
        this.userGender = userGender;
        this.userPhone = userPhone;
        this.userEmail = email;
    }

    // CRUD OPERATIONS!
    public abstract boolean registerUser(User newuser);
    public abstract boolean updateUser(User newuser);
    public abstract boolean deleteUser(User newuser);

    // OTHER HELPING METHODS!
    public abstract boolean[] validateUser(User newuser, int functionNum);

    public String pullSystemNotification() {
        // TODO Auto-generated method stub
        return null;
    }

    // GETTERS!
    public int getUserID() {
        return userID;
    }

    public LocalDate getUserDOB() {
        return userDOB;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public String getUserFName() {
        return userFName;
    }

    public String getUserGender() {
        return userGender;
    }

    public String getUserLName() {
        return userLName;
    }

    public static String getUserManualData() {
        return userManualData;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public String getUserPhone() {
        return userPhone;
    }

    public String getUserUsername() {
        return userUsername;
    }

    // SETTERS ----

    public void setUserID(int userID) {
        this.userID = userID;
    }
}
