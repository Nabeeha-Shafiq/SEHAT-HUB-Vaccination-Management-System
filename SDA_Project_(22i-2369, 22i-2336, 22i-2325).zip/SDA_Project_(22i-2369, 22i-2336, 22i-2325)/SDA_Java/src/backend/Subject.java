package backend;

public interface Subject {
	void pushSystemNotification(String message);
}
