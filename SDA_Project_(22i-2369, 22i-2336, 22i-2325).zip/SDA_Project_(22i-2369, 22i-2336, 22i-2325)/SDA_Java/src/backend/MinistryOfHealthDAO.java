package backend;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import application.ReportData;
import application.UserData;
import application.VaccineCenterData;

public class MinistryOfHealthDAO implements Subject {
    // Connection Strings here! ---------------------------

    // This is Wania's
    protected static final String JDBC_URL = "jdbc:sqlserver://ENVIOUS\\SQLEXPRESS:1433;databaseName=VaccinationSystem;integratedSecurity=true;encrypt=true;trustServerCertificate=true";
    // This is Emaan's

    // This is Nabeeha's (bebo)
     //protected static final String JDBC_URL = "jdbc:sqlserver://DESKTOP-J49GPGC\\SQLEXPRESS;databaseName=VaccinationSystem;integratedSecurity=true;encrypt=false;";

    // -------------------------------------------------------------------------

    private Connection connection;

    public MinistryOfHealthDAO() {
        try {
            // Load SQL Server JDBC driver and establish a connection
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            connection = DriverManager.getConnection(JDBC_URL);

            // Check if the connection is successfully established
            if (connection != null) {
                System.out.println("Connected to SQL Server Successfully");
            }
        } catch (ClassNotFoundException e) {
            // This exception handles the case where the JDBC driver isn't found
            System.err.println("Could not load JDBC driver: " + e.getMessage());
            e.printStackTrace();
        } catch (SQLException e) {
            // This exception handles SQL errors during connection setup
            System.err.println("SQL Exception: " + e.getMessage());
            e.printStackTrace();
        }
    }
    public Connection getConnection() {
        return connection;
    }
    
    
    public void pushSystemNotification(String message) {
        String sql = "INSERT INTO SystemNotifications (message) VALUES (?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, message);
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error pushing system notification: " + e.getMessage());
        }
    }
    
    public ArrayList<ReportData> fetchReportData() {
        String sql = """
            SELECT c.centerName, hw.healthworkerFName + ' ' + hw.healthworkerLName AS HealthWorkerName,
            v.vaccineeFName + ' ' + v.vaccineeLName AS VaccineeName, v.vaccineeID, vac.vaccineName,
            vv.doses_done AS DosesCompleted FROM Center c
            JOIN Center_AssignedHealthWorker cahw ON c.centerID = cahw.centerID
            JOIN HealthWorker hw ON cahw.healthworkerID = hw.healthworkerID
            JOIN Center_AttendedVaccinee cav ON c.centerID = cav.centerID
            JOIN Vaccinee v ON cav.vaccineeID = v.vaccineeID
            JOIN Vaccinee_VaccineSchedule vv ON v.vaccineeID = vv.vaccineeID
            JOIN Vaccine vac ON vv.vaccineID = vac.vaccineID
            ORDER BY c.centerName, hw.healthworkerFName, v.vaccineeFName;
        """;
        ArrayList<ReportData> data = new ArrayList<>();
        try (PreparedStatement stmt = connection.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                data.add(new ReportData(
                    rs.getString("centerName"),
                    rs.getString("HealthWorkerName"),
                    rs.getString("VaccineeName"),
                    rs.getString("vaccineeID"),
                    rs.getString("vaccineName"),
                    rs.getInt("DosesCompleted")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return data;
    }
    
    public List<String> getVaccineNames() {
        List<String> vaccines = new ArrayList<>();
        String sql = "SELECT vaccineName FROM Vaccine";

        try (Connection conn = DriverManager.getConnection(JDBC_URL);
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                vaccines.add(rs.getString("vaccineName"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error fetching vaccine names: " + e.getMessage());
        }
        return vaccines;
    }

    // Fetch center names from the database
    public List<String> getCenterNames() {
        List<String> centers = new ArrayList<>();
        String sql = "SELECT centerName FROM Center";

        try (Connection conn = DriverManager.getConnection(JDBC_URL);
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                centers.add(rs.getString("centerName"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error fetching center names: " + e.getMessage());
        }
        return centers;
    }
    
    public List<UserData> fetchVaccineSideEffects() {
        List<UserData> results = new ArrayList<>();
        String query = "SELECT V.vaccineeFName + ' ' + V.vaccineeLName AS Username, V.vaccineeID AS User_ID, " +
                       "VA.vaccineName AS Vaccine, C.centerName AS Center, VR.sideEffects AS Symptom, " +
                       "VR.Additional_Details FROM Vaccinee_RejectedVaccine VR " +
                       "JOIN Vaccinee V ON VR.vaccineeID = V.vaccineeID " +
                       "JOIN Vaccine VA ON VR.vaccineID = VA.vaccineID " +
                       "JOIN Center_AttendedVaccinee CA ON V.vaccineeID = CA.vaccineeID " +
                       "JOIN Center C ON CA.centerID = C.centerID";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                results.add(new UserData(
                    rs.getString("Username"),
                    rs.getString("User_ID"),
                    rs.getString("Vaccine"),
                    rs.getString("Center"),
                    rs.getString("Symptom"),
                    rs.getString("Additional_Details")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return results;
    }
    
    
    }

