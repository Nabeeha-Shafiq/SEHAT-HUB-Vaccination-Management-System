package backend;
import java.util.ArrayList;

// NADRA
public class NADRA{

    // Attributes -------------------------------------------------

    private ArrayList<Vaccinee> registeredVaccines;
    private ArrayList<HealthWorker> registeredHealthWorker;

    // Methods ----------------------------------------------------

    // contructor

    public NADRA(ArrayList<Vaccinee> registeredVaccines, ArrayList<HealthWorker> registeredHealthWorker) {
        this.registeredVaccines = registeredVaccines;
        this.registeredHealthWorker = registeredHealthWorker;
    }

    // Getter & setters
    public ArrayList<Vaccinee> getRegisteredVaccines() {
        return registeredVaccines;
    }

    public void setRegisteredVaccines(ArrayList<Vaccinee> registeredVaccines) {
        this.registeredVaccines = registeredVaccines;
    }

    public ArrayList<HealthWorker> getRegisteredHealthWorker() {
        return registeredHealthWorker;
    }

    public void setRegisteredHealthWorker(ArrayList<HealthWorker> registeredHealthWorker) {
        this.registeredHealthWorker = registeredHealthWorker;
    }

}
