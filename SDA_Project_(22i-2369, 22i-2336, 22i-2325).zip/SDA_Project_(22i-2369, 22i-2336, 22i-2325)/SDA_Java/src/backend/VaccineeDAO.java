package backend;
import application.Descendant;
import application.VaccineeData;

import java.sql.*;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Callable;

public class VaccineeDAO implements Observer{

    // Connection Strings here! ---------------------------

    // This is Wania's
    protected static final String JDBC_URL = "jdbc:sqlserver://ENVIOUS\\SQLEXPRESS:1433;databaseName=VaccinationSystem;integratedSecurity=true;encrypt=true;trustServerCertificate=true";
    // This is Emaan's

    // This is Nabeeha's (bebo)
    // protected static final String JDBC_URL = "jdbc:sqlserver://DESKTOP-J49GPGC\\SQLEXPRESS;databaseName=VaccinationSystem;integratedSecurity=true;encrypt=false;";
    private static Connection connection;
    // -------------------------------------------------------------------------

    // default constructor

    private static Connection getConnection() throws SQLException {
        try {
            // Load the JDBC driver
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            // Create and return a connection to the database
            return DriverManager.getConnection(JDBC_URL);
        } catch (ClassNotFoundException e) {
            // Handle the error for missing JDBC driver
            throw new SQLException("SQL Server JDBC Driver not found.", e);
        }
    }

    // All the CRUD + DATABASE implementations of the Vaccinee will be implemented here ------------------------

    public VaccineeDAO() throws SQLException{
        VaccineeDAO.connection=getConnection();
    }

    public boolean createUser(Vaccinee newvaccinee){

        // establishing connection here
        Connection connection = null;

        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            connection = DriverManager.getConnection(JDBC_URL);

            // checking the connection
            if (connection != null){
                System.out.println("\tConnected to SQL Server Successfully");
            }

            // get the latest entry for the Vaccinee to get the Vaccine ID
            String query1 = "select MAX(vaccineeID) as maxVaccineeID from Vaccinee";

            PreparedStatement execute_query1 = connection.prepareStatement(query1);
            ResultSet resultset = execute_query1.executeQuery();

            int maxVaccineeID = 0;
            if(resultset.next()){
                maxVaccineeID = resultset.getInt("maxVaccineeID");
            }

            maxVaccineeID++;

            resultset.close();
            execute_query1.close();

            // Now add the new entry into the table Vaccinee
            String query2 = "insert into Vaccinee values (?,?,?,?,?,?,?,?,?,?);";

            PreparedStatement execute_query2 = connection.prepareStatement(query2);

            execute_query2.setInt(1, maxVaccineeID);
            execute_query2.setString(2,newvaccinee.userFName);
            execute_query2.setString(3, newvaccinee.userLName);
            execute_query2.setDate(4, Date.valueOf(newvaccinee.userDOB));
            execute_query2.setString(5, newvaccinee.userGender);
            execute_query2.setString(6, newvaccinee.userPhone);
            execute_query2.setString(7, newvaccinee.userUsername);
            execute_query2.setString(8, newvaccinee.userPassword);
            execute_query2.setString(9,newvaccinee.userEmail);
            execute_query2.setBoolean(10,true);

            execute_query2.executeUpdate();

        } catch (ClassNotFoundException e) {
            System.out.println("ERROR - SQL Server JDBC Driver failed");
            e.printStackTrace();
        } catch(SQLException e){
            e.printStackTrace();
        }
        return true;
    }

    // adding the child and parent link in this table
    public boolean addingchild(Vaccinee parent, Vaccinee vaccinee){

        Connection connection = null;
        boolean added = true;

        try{
            connection = DriverManager.getConnection(JDBC_URL);

            String query = "insert into Vaccinee_Children values(?,?);";

            PreparedStatement execute_query = connection.prepareStatement(query);

            execute_query.setInt(1,parent.userID);
            execute_query.setInt(2,vaccinee.userID);

            execute_query.executeUpdate();

        }catch (SQLException e){
            e.printStackTrace();
        }
        return added;
    }

    // retrieve the username and password from the Vaccinee Database here
    public String getUsernamePassword(String userName){

        Connection connection = null;
        String password = null;

        try{
            connection = DriverManager.getConnection(JDBC_URL);

            String query = "select vaccineePassword as userPassword from Vaccinee where vaccineeUserName = ? and vaccineActive = 1";

            PreparedStatement execute_query = connection.prepareStatement(query);

            execute_query.setString(1,userName);

            ResultSet result = execute_query.executeQuery();

            if(result.next()){
                password = result.getString("userPassword");
            }

        }catch(SQLException e){
            e.printStackTrace();
        }

        return password;
    }

    public static List<Vaccine> getDueVaccines(int vaccineeId) {
        List<Vaccine> dueVaccines = new ArrayList<>();
        String query = "SELECT v.* FROM Vaccine v " +
                "JOIN Vaccinee_VaccineSchedule vs ON v.vaccineID = vs.vaccineID " +
                "WHERE vs.vaccineeID = ? AND vs.doses_done < vs.doses_needed";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, vaccineeId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Vaccine vaccine = new Vaccine();
                vaccine.setVaccineID(rs.getInt("vaccineID"));
                vaccine.setVaccineName(rs.getString("vaccineName"));
                vaccine.setProdCompany(rs.getString("prodCompany"));
                vaccine.setProdCountry(rs.getString("prodCountry"));
                vaccine.setVaccineInfo(rs.getString("vaccineInfo"));
                dueVaccines.add(vaccine);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return dueVaccines;
    }

    public static List<Appointment> getDueAppointments(int vaccineeId) {
        List<Appointment> dueAppointments = new ArrayList<>();
        String query = "SELECT a.*, c.centerID, c.centerName, c.centerAddress, c.centerCapacity FROM Appointment a " +
                "JOIN Center c ON a.centerID = c.centerID " +
                "JOIN Vaccinee_pendingAppointment pa ON a.appointmentID = pa.appointmentID " +
                "WHERE pa.vaccineeID = ? AND a.appointmentDate > GETDATE()";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, vaccineeId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                //Vaccine vaccine = new Vaccine();
                // int appointmentID = rs.getInt("appointmentID");
                Vaccine vaccine = new Vaccine(
                        rs.getInt("vaccineID"),
                        rs.getString("vaccineName"),
                        rs.getString("prodCompany"),
                        rs.getString("prodCountry"),
                        rs.getString("vaccineInfo")
                );
                Center center = new Center(rs.getInt("centerID"), rs.getString("centerName"), rs.getString("centerAddress"), rs.getInt("centerCapacity"));

                Appointment appointment = new Appointment(
                        rs.getInt("appointmentID"),
                        vaccine,
                        rs.getTime("startTime").toLocalTime(),
                        rs.getTime("endTime").toLocalTime(),
                        center,
                        rs.getBoolean("reserved"),
                        rs.getDate("appointmentDate")
                );
                dueAppointments.add(appointment);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return dueAppointments;
    }

    // checking whether username is taken or not
    public boolean UsernameChecker(String currentUsername){

        Connection connection = null;
        boolean istaken = true;

        try{
            connection = DriverManager.getConnection(JDBC_URL);

            String query = "select vaccineeUserName as usernames from Vaccinee where vaccineActive = 1";

            PreparedStatement execute_query = connection.prepareStatement(query);

            ResultSet result = execute_query.executeQuery();

            while(result.next()){
                if(currentUsername.matches(result.getString("usernames"))){
                    istaken = false;
                    break;
                }
            }

        }catch (SQLException e){
            e.printStackTrace();
        }

        return istaken;
    }

    // getting the specific vaccinee based on their username
    public Vaccinee getVaccinee(String username) throws SQLException {

        Connection connection = null;
        Vaccinee logged_vaccinee = new Vaccinee();

        try{
            connection = DriverManager.getConnection(JDBC_URL);

            String query = "select * from Vaccinee where vaccineeUserName = ?";

            PreparedStatement execute_query = connection.prepareStatement(query);

            execute_query.setString(1,username);

            ResultSet result = execute_query.executeQuery();


            if(result.next()){
                logged_vaccinee.userID = result.getInt("vaccineeID");
                logged_vaccinee.userFName = result.getString("vaccineeFName");
                logged_vaccinee.userLName = result.getString("vaccineeLName");
                logged_vaccinee.userDOB = result.getDate("vaccineeDOB").toLocalDate();
                logged_vaccinee.userGender = result.getString("vaccineeGender");
                logged_vaccinee.userPhone = result.getString("vaccineePhone");
                logged_vaccinee.userUsername = result.getString("vaccineeUserName");
                logged_vaccinee.userPassword = result.getString("vaccineePassword");
                logged_vaccinee.userEmail = result.getString("vaccineeEmail");
                boolean trash = result.getBoolean("vaccineActive");
            }


        }catch (SQLException e){
            e.printStackTrace();
        }

        return logged_vaccinee;
    }

    public static Vaccinee getVaccineeObjectFromID(int vaccineeId) {
        String sql = "SELECT vaccineeFName, vaccineeLName, vaccineeDOB, vaccineeGender, vaccineePhone, vaccineeUserName, vaccineePassword FROM Vaccinee WHERE vaccineeID = ?";
        Vaccinee vaccinee = null;

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, vaccineeId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                String fName = rs.getString("vaccineeFName");
                String lName = rs.getString("vaccineeLName");
                LocalDate dob = rs.getDate("vaccineeDOB").toLocalDate();
                String gender = rs.getString("vaccineeGender");
                String phone = rs.getString("vaccineePhone");
                String username = rs.getString("vaccineeUserName");
                String password = rs.getString("vaccineePassword");

                vaccinee = new Vaccinee(username, password, fName, lName, dob, gender, phone, null); // Assuming email is not shown in the schema
            }
        } catch (SQLException e) {
            System.err.println("SQL Error: " + e.getMessage());
            e.printStackTrace();
        }

        return vaccinee;
    }

    // getting the specific vaccinee based on their username
    public Vaccinee getVaccinee(int vaccineeID) throws SQLException {

        Connection connection = null;
        Vaccinee logged_vaccinee = new Vaccinee();

        try{
            connection = DriverManager.getConnection(JDBC_URL);

            String query = "select * from Vaccinee where vaccineeID = ?";

            PreparedStatement execute_query = connection.prepareStatement(query);

            execute_query.setInt(1,vaccineeID);

            ResultSet result = execute_query.executeQuery();


            if(result.next()){
                logged_vaccinee.userID = result.getInt("vaccineeID");
                logged_vaccinee.userFName = result.getString("vaccineeFName");
                logged_vaccinee.userLName = result.getString("vaccineeLName");
                logged_vaccinee.userDOB = result.getDate("vaccineeDOB").toLocalDate();
                logged_vaccinee.userGender = result.getString("vaccineeGender");
                logged_vaccinee.userPhone = result.getString("vaccineePhone");
                logged_vaccinee.userUsername = result.getString("vaccineeUserName");
                logged_vaccinee.userPassword = result.getString("vaccineePassword");
                logged_vaccinee.userEmail = result.getString("vaccineeEmail");
                boolean trash = result.getBoolean("vaccineActive");
            }


        }catch (SQLException e){
            e.printStackTrace();
        }

        return logged_vaccinee;
    }

    @Override
    public String pullSystemNotification() {
        StringBuilder notifications = new StringBuilder();
        String sql = "SELECT message FROM SystemNotifications ORDER BY created_at DESC";
        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                if (notifications.length() > 0) {
                    notifications.append("\n");  // Add a newline between messages if there is more than one
                }
                notifications.append(rs.getString("message"));
            }
        } catch (SQLException e) {
            System.err.println("Error pulling notifications: " + e.getMessage());
            return "Failed to pull notifications: " + e.getMessage();
        }
        return notifications.toString();
    }

    public Map<String, int[]> fetchVaccinationProgress(int vaccineeID) throws Exception {
        Map<String, int[]> vaccinationData = new HashMap<>();
        String query = """
            SELECT v.vaccineName, vs.doses_needed, vs.doses_done
            FROM Vaccinee_VaccineSchedule vs
            JOIN Vaccine v ON vs.vaccineID = v.vaccineID
            WHERE vs.vaccineeID = ?
        """;

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, vaccineeID);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    String vaccineName = rs.getString("vaccineName");
                    int dosesNeeded = rs.getInt("doses_needed");
                    int dosesDone = rs.getInt("doses_done");
                    int dosesPending = dosesNeeded - dosesDone;

                    vaccinationData.put(vaccineName, new int[]{dosesDone, dosesPending});
                }
            }
        }
        return vaccinationData;
    }

    public List<String> getVaccines() {
        List<String> vaccines = new ArrayList<>();
        String query = "SELECT DISTINCT vaccineName FROM Vaccine";
        try (PreparedStatement stmt = connection.prepareStatement(query); ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                vaccines.add(rs.getString("vaccineName"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return vaccines;
    }

    public List<String> getSymptoms() {
        List<String> symptoms = new ArrayList<>();
        String query = "SELECT DISTINCT sideEffects AS Symptom FROM Vaccinee_rejectedVaccine";
        try (PreparedStatement stmt = connection.prepareStatement(query); ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                symptoms.add(rs.getString("Symptom"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return symptoms;
    }

    public List<String> getCenters() {
        List<String> centers = new ArrayList<>();
        String query = "SELECT centerName FROM Center";
        try (PreparedStatement stmt = connection.prepareStatement(query); ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                centers.add(rs.getString("centerName"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return centers;
    }

    public void insertSideEffect(int vaccineID, int vaccineeID, String sideEffect, String additionalDetails) {
        String sql = "INSERT INTO Vaccinee_RejectedVaccine (vaccineID, vaccineeID, sideEffects, Additional_Details) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, vaccineID);
            stmt.setInt(2, vaccineeID);
            stmt.setString(3, sideEffect);
            stmt.setString(4, additionalDetails);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public int fetchVaccineIDByName(String vaccineName) {
        String sql = "SELECT vaccineID FROM Vaccine WHERE vaccineName = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, vaccineName);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("vaccineID");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    // getting children
    public List<Descendant> gettingChildren(Vaccinee parent){

        Connection connection = null;
        Connection connection1 = null;
        List<Descendant> children = new ArrayList<>();
        int[] childIDs = new int[20];

        try{
            connection = DriverManager.getConnection(JDBC_URL);

            String Query = "Select childID from Vaccinee_Children where parentID = ?";

            PreparedStatement execute_query = connection.prepareStatement(Query);

            execute_query.setInt(1,parent.userID);

            ResultSet result = execute_query.executeQuery();

            int i = 0;
            while(result.next()){
                childIDs[i] = result.getInt("childID");
                i++;
            }

            connection.close();

            // now getting the whole objects
            connection1 = DriverManager.getConnection(JDBC_URL);

            String query = "select vaccineeUserName, vaccineeFName, vaccineeLName, vaccineeDOB from Vaccinee where vaccineeID = ?";

            PreparedStatement execute_query2 = connection1.prepareStatement(query);

            int j = 0;
            while(childIDs[j] != 0) {

                execute_query2.setInt(1, childIDs[j]);

                ResultSet result2 = execute_query2.executeQuery();

                if (result2.next()) {
                    Descendant temp = new Descendant();

                    String fname = result2.getString("vaccineeFName");
                    String lname = result2.getString("vaccineeLName");
                    LocalDate dob = result2.getDate("vaccineeDOB").toLocalDate();
                    LocalDate today = LocalDate.now();
                    int age = Period.between(dob, today).getYears();
                    String username = result2.getString("vaccineeUserName");

                    temp.setAge(age);
                    temp.setFullname(fname + " " + lname);
                    temp.setUsername(username);

                    children.add(temp);
                }
                j++;
            }

            connection1.close();

        }catch (SQLException e){
            e.printStackTrace();
        }

        return children;
    }

    // checking for children
    public boolean checkingChildren(Vaccinee parent){

        Connection connection = null;
        boolean present = false;

        try{

            connection = DriverManager.getConnection(JDBC_URL);

            String query = "Select childID from Vaccinee_Children where parentID = ?";

            PreparedStatement execute_query = connection.prepareStatement(query);

            execute_query.setInt(1,parent.userID);

            ResultSet result = execute_query.executeQuery();

            if(result.next()){
                present = true;
            }

        }catch (SQLException e){
            e.printStackTrace();
        }

        return present;
    }

    // Updating the new details of the Vaccinee
    public boolean updatingVaccinee(Vaccinee vaccinee){

        Connection connection = null;
        boolean updated = true;

        try{
            connection = DriverManager.getConnection(JDBC_URL);

            String query = "update Vaccinee set vaccineeFName = ?, vaccineeLName = ?, vaccineeDOB = ?, vaccineeGender = ?, vaccineePhone = ?, vaccineeEmail = ? where vaccineeUserName = ?;";

            PreparedStatement execute_query = connection.prepareStatement(query);

            execute_query.setString(1, vaccinee.userFName);
            execute_query.setString(2, vaccinee.userLName);
            execute_query.setDate(3, Date.valueOf(vaccinee.userDOB));
            execute_query.setString(4, vaccinee.userGender);
            execute_query.setString(5, vaccinee.userPhone);
            execute_query.setString(6, vaccinee.userEmail);
            execute_query.setString(7,vaccinee.userUsername);

            execute_query.executeUpdate();

        }catch (SQLException e){
            e.printStackTrace();
        }

        return updated;
    }

    // deleteing the vaccinee (turning active bit from 1 to 0)
    public boolean deletingVaccinee(Vaccinee vaccinee){

        Connection connection = null;
        boolean deleted = true;

        try{
            connection = DriverManager.getConnection(JDBC_URL);

            String query = "Update Vaccinee set vaccineActive = 0 where vaccineeUserName = ?";

            PreparedStatement execute_query = connection.prepareStatement(query);

            execute_query.setString(1, vaccinee.userUsername);

            execute_query.executeUpdate();

        }catch (SQLException e){
            e.printStackTrace();
        }

        return deleted;
    }


    public List<String> gettingMissedVaccinee(){

        Connection connection = null;
        List<String> vaccineeList = new ArrayList<>();

        try{
            connection = DriverManager.getConnection(JDBC_URL);

            String query = "select V.vaccineeID, V.vaccineeFName, V.vaccineeLName from Vaccinee V inner join Vaccinee_MissedAppointment VMA on V.vaccineeID = VMA.vaccineeID;";

            PreparedStatement execute_query = connection.prepareStatement(query);

            ResultSet result = execute_query.executeQuery();

            while(result.next()){
                String temp = "";
                temp += result.getString("vaccineeID") + ", " + result.getString("vaccineeFName") + " " + result.getString("vaccineeLName");
                vaccineeList.add(temp);
            }

        }catch (SQLException e){
            e.printStackTrace();
        }

        return vaccineeList;
    }

    public List<VaccineeData> extractingDailyAppointments(int centerID, int vaccineID){

        Connection connection = null;
        List<VaccineeData> vaccineeList = new ArrayList<>();

        try{
            connection = DriverManager.getConnection(JDBC_URL);

            String query = "select V.vaccineeID, V.vaccineeFName, V.vaccineeLName, A.appointmentID, A.startTime from Vaccinee V inner join Vaccinee_pendingAppointment VPA on V.vaccineeID = VPA.vaccineeID inner join Appointment A on VPA.appointmentID = A.appointmentID where A.appointmentDate = CAST(GETDATE() AS DATE) and A.centerID = ? and A.vaccineID = ?;";

            PreparedStatement execute_query = connection.prepareStatement(query);

            execute_query.setInt(1,centerID);
            execute_query.setInt(2,vaccineID);

            ResultSet result = execute_query.executeQuery();

            while(result.next()){
                VaccineeData temp = new VaccineeData();

                temp.setAppointmentID(result.getInt("appointmentID"));
                temp.setAppointmentTime(result.getString("startTime"));
                temp.setVaccineeId(result.getInt("vaccineeID"));
                String fullname = result.getString("vaccineeFName");
                fullname += " " + result.getString("vaccineeLName");
                temp.setVaccineeName(fullname);
                temp.setStatus("Pending");

                vaccineeList.add(temp);
            }

        }catch (SQLException e){
            e.printStackTrace();
        }

        return vaccineeList;
    }

    public boolean makeCompletedAppointment(int appointmentID, int vaccineeID){

        Connection connection = null;
        Connection connection1 = null;
        boolean marked = true;

        try{
            connection = DriverManager.getConnection(JDBC_URL);

            String query = "delete from Vaccinee_pendingAppointment where appointmentID = ?";

            PreparedStatement execute_query = connection.prepareStatement(query);

            execute_query.setInt(1,appointmentID);

            execute_query.executeUpdate();

            connection.close();

            connection1 = DriverManager.getConnection(JDBC_URL);

            String query1 = "insert into Vaccinee_completedAppointment values (?,?)";

            PreparedStatement execute_query1 = connection1.prepareStatement(query1);

            execute_query1.setInt(1,vaccineeID);
            execute_query1.setInt(2,appointmentID);

            execute_query1.executeUpdate();

            connection1.close();

        }catch (SQLException e){
            e.printStackTrace();
        }

        return marked;
    }

    public boolean UpdateDose(int vaccineeID, int vaccineID){

        Connection connection = null;
        boolean updated = true;

        try{
            connection = DriverManager.getConnection(JDBC_URL);

            String query = "update Vaccinee_VaccineSchedule set doses_needed = doses_needed - 1, doses_done = doses_done + 1 where vaccineID = ? and vaccineeID = ?";

            PreparedStatement execute_query = connection.prepareStatement(query);

            execute_query.setInt(1,vaccineID);
            execute_query.setInt(2,vaccineeID);

            execute_query.executeUpdate();

        }catch(SQLException e){
            e.printStackTrace();
        }

        return updated;
    }

    public boolean filterAppointments(int centerID, int vaccineID){

        Connection connection = null;
        Connection connection1 = null;
        boolean filtered = true;
        ArrayList<Integer> appointmentIDs = new ArrayList<Integer>();
        ArrayList<Integer> vaccineeIDs = new ArrayList<Integer>();

        try{
            connection = DriverManager.getConnection(JDBC_URL);

            String query = "select VPA.vaccineeID, A.appointmentID from Appointment A inner join Vaccinee_pendingAppointment VPA on A.appointmentID = VPA.appointmentID where A.appointmentDate < CAST(GETDATE() as DATE) and A.vaccineID = ? and A.centerID = ?";

            PreparedStatement execute_query = connection.prepareStatement(query);

            execute_query.setInt(1,vaccineID);
            execute_query.setInt(2,centerID);

            ResultSet result = execute_query.executeQuery();

            while(result.next()){
                appointmentIDs.add(result.getInt("appointmentID"));
                vaccineeIDs.add(result.getInt("vaccineeID"));
            }

            connection.close();

            connection1 = DriverManager.getConnection(JDBC_URL);

            String query1 = "INSERT INTO Vaccinee_missedAppointment values (?,?)";
            String query2 = "DELETE FROM Vaccinee_pendingAppointment WHERE appointmentID = ?";

            PreparedStatement execute_query1 = connection1.prepareStatement(query1);
            PreparedStatement execute_query2 = connection1.prepareStatement(query2);

            while(!appointmentIDs.isEmpty()){
                execute_query1.setInt(1,vaccineeIDs.removeFirst());
                int appt = appointmentIDs.removeFirst();
                execute_query1.setInt(2,appt);
                execute_query2.setInt(1,appt);
                execute_query1.executeUpdate();
                execute_query2.executeUpdate();
            }

            connection1.close();

        }catch (SQLException e){
            e.printStackTrace();
        }

        return filtered;
    }

    public int getVaccineeAppointment(int appointmentID){

        Connection connection = null;
        int vaccineeID = 0;

        try{
            connection = DriverManager.getConnection(JDBC_URL);

            String query = "select vaccineeID from Vaccinee_pendingAppointment where appointmentID = ?";

            PreparedStatement execute_query = connection.prepareStatement(query);

            execute_query.setInt(1, appointmentID);

            ResultSet result = execute_query.executeQuery();

            while(result.next()) {
                vaccineeID = result.getInt("vaccineeID");
            }

        }catch (SQLException e){
            e.printStackTrace();
        }

        return vaccineeID;
    }

    public boolean AddChildSchedule(Vaccinee vaccinee){

        Connection connection = null;
        boolean done = true;

        try{
            connection = DriverManager.getConnection(JDBC_URL);

            String query = "";

        }catch (SQLException e){
            e.printStackTrace();
        }

        return done;
    }
}
