// This is our Controller for:
// User (Vaccinee and HealthWorker) manager
// Appointments, Vaccine, Center

package backend;
import application.Appointment;
import application.Descendant;
import application.VaccineeData;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import application.ReportData;
import application.UserData;
import application.VaccineCenterData;
import application.VaccineProgress;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.chart.PieChart;

public class SehatHUB {

    // Attributes -----------------------------------------------

    private Vaccinee vaccinee;
    private Center center;
    private Vaccine vaccine;
    private HealthWorker healthworker;
    private backend.Appointment appointment;
    private MOH moh = new MOH();

    // Methods -------------------------------------------------

    // default constructor and add the database connection here
    public SehatHUB(){}

    // This is the authentication function for the Vaccinee
    public boolean[] SignUp_Vaccinee(Vaccinee vaccinee){

        boolean[] answer = vaccinee.validateUser(vaccinee,1);

        boolean isCorrect = true;
        for(boolean value: answer){
            if(!value){
                isCorrect = false;
            }
        }
        if(isCorrect){
            if (vaccinee.registerUser(vaccinee)){
                return answer; // This means that registration was done successfully
            }
        }
        return answer;
    }

    // This is the authentication function for the Vaccinee
    public boolean[] SignUp_Vaccinee(Vaccinee parent, Vaccinee child, int ischild) throws SQLException {

        boolean[] answer = child.validateUser(child,3);

        boolean isCorrect = true;
        for(boolean value: answer){
            if(!value){
                isCorrect = false;
            }
        }
        if(isCorrect){
            if (child.registerUser(child)){
                // call the add child function in this to add children in database
                parent.addchild(child.getvaccinee(child.getUserUsername()));
                return answer; // This means that registration was done successfully
            }
        }
        return answer;
    }

    // This function is for getting children in forms of strings
    public List<Descendant> getchildrenStrings(Vaccinee parent){
        return parent.getchildren();
    }

    // This is login in function for the Vaccinee
    public int Login_Vaccinee(String username, String password) throws SQLException {
        vaccinee = new Vaccinee();

        if(vaccinee.validateUser(username,password)==3){
            vaccinee = vaccinee.getvaccinee(username);
        }
        return vaccinee.validateUser(username, password);
    }

    // boolean checker for whether children are present or not
    public boolean childrenlinked(Vaccinee parent){
        return parent.checkChild();
    }

    // this is update function for the Vaccinee
    public boolean[] updateVaccine(Vaccinee vaccinee){
        boolean[] answer = vaccinee.validateUser(vaccinee,2);

        boolean isCorrect = true;
        for(boolean value: answer){
            if(!value){
                isCorrect = false;
            }
        }
        if(isCorrect){
            if (vaccinee.updateUser(vaccinee)){
                return answer; // This means that updating was done successfully
            }
        }
        return answer;
    }

    // add vaccinee in the instance
    public void addVaccinee(String username, String password, String fname, String lname, LocalDate DOB, String gender, String phone, String email) throws SQLException {
        vaccinee = new Vaccinee(username,password,fname,lname,DOB,gender,phone,email);
    }

    // getter for the vaccinee
    public Vaccinee getVaccinee(){
        return vaccinee;
    }

    // setter for the vaccinee
    public void setVaccinee(Vaccinee vacc){
        this.vaccinee = vacc;
    }

    // getter for the vaccinee
    public Vaccinee getVaccinee(int vaccineeID) throws SQLException {
        return vaccinee.getvaccinee(vaccineeID);
    }

    // This if for getting that specific line of center from the database
    public String getCenterLine(int centerID){
        return center.getCenterline(centerID);
    }

    // This is authentication function for the Healthworker
    public boolean[] SignUp_Healthworker(HealthWorker healthworker){

        boolean[] answer = healthworker.validateUser(healthworker,1);

        boolean isCorrect = true;
        for(boolean value: answer){
            if(!value){
                isCorrect = false;
            }
        }
        if(isCorrect){
            if (healthworker.registerUser(healthworker)){
                // call Center to add increase the center's capacity
                center.UpdateCenterCapacity(healthworker.centerID);
                this.center = center.getCenter(healthworker.centerID);
                return answer; // This means that registration was done successfully
            }
        }
        return answer;
    }

    // This is login in function for the Healthworker
    public int Login_Healthworker(String username, String password){
        healthworker = new HealthWorker();
        center = new Center();
        // this is for returning the healthworker obj

        if(healthworker.validateUser(username,password)==3){
            healthworker = healthworker.gethealthworker(username);
            center.getCenter(healthworker.centerID);
        }
        return healthworker.validateUser(username, password);
    }

    // add Healthworker in the instance
    public void addHealthworker(String username, String password, String fname, String lname, LocalDate DOB, String gender, String phone, String license, String email, int centerID){
        healthworker = new HealthWorker(username,password,fname,lname,DOB,gender,phone,license,email,centerID);
    }

    // getter for the healthworker
    public HealthWorker getHealthworker(){
        return healthworker;
    }

    public List<Vaccine> getDueVaccines(int vaccineeId) {
        return Vaccinee.getDueVaccines(vaccineeId);
    }

    public List<backend.Appointment> getDueAppointments(int vaccineeId) {
        return Vaccinee.getDueAppointments(vaccineeId);
    }

    public String pullSystemNotification() throws SQLException {
        //comment out this vaccinee line after wania adds logic to keep current user = this vaccinee obj
        //waneez do
        //vaccinee=currentVaccinee
        //vaccinee=VaccineeDAO.getVaccineeObjectFromID(2);
        vaccinee = new Vaccinee();
        return vaccinee.pullSystemNotification();
    }

    public String pullSystemNotificationHealthworker() {
        //for now this is null waneez will fix it
        //it will give error abhi dw
        return healthworker.pullSystemNotification();
    }

    public ObservableList<VaccineProgress> getVaccinationProgress(int vaccineeID) throws Exception {
        ObservableList<VaccineProgress> progressData = FXCollections.observableArrayList();

        // Get vaccination data as a Map from Vaccinee
        Map<String, int[]> vaccineData = vaccinee.getVaccinationProgress(vaccineeID);

        // Convert the data into VaccineProgress objects
        vaccineData.forEach((vaccineName, progress) -> {
            int dosesDone = progress[0];
            int dosesPending = progress[1];
            progressData.add(new VaccineProgress(vaccineName, dosesDone, dosesPending));
        });

        return progressData;
    }

    public ObservableList<VaccineCenterData> getHealthWorkerVaccinationData(int healthWorkerId) {
        //HealthWorker healthWorker = new HealthWorker();

        List<VaccineCenterData> dataList = healthworker.getVaccinationData();
        return FXCollections.observableArrayList(dataList);
    }

    public String generateVaccinationReport(int vaccineeID) throws Exception {
        return vaccinee.generateVaccinationReport(vaccineeID);
    }

    public ObservableList<ReportData> getHealthWorkerVaccinationData() {
        ArrayList<ReportData> dataList = moh.generateReport();
        return FXCollections.observableArrayList(dataList);
    }

    public List<String> getVaccineNames() {
        //   List<String> vaccines = new ArrayList<>();
        MinistryOfHealthDAO obj=new MinistryOfHealthDAO();
        return obj.getVaccineNames();
    }

    // Fetch center names from the database
    public List<String> getCenterNames() {
        MinistryOfHealthDAO obj=new MinistryOfHealthDAO();
        return obj.getCenterNames();
    }

    public List<UserData> getVaccineSideEffectsReport() {
        return moh.getVaccineSideEffects();
    }

    public List<String> fetchVaccineNames() throws SQLException {
        vaccinee = new Vaccinee();
        return vaccinee.getVaccines();
    }

    public List<String> fetchSymptoms() {
        return vaccinee.getSymptoms();
    }

    public List<String> fetchCenterNames() {
        return vaccinee.getCenters();
    }

    public void reportVaccineSideEffect(int vaccineID, int vaccineeID, String symptom, String additionalDetails) {
        vaccinee.reportSideEffect(vaccineID, vaccineeID, symptom, additionalDetails);
    }

    // deactivate Vaccinee account
    public boolean deleteVaccinee(Vaccinee vaccinee){
        return vaccinee.deleteUser(vaccinee);
    }

    // This function gets the list of center with their name and address
    public List<String> getCenters(){
        center = new Center();
        List<String> center_list = center.getCenterList();
        return center_list;
    }

    // This function gets list of vaccinees who missed their appointment
    public List<String> getVaccineeList() throws SQLException {
        if(vaccinee == null){
            vaccinee = new Vaccinee();
        }
        return vaccinee.gettingVaccineeList();
    }

    // this is update function for the Vaccinee
    public boolean[] updateHealthworker(HealthWorker healthworker){
        boolean[] answer = healthworker.validateUser(healthworker,2);

        boolean isCorrect = true;
        for(boolean value: answer){
            if(!value){
                isCorrect = false;
            }
        }
        if(isCorrect){
            if (healthworker.updateUser(healthworker)){
                return answer; // This means that updating was done successfully
            }
        }
        return answer;
    }

    // deactivate Healthworker account
    public boolean deleteAccount(HealthWorker healthworker){
        return healthworker.deleteUser(healthworker);
    }

    // This function gets the list of center with their name and address
    public List<String> getVaccineList(int vaccineeID){
        vaccine = new Vaccine();
        List<String> vaccineList = vaccine.getVaccineList(vaccineeID);
        return vaccineList;
    }

    // This function gets the list of center with their name and address
    public List<String> getVaccineList(){
        vaccine = new Vaccine();
        List<String> vaccineList = vaccine.getVaccineList();
        return vaccineList;
    }

    // this gets all the apppointments based on the center and the vaccine
    public List<Appointment> getAppointments(Center center, int vaccineID){
        appointment = new backend.Appointment();
        return appointment.getAvaliableAppointments(center, vaccineID);
    }

    // Log in an appointment
    public boolean enterAppointment(Appointment apt, Vaccinee vaccinee){

        boolean result = false;
        appointment = appointment.getAppointment(apt.getAppointmentID());
        if(appointment.bookAppointment()){
            result = appointment.addBookedAppointment(appointment, vaccinee);
        }
        return result;
    }

    public Center getCenter(){
        return this.center;
    }

    public Center getCenter(int centerID){
        return center.getCenter(centerID);
    }

    public List<VaccineeData> getVaccineeDataList(int centerID, int vaccineID) throws SQLException {
        vaccinee = new Vaccinee();
        return vaccinee.gettingVaccineeDataList(centerID,vaccineID);
    }

    public boolean addCompletedAppointment (int appointmentID, int vaccineeID){
        return vaccinee.markCompletedAppointment(appointmentID, vaccineeID);
    }

    public boolean reduceDose(int vaccineeID, int vaccineID){
        return vaccinee.updateDose(vaccineeID, vaccineID);
    }

    public boolean addVisitedVaccinee(int vaccineeID, int centerID, int appointmentID){
        return center.logVisitedVaccinee(centerID,vaccineeID,appointmentID);
    }

    public boolean filterMissedAppointment(int centerID, int vaccineID) throws SQLException {
        vaccinee = new Vaccinee();
        return vaccinee.removeMissedAppointment(centerID, vaccineID);
    }

    public List<Appointment> getAppointmentList(int vaccineeID){
        appointment = new backend.Appointment();
        return appointment.getPersonalAppointments(vaccineeID);
    }

    public boolean removeAppointment(int appointmentID){
        return appointment.removeBookedAppointment(appointmentID);
    }

    public int getAppointmentVaccinee(int appointmentID) throws SQLException {
        vaccinee = new Vaccinee();
        return vaccinee.gettingVaccineefromAppointment(appointmentID);
    }

    public boolean addChildVaccineSchedule(Vaccinee vaccinee) throws SQLException {
        return vaccinee.addchildSchedule(vaccinee);
    }

}
