package backend;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VaccineDAO {

    // Connection Strings here! ---------------------------

    // This is Wania's
    protected static final String JDBC_URL = "jdbc:sqlserver://ENVIOUS\\SQLEXPRESS:1433;databaseName=VaccinationSystem;integratedSecurity=true;encrypt=true;trustServerCertificate=true";
    // This is Emaan's

    // This is Nabeeha's (bebo)
    // protected static final String JDBC_URL = "jdbc:sqlserver://DESKTOP-J49GPGC\\SQLEXPRESS;databaseName=VaccinationSystem;integratedSecurity=true;encrypt=false;";

    // -------------------------------------------------------------------------

    public VaccineDAO(){}

    // ALL THE DATABSE WORK BELOW

    public List<String> create_VaccineList(int vaccineeID){

        Connection connection = null;
        List<String> vaccineList = new ArrayList<>();

        try{
            connection = DriverManager.getConnection(JDBC_URL);

            String query = "select V.vaccineName, V.vaccineID from Vaccine V inner join Vaccinee_VaccineSchedule VS on V.vaccineID = VS.vaccineID where VS.vaccineeID = ? and VS.doses_needed > 0;";

            PreparedStatement execute_query = connection.prepareStatement(query);

            execute_query.setInt(1,vaccineeID);

            ResultSet result = execute_query.executeQuery();

            while(result.next()){
                vaccineList.add(result.getString("vaccineID") + ", " + result.getString("vaccineName"));
            }

        }catch (SQLException e){
            e.printStackTrace();
        }

        return vaccineList;
    }

    public List<String> create_VaccineList(){

        Connection connection = null;
        List<String> vaccineList = new ArrayList<>();

        try{
            connection = DriverManager.getConnection(JDBC_URL);

            String query = "select vaccineName, vaccineID from Vaccine;";

            PreparedStatement execute_query = connection.prepareStatement(query);

            ResultSet result = execute_query.executeQuery();

            while(result.next()){
                vaccineList.add(result.getString("vaccineID") + ", " + result.getString("vaccineName"));
            }

        }catch (SQLException e){
            e.printStackTrace();
        }

        return vaccineList;
    }

    // gets the object of Vaccine
    public Vaccine gettingVaccine(int vaccineID){

        Connection connection = null;
        Vaccine vaccine = new Vaccine();

        try{
            connection = DriverManager.getConnection(JDBC_URL);

            String query = "select * from Vaccine where vaccineID = ?";

            PreparedStatement execute_query = connection.prepareStatement(query);

            execute_query.setInt(1,vaccineID);

            ResultSet result = execute_query.executeQuery();

            while(result.next()){
                vaccine.setVaccineID(result.getInt("vaccineID"));
                vaccine.setVaccineName(result.getString("vaccineName"));
                vaccine.setProdCompany(result.getString("prodCompany"));
                vaccine.setProdCountry(result.getString("prodCountry"));
                vaccine.setVaccineInfo(result.getString("vaccineInfo"));
            }


        }catch (SQLException e){
            e.printStackTrace();
        }

        return vaccine;
    }

}
