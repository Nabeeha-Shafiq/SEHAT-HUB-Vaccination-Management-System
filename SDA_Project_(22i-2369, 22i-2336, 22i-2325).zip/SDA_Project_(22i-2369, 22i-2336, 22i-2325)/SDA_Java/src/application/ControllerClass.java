package application;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.scene.Parent;
import java.io.IOException;

public class ControllerClass
{
    @FXML
    private Button vaccineeButton;
    @FXML
    private Button healthWorkerButton;
    @FXML
    private Button ministryButton;
    
    @FXML
    public void initialize()
    {
        vaccineeButton.setOnAction(event -> loadPage("VaccineePage.fxml"));
        healthWorkerButton.setOnAction(event -> loadPage("HealthWorkerPage.fxml"));
        ministryButton.setOnAction(event -> loadPage("MinistryPage.fxml"));
    }

    private void loadPage(String fxmlFile)
    {
        // This is Vaccinee page linked up
        try
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();

            Stage stage = (Stage) vaccineeButton.getScene().getWindow();
           
            stage.setScene(new Scene(root));
            stage.show();
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        }
    }
}
