package application;

import backend.SehatHUB;
import backend.Vaccinee;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import javafx.stage.Popup;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.layout.StackPane;
import javafx.util.Duration;

import java.io.IOException;
import java.sql.SQLException;

public class VaccineeHomePageController 
{
    // referenced to SEHATHUB
    private SehatHUB sehatHUB;

    @FXML
    private Button manageAccount;
    @FXML
    private Button selectAppointment;
    @FXML
    private Button trackProgress;
    @FXML
    private Button reportSideeffects;
    @FXML
    private Button syncAccount;
    @FXML
    private Button userManuel;
    @FXML
    private Button backButton;
    @FXML
    private ImageView bellIcon;
    @FXML
    private TextArea showAppointmentsBox;
    @FXML
    private Text careText; 

    private Popup notificationPopup; 

    @FXML
    public void initialize()
    {
        
        manageAccount.setOnAction(event -> loadPage("VaccineeManageAccountPage.fxml",this.sehatHUB));
        selectAppointment.setOnAction(event -> loadPage("VaccineeSelectAppointmentPage.fxml",this.sehatHUB));
        trackProgress.setOnAction(event -> loadPage("VaccineeTrackProgressPage.fxml",this.sehatHUB));
        reportSideeffects.setOnAction(event -> loadPage("VaccineReportSideEffectsPage.fxml",this.sehatHUB));
        syncAccount.setOnAction(event -> loadPage("VaccineSyncAccountPage.fxml", this.sehatHUB));
        userManuel.setOnAction(event -> loadPage("VaccineeUserManuelPage.fxml"));
        backButton.setOnAction(event -> loadPage("VaccineePage.fxml"));
        bellIcon.setOnMouseClicked(event -> toggleNotifications());

        loadAppointments(); // loads pending appointment text on home page

        sehatHUB = new SehatHUB();

        displayHealthcareMessage("#Stay safe and healthy! Vaccination protects you and your loved ones......");
        //displayHealthcareMessage(");

    }

    public void setSehatHUB(SehatHUB sehathub){
        this.sehatHUB = sehathub;
    }

    private void loadPage(String fxmlFile, SehatHUB sehathub)
    {
        try
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();

            Object controller = loader.getController();
            // This is for Manage Vaccinee Controller
            if(controller instanceof VaccineeManageAccountController){
                ((VaccineeManageAccountController) controller).setSehatHUB(sehathub);
            }
            if(controller instanceof VaccineeSyncAccountController){
                ((VaccineeSyncAccountController) controller).setSehatHUB(sehathub);
            }
            if(controller instanceof VaccineeSelectAppointmentController){
                ((VaccineeSelectAppointmentController) controller).setSehatHUB(sehathub);
            }
            if(controller instanceof VaccineeTrackProgressController){
                ((VaccineeTrackProgressController) controller).setSehatHUB(sehathub);
            }
            if(controller instanceof VaccineReportSideEffectsController){
                ((VaccineReportSideEffectsController) controller).setSehatHub(sehathub);
            }

            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    private void loadPage(String fxmlFile)
    {
        try
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();

            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    private void toggleNotifications() {

        if (notificationPopup == null) {
            notificationPopup = new Popup();

            TextArea notifications = new TextArea();
            notifications.setWrapText(true);
            notifications.setEditable(false);
            notifications.setPrefSize(200, 150);

            Button closeButton = new Button("X");
            closeButton.setStyle("-fx-background-color: transparent; -fx-text-fill: red; -fx-font-size: 16px; -fx-padding: 0;");
            closeButton.setOnAction(event -> notificationPopup.hide());

            StackPane.setAlignment(closeButton, javafx.geometry.Pos.TOP_RIGHT);
            StackPane closeButtonContainer = new StackPane(closeButton);
            StackPane popupContent = new StackPane(notifications, closeButtonContainer);
            notificationPopup.getContent().add(popupContent);
        }

        new Thread(() -> {
            StringBuilder notificationText = new StringBuilder();
            // Append due vaccines and appointments
            sehatHUB.getDueVaccines(sehatHUB.getVaccinee().getUserID()).forEach(vaccine -> notificationText.append("Vaccine due: ").append(vaccine.getVaccineName()).append("\n"));
            sehatHUB.getDueAppointments(sehatHUB.getVaccinee().getUserID()).forEach(appointment -> notificationText.append("Appointment due: ").append(appointment.getAppointmentDate()).append("\n"));

            // Pull and append system-wide notifications
            String systemNotifications = null;
            try {
                systemNotifications = sehatHUB.pullSystemNotification();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
            if (!systemNotifications.isEmpty()) {
                notificationText.append("\nSystem Notifications:\n").append(systemNotifications);
            }

            Platform.runLater(() -> {
                TextArea textArea = (TextArea) ((StackPane) notificationPopup.getContent().get(0)).getChildren().get(0);
                textArea.setText(notificationText.toString());

                if (notificationPopup.isShowing()) {
                    notificationPopup.hide();
                } else {
                    notificationPopup.show(bellIcon, bellIcon.getScene().getWindow().getX() + bellIcon.getLayoutX(), bellIcon.getScene().getWindow().getY() + bellIcon.getLayoutY() + 30);
                }
            });
        }).start();
    }

    // WANIEES REPLACE THE LOGIC FOR THE DATA TO SHOW IN APPOINTMENT BOX HERE , CALL FUNCTION OR WHATEVER

    private void loadAppointments()
    {
        // create Strings for the appointment of the Child



        //showAppointmentsBox.setText(appointments);
    }

    private void displayHealthcareMessage(String message)
    {
        careText.setText(""); 
        final int[] charIndex = {0};

        Timeline timeline = new Timeline(new KeyFrame(Duration.millis(100), event ->
        {
            if (charIndex[0] < message.length())
            {
                careText.setText(careText.getText() + message.charAt(charIndex[0]));
                charIndex[0]++;
            }
        }));

        // restart the animation
        timeline.setCycleCount(message.length());
        timeline.setOnFinished(event -> displayHealthcareMessage(message)); // restart the animation

        timeline.play();
    }
}
