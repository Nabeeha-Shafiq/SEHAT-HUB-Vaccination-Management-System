// This is UserInterface (Controller Class):
// Sending Notifications to User
// Side Effects
// UI Manager

package application;
import backend.Vaccinee;
import java.util.ArrayList;

public class UserInterface {

    // Attributes -------------------------------------------------

    // To be discussed later
    private ArrayList<Vaccinee> vaccineeObject;

    // Methods ----------------------------------------------------

    // contructor
    public UserInterface(ArrayList<Vaccinee> vaccineeObject) {
        this.vaccineeObject = vaccineeObject;
    }

    // getter setters
    public ArrayList<Vaccinee> getVaccineeObject() {
        return vaccineeObject;
    }

    public void setVaccineeObject(ArrayList<Vaccinee> vaccineeObject) {
        this.vaccineeObject = vaccineeObject;
    }



}
