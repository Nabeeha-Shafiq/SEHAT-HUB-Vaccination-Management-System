package application;

import backend.SehatHUB;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.Parent;
import javafx.stage.Stage;
import java.io.IOException;

public class HealthWorkerPageController 
{
    // referenced to SEHATHUB
    private SehatHUB sehatHUB;

    @FXML
    private Button loginButton;

    @FXML
    private Button signupButton;

    @FXML
    private Button backButton;

    @FXML
    private TextField Husername;

    @FXML
    private PasswordField Hpassword;

    @FXML
    private Label usernameFeedbackLabel;

    @FXML
    private Label passwordFeedbackLabel;

    @FXML
    public void initialize()
    {
        signupButton.setOnAction(event -> loadPage("HealthWorkerSignUpPage.fxml"));
        backButton.setOnAction(event -> loadPage("mainpage.fxml"));
        //loginButton.setOnAction(event -> loadPage("HealthWorkerHomePage.fxml")); // remove this and uncomment below code
        loginButton.setOnAction(event -> validateAndLogin());

        // Initialize the sehathub reference
        sehatHUB = new SehatHUB();
    }

    public void setSehatHUB(SehatHUB sehathub){
        this.sehatHUB = sehathub;
    }

    private void validateAndLogin() {
        // call validation function here to check
        String username = Husername.getText();
        String password = Hpassword.getText();

        // This will give us the result of the check, instead of bringing the confidential data to the frontend controller
        int result = sehatHUB.Login_Healthworker(username,password);

        // The username exists!
        if (result == 3 || result == 1) {
            usernameFeedbackLabel.setText("Correct");
            usernameFeedbackLabel.setStyle("-fx-text-fill: green;");
        }
        // The username does not exist!
        else if (result == 2){
            usernameFeedbackLabel.setText("Incorrect username");
            usernameFeedbackLabel.setStyle("-fx-text-fill: red;");
        }

        // The password is correct!
        if (result == 3) {
            passwordFeedbackLabel.setText("Correct");
            passwordFeedbackLabel.setStyle("-fx-text-fill: green;");
        }
        // The password is incorrect!
        else if (result == 1){
            passwordFeedbackLabel.setText("Incorrect password");
            passwordFeedbackLabel.setStyle("-fx-text-fill: red;");
        }

        // The username and password both are correct!
        if (result == 3) {
            loadPage("HealthWorkerHomePage.fxml", this.sehatHUB);
        }
    }

    private void loadPage(String fxmlFile, SehatHUB sehathub) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();

            Object controller = loader.getController();
            if(controller instanceof HealthWorkerHomepageController){
                ((HealthWorkerHomepageController) controller).setSehatHUB(sehathub);
            }

            Stage stage = (Stage) loginButton.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadPage(String fxmlFile) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();

            Stage stage = (Stage) loginButton.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
