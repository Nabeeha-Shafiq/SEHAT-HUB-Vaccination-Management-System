package application;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class NotificationManager
{

    private static NotificationManager instance;
    private final ObservableList<String> healthWorkerNotifications;
    private final ObservableList<String> vaccineeNotifications;

   
    private NotificationManager() 
    {
        healthWorkerNotifications = FXCollections.observableArrayList();
        vaccineeNotifications = FXCollections.observableArrayList();
    }

   
    public static NotificationManager getInstance()
    {
        if (instance == null) 
        {
            instance = new NotificationManager();
        }
        return instance;
    }

    public ObservableList<String> getHealthWorkerNotifications()
    {
        return healthWorkerNotifications;
    }

    public ObservableList<String> getVaccineeNotifications() 
    {
        return vaccineeNotifications;
    }

    

    public void addVaccineeNotification(String message)
    {
        vaccineeNotifications.add(message);
    }
    public void addVaccineeNotification(String message, String vaccineId, String username)
    {
        
        System.out.println("Sending notification:");
        System.out.println("Message: " + message);
        System.out.println("Vaccine ID: " + vaccineId);
        System.out.println("Username: " + username);
        
        // Add your logic to store or send the notification
        // For example, you could save this information to a database or send it to the recipient
    }

  
    public void addHealthWorkerNotification(String message) 
    {
       
        System.out.println("Health Worker Notification: " + message);
        
    }
}
