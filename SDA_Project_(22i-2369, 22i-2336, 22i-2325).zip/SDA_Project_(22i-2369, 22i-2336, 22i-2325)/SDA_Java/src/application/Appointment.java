package application;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Appointment
{
    private SimpleIntegerProperty appointmentID;
    private SimpleStringProperty date;
    private SimpleStringProperty time;
    private SimpleStringProperty availability;

    //  initialize Appointment object
    public Appointment(){
        this.appointmentID = new SimpleIntegerProperty();
        this.date = new SimpleStringProperty();
        this.time = new SimpleStringProperty();
        this.availability = new SimpleStringProperty();
    }

    public Appointment(int appointmentID, String date, String time, String availability)
    {
        this.appointmentID = new SimpleIntegerProperty(appointmentID);
        this.date = new SimpleStringProperty(date);
        this.time = new SimpleStringProperty(time);
        this.availability = new SimpleStringProperty(availability);
    }

    public Integer getAppointmentID(){return appointmentID.get();};

    public void setAvailability(String availability) {
        this.availability.set(availability);
    }

    public void setDate(String date) {
        this.date.set(date);
    }

    public void setTime(String time) {
        this.time.set(time);
    }

    public void setAppointmentID(int appointmentID) {
        this.appointmentID.set(appointmentID);
    }

    public SimpleIntegerProperty IDProperty() {return appointmentID;};

   
    public String getDate()
    {
        return date.get();
    }

    public SimpleStringProperty dateProperty()
    {
        return date;
    }

    
    public String getTime() 
    {
        return time.get();
    }

    public SimpleStringProperty timeProperty()
    {
        return time;
    }

   
    public String getAvailability()
    {
        return availability.get();
    }

    public SimpleStringProperty availabilityProperty()
    {
        return availability;
    }
}
