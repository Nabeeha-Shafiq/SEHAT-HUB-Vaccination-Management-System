package application;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.FileWriter;
import java.io.IOException;

import backend.SehatHUB;

public class MinistryRecieveSideEffectsController
{

    @FXML
    private TableView<UserData> reportTable;

    @FXML
    private TableColumn<UserData, String> usernameColumn;

    @FXML
    private TableColumn<UserData, String> userIdColumn;

    @FXML
    private TableColumn<UserData, String> vaccineColumn;

    @FXML
    private TableColumn<UserData, String> centerColumn;

    @FXML
    private TableColumn<UserData, String> symptomColumn;

    @FXML
    private TableColumn<UserData, String> additionalDetailsColumn;

    @FXML
    private Button generateReportButton;

    @FXML
    private Button backButton;
    private SehatHUB sehatHub;

    private ObservableList<UserData> tableData;

    @FXML
    public void initialize()
    {
        // taking getter setter from userData.java file
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));
        userIdColumn.setCellValueFactory(new PropertyValueFactory<>("userId"));
        vaccineColumn.setCellValueFactory(new PropertyValueFactory<>("vaccine"));
        centerColumn.setCellValueFactory(new PropertyValueFactory<>("center"));
        symptomColumn.setCellValueFactory(new PropertyValueFactory<>("symptom"));
        additionalDetailsColumn.setCellValueFactory(new PropertyValueFactory<>("additionalDetail"));
//
//
//        tableData = FXCollections.observableArrayList(
//                new UserData("john_doe", "001", "Pfizer", "Center A", "Fever", "Mild fever"),
//                new UserData("jane_smith", "002", "Moderna", "Center B", "Nausea", "Nausea post-vaccine")
//        );
        sehatHub=new SehatHUB();
        tableData = FXCollections.observableArrayList(sehatHub.getVaccineSideEffectsReport());
        reportTable.setItems(tableData);
    }

    @FXML
    public void handleGenerateReport()
    {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save CSV Report");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV Files", "*.csv"));

        Stage stage = (Stage) generateReportButton.getScene().getWindow();
        var file = fileChooser.showSaveDialog(stage);

        if (file != null)
        {
            try (FileWriter writer = new FileWriter(file))
            {
                writer.write("Username,UserID,Vaccine,Center,Symptom,Additional Detail\n");
                for (UserData data : tableData)
                {
                    writer.write(data.toCSV() + "\n");
                }
                showAlert("Report Generated", "CSV report has been successfully generated.");
            } catch (IOException e)
            {
                showAlert("Error", "Failed to generate the report.");
                e.printStackTrace();
            }
        }
    }


    @FXML
    public void handleBackButton()
    {
        try
        {

            FXMLLoader loader = new FXMLLoader(getClass().getResource("MinistryHomePage.fxml"));
            Parent ministryHomePage = loader.load();
            Stage stage = (Stage) backButton.getScene().getWindow();
            Scene scene = new Scene(ministryHomePage);
            stage.setScene(scene);
            stage.setTitle("Ministry Home Page");
            stage.show();
        }
        catch (IOException e)
        {
            e.printStackTrace();
            showAlert("Error", "Failed to load the Ministry Home Page.");
        }
    }



    private void showAlert(String title, String content)
    {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
