package application;

public class AppointmentList {
    private Appointment appointmentdetails;
    private int vaccineeID;

    public AppointmentList(){}

    public AppointmentList(Appointment appt, int vaccineeID){
        this.appointmentdetails = appt;
        this.vaccineeID = vaccineeID;
    }

    public void setAppointmentdetails(Appointment appointmentdetails) {
        this.appointmentdetails = appointmentdetails;
    }

    public int getVaccineeID() {
        return vaccineeID;
    }

    public Appointment getAppointmentdetails() {
        return appointmentdetails;
    }

    public void setVaccineeID(int vaccineeID) {
        this.vaccineeID = vaccineeID;
    }
}
