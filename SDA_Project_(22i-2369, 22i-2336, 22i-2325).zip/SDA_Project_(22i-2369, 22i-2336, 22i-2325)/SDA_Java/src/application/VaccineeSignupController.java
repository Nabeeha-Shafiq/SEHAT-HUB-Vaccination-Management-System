package application;

import backend.SehatHUB;
import backend.Vaccinee;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.Parent;
import java.io.IOException;
import java.sql.SQLException;

public class VaccineeSignupController
{
    // referenced to SEHATHUB
    private SehatHUB sehatHUB;
    private int ischild;

    @FXML
    private ComboBox<String> GenderComboBox;
    @FXML
    private Button backButton;
    @FXML
    private Button createAccount;
    @FXML
    private TextField fname, lname, email, username, userPhoneNo;
    @FXML
    private PasswordField userPassword;
    @FXML
    private DatePicker dob;
    @FXML
    private Label FnameLabel, LnameLabel, DobLabel, GenderLabel, EmailLabel, UsernameLabel, passwordLabel, PhoneLabel;

    @FXML
    public void initialize()
    {
        GenderComboBox.getItems().addAll("Male", "Female", "Others");

        // Back button
        backButton.setOnAction(event -> loadPage("vaccineePage.fxml"));

        // Create account button
        createAccount.setOnAction(event -> {
            try {
                validateCheck();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        });

        sehatHUB = new SehatHUB();
    }

    public void setSehatHUB(SehatHUB sehathub){
        this.sehatHUB = sehathub;
    }

    public void setchild(int child){
        this.ischild = child;
    }

    private void validateCheck() throws SQLException {
        boolean valid = true;
        Vaccinee child = new Vaccinee();

        if(sehatHUB == null) {
            // create instance of vaccinee for checking
            sehatHUB.addVaccinee(username.getText(), userPassword.getText(), fname.getText(), lname.getText(), dob.getValue(), GenderComboBox.getValue(), userPhoneNo.getText(), email.getText());
        }else{
            child = new Vaccinee(username.getText(), userPassword.getText(), fname.getText(), lname.getText(), dob.getValue(), GenderComboBox.getValue(), userPhoneNo.getText(), email.getText());
        }

        boolean[] answer;

        if(ischild == 1) {
            answer = sehatHUB.SignUp_Vaccinee(sehatHUB.getVaccinee(),child, ischild);
            // add the vaccine schedule for the child
            sehatHUB.addChildVaccineSchedule(sehatHUB.getVaccinee());

        }else{
            answer = sehatHUB.SignUp_Vaccinee(sehatHUB.getVaccinee());
        }

        // First Name
        if (fname.getText().isEmpty())
        {
            FnameLabel.setText("Field Required");
            FnameLabel.setTextFill(javafx.scene.paint.Color.RED);
            valid = false;
        } 
        else
        {
            // Validation check
            if(answer[0]){
                FnameLabel.setText("✔");
                FnameLabel.setTextFill(javafx.scene.paint.Color.GREEN);
            }else{
                FnameLabel.setText("Incorrect Format");
                FnameLabel.setTextFill(javafx.scene.paint.Color.RED);
                valid = false;
            }
        }

        // Last Name
        if (lname.getText().isEmpty())
        {
            LnameLabel.setText("Field Required");
            LnameLabel.setTextFill(javafx.scene.paint.Color.RED);
            valid = false;
        } 
        else
        {
            // Validation check
            if(answer[1]){
                LnameLabel.setText("✔");
                LnameLabel.setTextFill(javafx.scene.paint.Color.GREEN);
            }else{
                LnameLabel.setText("Incorrect Format");
                LnameLabel.setTextFill(javafx.scene.paint.Color.RED);
                valid = false;
            }
        }

        // Date of Birth
        if (dob.getValue() == null) 
        {
            DobLabel.setText("Field Required");
            DobLabel.setTextFill(javafx.scene.paint.Color.RED);
            valid = false;
        } 
        else
        {
            // Validation check
            if(answer[5]){
                DobLabel.setText("✔");
                DobLabel.setTextFill(javafx.scene.paint.Color.GREEN);
            }else{
                if(ischild == 1){
                    DobLabel.setText("DOB must not be greater");
                    DobLabel.setTextFill(javafx.scene.paint.Color.RED);
                    valid = false;
                }else {
                    DobLabel.setText("Must be atleast 18 years old");
                    DobLabel.setTextFill(javafx.scene.paint.Color.RED);
                    valid = false;
                }
            }
        }

        // Gender
        if (GenderComboBox.getValue() == null) 
        {
            GenderLabel.setText("Field Required");
            GenderLabel.setTextFill(javafx.scene.paint.Color.RED);
            valid = false;
        } 
        else 
        {
            // Validation Check
            if(answer[3]){
                GenderLabel.setText("✔");
                GenderLabel.setTextFill(javafx.scene.paint.Color.GREEN);
            }else{
                GenderLabel.setText("Incorrect Option");
                GenderLabel.setTextFill(javafx.scene.paint.Color.RED);
                valid = false;
            }
        }

        // Email
        if (email.getText().isEmpty())
        {
            EmailLabel.setText("Field Required");
            EmailLabel.setTextFill(javafx.scene.paint.Color.RED);
            valid = false;
        } 
        else 
        {
            // Validation check
            if(answer[7]){
                EmailLabel.setText("✔");
                EmailLabel.setTextFill(javafx.scene.paint.Color.GREEN);
            }else{
                EmailLabel.setText("Incorrect Format");
                EmailLabel.setTextFill(javafx.scene.paint.Color.RED);
                valid = false;
            }
        }

        // Phone Number
        if (userPhoneNo.getText().isEmpty())
        {
            PhoneLabel.setText("Field Required");
            PhoneLabel.setTextFill(Color.RED);
            valid = false;
        }
        else
        {
            // Validation check
            if(answer[4]){
                PhoneLabel.setText("✔");
                PhoneLabel.setTextFill(Color.GREEN);
            }else{
                PhoneLabel.setText("Invalid Phone Number");
                PhoneLabel.setTextFill(Color.RED);
                valid = false;
            }
        }

        //Username
        if (username.getText().isEmpty())
        {
            UsernameLabel.setText("Field Required");
            UsernameLabel.setTextFill(javafx.scene.paint.Color.RED);
            valid = false;
        } 
        else 
        {
            // Validation check
            if(answer[2]){
                UsernameLabel.setText("✔");
                UsernameLabel.setTextFill(javafx.scene.paint.Color.GREEN);
            }else{
                UsernameLabel.setText("Incorrect Format");
                UsernameLabel.setTextFill(javafx.scene.paint.Color.RED);
                valid = false;
            }
            if(!answer[8]){
                UsernameLabel.setText("Username is taken");
                UsernameLabel.setTextFill(javafx.scene.paint.Color.RED);
                valid = false;
            }
        }

        // Password
        if (userPassword.getText().isEmpty())
        {
            passwordLabel.setText("Field Required");
            passwordLabel.setTextFill(javafx.scene.paint.Color.RED);
            valid = false;
        } 
        else 
        {
            // Validation check
            if(answer[6]){
                passwordLabel.setText("✔");
                passwordLabel.setTextFill(javafx.scene.paint.Color.GREEN);
            }else{
                passwordLabel.setText("Must be 5 digits long");
                passwordLabel.setTextFill(javafx.scene.paint.Color.RED);
                valid = false;
            }
        }

        //  all fields are valid proceed with account creation
        if (valid) {
            loadPage("vaccineePage.fxml");
        }
    }

    private void loadPage(String fxmlFile) 
    {
        try
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();
            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        }
    }
}
