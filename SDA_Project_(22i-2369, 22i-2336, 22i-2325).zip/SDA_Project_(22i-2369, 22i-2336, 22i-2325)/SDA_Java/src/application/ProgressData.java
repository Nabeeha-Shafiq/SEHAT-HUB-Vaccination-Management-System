package application;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class ProgressData
{
    private final StringProperty centerName;
    private final StringProperty healthWorker;
    private final StringProperty vaccineeName;
    private final StringProperty vaccineeID;
    private final StringProperty doseStatus;
    private final StringProperty dateTime;
    private final int age;

    public ProgressData(String centerName, String healthWorker, String vaccineeName, String vaccineeID, String doseStatus, String dateTime, int age) {
        this.centerName = new SimpleStringProperty(centerName);
        this.healthWorker = new SimpleStringProperty(healthWorker);
        this.vaccineeName = new SimpleStringProperty(vaccineeName);
        this.vaccineeID = new SimpleStringProperty(vaccineeID);
        this.doseStatus = new SimpleStringProperty(doseStatus);
        this.dateTime = new SimpleStringProperty(dateTime);
        this.age = age;
    }

   
    public StringProperty centerNameProperty()
    {
        return centerName;
    }

    public StringProperty healthWorkerProperty() 
    {
        return healthWorker;
    }

    public StringProperty vaccineeNameProperty() 
    {
        return vaccineeName;
    }

    public StringProperty vaccineeIDProperty() 
    {
        return vaccineeID;
    }

    public StringProperty doseStatusProperty()
    {
        return doseStatus;
    }

    public StringProperty dateTimeProperty()
    {
        return dateTime;
    }

   
    public String getCenterName()
    {
        return centerName.get();
        
    }

    public String getHealthWorker() 
    {
        return healthWorker.get();
    }

    public String getVaccineeName()
    {
        return vaccineeName.get();
    }

    public String getVaccineeID()
    {
        return vaccineeID.get();
    }

    public String getDoseStatus() 
    {
        return doseStatus.get();
    }

    public String getDateTime()
    {
        return dateTime.get();
    }

    public int getAge()
    {
        return age;
    }

       public String toCSV()
       {
        return String.format("%s,%s,%s,%s,%s,%s,%d",
                centerName.get(), healthWorker.get(), vaccineeName.get(),
                vaccineeID.get(), doseStatus.get(), dateTime.get(), age);
    }
}
