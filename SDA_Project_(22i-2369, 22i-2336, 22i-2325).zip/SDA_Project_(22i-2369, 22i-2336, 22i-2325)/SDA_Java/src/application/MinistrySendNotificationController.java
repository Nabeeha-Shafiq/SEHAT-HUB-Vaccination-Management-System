package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextInputDialog;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.Optional;

import backend.MinistryOfHealthDAO;

public class MinistrySendNotificationController
{

    @FXML
    private Button sendNotifButton;

    @FXML
    private TextArea HealthWorkerNotifyBox;

    @FXML
    private TextArea VaccineNotifyBox;

    @FXML
    private TextArea VaccineNotifyAllBox;

    @FXML
    private Button backButton;

    private MinistryOfHealthDAO MOH=new MinistryOfHealthDAO();

    @FXML
    public void handleSendNotif(ActionEvent event)
    {
        String healthWorkerMessage = HealthWorkerNotifyBox.getText().trim();
        String vaccineeMessage = VaccineNotifyBox.getText().trim();
        String vaccineeMessageAll = VaccineNotifyAllBox.getText().trim();



        if (!vaccineeMessage.isEmpty())
        {
            //  vaccine ID and username
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Vaccine Details");
            dialog.setHeaderText("Please enter the Vaccine ID and Username");

            //  the vaccine ID from
            dialog.setContentText("Vaccine ID:");
            Optional<String> vaccineIdResult = dialog.showAndWait();

            // after user entered Vaccine ID, ask for username
            if (vaccineIdResult.isPresent() && !vaccineIdResult.get().trim().isEmpty())
            {
                String vaccineId = vaccineIdResult.get().trim();

                // Ask for username
                dialog.setContentText("Username:");
                Optional<String> usernameResult = dialog.showAndWait();

                //after username is entered, send the notification
                if (usernameResult.isPresent() && !usernameResult.get().trim().isEmpty())
                {
                    String username = usernameResult.get().trim();

                    // Process notification with vaccine ID and username
                    NotificationManager.getInstance().addVaccineeNotification(vaccineeMessage, vaccineId, username);
                    showAlert("Vaccinee Notification Sent", "Message sent to vaccinee with Vaccine ID: " + vaccineId + " and Username: " + username);
                }
                else
                {
                    showAlert("Error", "Username is required.");
                }
            }
            else
            {
                showAlert("Error", "Vaccine ID is required.");
            }
        }



        if (!healthWorkerMessage.isEmpty())
        {
            NotificationManager.getInstance().addHealthWorkerNotification(healthWorkerMessage);
            showAlert("Health Worker Notification Sent", "Message sent to health workers.");
        }


        if (!vaccineeMessageAll .isEmpty())
        {
            NotificationManager.getInstance().addVaccineeNotification(vaccineeMessageAll);
            MOH.pushSystemNotification(vaccineeMessageAll);
            showAlert("Vaccinee Notification Sent", "Message sent to All Vaccinees " );
        }



        HealthWorkerNotifyBox.clear();
        VaccineNotifyBox.clear();
        VaccineNotifyAllBox.clear();
    }

    @FXML
    public void handleBackButton(ActionEvent event) throws IOException
    {
        Stage stage = (Stage) backButton.getScene().getWindow();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/MinistryHomePage.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    private void showAlert(String title, String content)
    {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
