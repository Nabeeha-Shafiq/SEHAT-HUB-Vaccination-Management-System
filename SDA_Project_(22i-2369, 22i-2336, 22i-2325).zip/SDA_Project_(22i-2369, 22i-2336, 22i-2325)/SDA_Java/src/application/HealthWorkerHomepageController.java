package application;

import backend.SehatHUB;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import javafx.stage.Popup;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.awt.Label;
import java.sql.SQLException;

public class HealthWorkerHomepageController {

    // references to SehatHUB
    private SehatHUB sehatHUB;

    @FXML
    private Button manageAccount, makeAppointment, trackProgress, acceptAppointment, trainingManuel, backButton, viewAppointment;

    @FXML
    private ImageView bellIcon;

    @FXML
    private TextArea notificationBox;

    @FXML
    private Text careText;

    private Popup notificationPopup;

    @FXML
    public void initialize() 
    {
        sehatHUB  = new SehatHUB();

        manageAccount.setOnAction(event -> loadPage("HealthWorkerManageAccountPage.fxml", this.sehatHUB));
        makeAppointment.setOnAction(event -> loadPage("HealthWorkerMakeAppointmentPage.fxml", this.sehatHUB));
        trackProgress.setOnAction(event -> loadPage("HealthWorkerTrackProgressPage.fxml", this.sehatHUB));
        acceptAppointment.setOnAction(event -> loadPage("HealthWorkerAcceptAppointmentPage.fxml", this.sehatHUB));
        viewAppointment.setOnAction(event -> loadPage("HealthworkerViewAppointment.fxml",this.sehatHUB));
        trainingManuel.setOnAction(event -> loadPage("HealthWorkerTrainingManualPage.fxml"));
        backButton.setOnAction(event -> loadPage("HealthWorkerPage.fxml"));

        bellIcon.setOnMouseClicked(event -> toggleNotifications());

        displayHealthcareMessage("#Welcome to Health Worker Dashboard! Stay healthy and care for others...");
    }

    public void setSehatHUB(SehatHUB sehathub){
        this.sehatHUB = sehathub;
    }

    private void loadPage(String fxmlFile, SehatHUB sehathub)
    {
        try
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();

            Object controller = loader.getController();
            if(controller instanceof HealthWorkerManageAccountController){
                ((HealthWorkerManageAccountController) controller).setSehatHUB(sehathub);
            }
            if(controller instanceof HealthWorkerSelectAppointmentController){
                ((HealthWorkerSelectAppointmentController) controller).setSehatHUB(sehathub);
            }
            if(controller instanceof HealthWorkerAcceptAppointmentController){
                ((HealthWorkerAcceptAppointmentController) controller).setSehatHUB(sehathub);
            }
            if(controller instanceof HealthWorkerTrackProgressController){
                ((HealthWorkerTrackProgressController) controller).setSehatHUB(sehathub);
            }
            if(controller instanceof HealthWorkerViewAppointmentController){
                ((HealthWorkerViewAppointmentController) controller).setSehatHUB(sehathub);
            }

            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } 
        catch (IOException e)
        {
            e.printStackTrace();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private void loadPage(String fxmlFile)
    {
        try
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();

            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    private void toggleNotifications() {

        if (notificationPopup == null) {
            notificationPopup = new Popup();

            TextArea notifications = new TextArea();
            notifications.setWrapText(true);
            notifications.setEditable(false);
            notifications.setPrefSize(200, 150);

            Button closeButton = new Button("X");
            closeButton.setStyle("-fx-background-color: transparent; -fx-text-fill: red; -fx-font-size: 16px; -fx-padding: 0;");
            closeButton.setOnAction(event -> notificationPopup.hide());

            StackPane.setAlignment(closeButton, javafx.geometry.Pos.TOP_RIGHT);
            StackPane closeButtonContainer = new StackPane(closeButton);
            StackPane popupContent = new StackPane(notifications, closeButtonContainer);
            notificationPopup.getContent().add(popupContent);
        }

        new Thread(() -> {
            StringBuilder notificationText = new StringBuilder();
            // Append due vaccines and appointments
            //   dao.getDueVaccines(currentVaccineeID).forEach(vaccine -> notificationText.append("Vaccine due: ").append(vaccine.getVaccineName()).append("\n"));
            // dao.getDueAppointments(currentVaccineeID).forEach(appointment -> notificationText.append("Appointment due: ").append(appointment.getAppointmentDate()).append("\n"));

            // Pull and append system-wide notifications
            //String systemNotifications = dao.pullSystemNotificationHealthworker();
            String systemNotifications = null;
            try {
                systemNotifications = sehatHUB.pullSystemNotification();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
            if (!systemNotifications.isEmpty()) {
                notificationText.append("\nSystem Notifications:\n").append(systemNotifications);
            }

            Platform.runLater(() -> {
                TextArea textArea = (TextArea) ((StackPane) notificationPopup.getContent().get(0)).getChildren().get(0);
                textArea.setText(notificationText.toString());

                if (notificationPopup.isShowing()) {
                    notificationPopup.hide();
                } else {
                    notificationPopup.show(bellIcon, bellIcon.getScene().getWindow().getX() + bellIcon.getLayoutX(), bellIcon.getScene().getWindow().getY() + bellIcon.getLayoutY() + 30);
                }
            });
        }).start();
    }

    private void displayHealthcareMessage(String message)
    {
        careText.setText(""); 
        final int[] charIndex = {0};

        Timeline timeline = new Timeline(new KeyFrame(Duration.millis(100), event ->
        {
            if (charIndex[0] < message.length())
            {
                careText.setText(careText.getText() + message.charAt(charIndex[0]));
                charIndex[0]++;
            }
        }));
        
        timeline.setCycleCount(message.length());
        timeline.setOnFinished(event -> displayHealthcareMessage(message));

        timeline.play();
    }
}
