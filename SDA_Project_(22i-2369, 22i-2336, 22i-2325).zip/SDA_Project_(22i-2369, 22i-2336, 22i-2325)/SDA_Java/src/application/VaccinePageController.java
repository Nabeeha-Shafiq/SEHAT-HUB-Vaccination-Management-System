package application;
import backend.SehatHUB;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.Parent;
import javafx.stage.Stage;
import java.io.IOException;
import java.sql.SQLException;

public class VaccinePageController {
//add must
    // referenced to SEHATHUB
    private SehatHUB sehatHUB;

    @FXML
    private Button loginButton;

    @FXML
    private Button signupButton;

    @FXML
    private Button backButton;

    @FXML
    private TextField Vusername;

    @FXML
    private PasswordField Vpassword;

    @FXML
    private Label usernameFeedbackLabel;

    @FXML
    private Label passwordFeedbackLabel;

    @FXML
    public void initialize() 
    {
        signupButton.setOnAction(event -> loadPage("VaccineeSignupPage.fxml"));
        backButton.setOnAction(event -> loadPage("mainpage.fxml"));
        //loginButton.setOnAction(event ->loadPage("VaccineeHomePage.fxml"));   // remove this and uncomment below code
        loginButton.setOnAction(event -> {
            try {
                validateAndLogin();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        });

        sehatHUB = new SehatHUB();

        // Initialize the sehathub reference
        setSehatHUB(this.sehatHUB);
    }

    public void setSehatHUB(SehatHUB sehathub){
        this.sehatHUB = sehathub;
    }

    private void validateAndLogin() throws SQLException {  // call validation function here to check
        String username = Vusername.getText();
        String password = Vpassword.getText();

        // This will give us the result of the check, instead of bringing the confidential data to the frontend controller
        int result = sehatHUB.Login_Vaccinee(username,password);

        // The username exists!
        if (result == 3 || result == 1)
        {
            usernameFeedbackLabel.setText("Correct");
            usernameFeedbackLabel.setStyle("-fx-text-fill: green;");
        }
        // The username does not exist!
        else if(result == 2)
        {
            usernameFeedbackLabel.setText("Incorrect username");
            usernameFeedbackLabel.setStyle("-fx-text-fill: red;");
        }
        // The password is correct!
        if (result == 3)
        {
            passwordFeedbackLabel.setText("Correct");
            passwordFeedbackLabel.setStyle("-fx-text-fill: green;");
        }
        // The password is incorrect
        else if(result == 1)
        {
            passwordFeedbackLabel.setText("Incorrect password");
            passwordFeedbackLabel.setStyle("-fx-text-fill: red;");
        }

        // The username and password are both correct!
        if (result == 3)
        {
            loadPage("VaccineeHomePage.fxml", this.sehatHUB);
        } 
    }

    private void loadPage(String fxmlFile, SehatHUB sehathub)
    {
        try 
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();

            // from here, put this in every controller page .java
            Object controller = loader.getController();
            if (controller instanceof VaccineeHomePageController) {
                ((VaccineeHomePageController) controller).setSehatHUB(sehathub);
            }// to here

            Stage stage = (Stage) signupButton.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } 
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    private void loadPage(String fxmlFile)
    {
        try
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();
            Stage stage = (Stage) signupButton.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}
