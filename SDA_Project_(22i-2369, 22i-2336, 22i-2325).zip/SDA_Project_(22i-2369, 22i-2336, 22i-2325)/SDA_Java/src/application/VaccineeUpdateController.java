package application;

import backend.SehatHUB;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.Parent;
import java.io.IOException;
import java.sql.SQLException;

public class VaccineeUpdateController
{
    // referenced to SEHATHUB
    private SehatHUB sehatHUB;

    @FXML
    private ComboBox<String> GenderComboBox;
    @FXML
    private Button backButton;
    @FXML
    private Button updateAccount;
    @FXML
    private TextField fname, lname, email, userPhoneNo;
    @FXML
    private DatePicker dob;
    @FXML
    private Label FnameLabel, LnameLabel, DobLabel, GenderLabel, EmailLabel, PhoneLabel;

    @FXML
    public void initialize()
    {
        GenderComboBox.getItems().addAll("Male", "Female", "Others");

        // Back button
        backButton.setOnAction(event -> loadPage("vaccineePage.fxml"));

        this.sehatHUB = new SehatHUB();

        // Create account button
        updateAccount.setOnAction(event -> {
            try {
                validateCheck();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        });
    }

    public void setSehatHUB(SehatHUB sehathub) {
        this.sehatHUB = sehathub;
        setFields();
    }

    public void setFields(){
        fname.setText(sehatHUB.getVaccinee().getUserFName());
        lname.setText(sehatHUB.getVaccinee().getUserLName());
        dob.setValue(sehatHUB.getVaccinee().getUserDOB());
        GenderComboBox.setValue(sehatHUB.getVaccinee().getUserGender());
        userPhoneNo.setText(sehatHUB.getVaccinee().getUserPhone());
        email.setText(sehatHUB.getVaccinee().getUserEmail());
    }

    private void validateCheck() throws SQLException {
        boolean valid = true;

        // create instance of vaccinee for checking but adding it into the database
        sehatHUB.addVaccinee(sehatHUB.getVaccinee().getUserUsername(),sehatHUB.getVaccinee().getUserPassword(),fname.getText(),lname.getText(),dob.getValue(),GenderComboBox.getValue(),userPhoneNo.getText(),email.getText());
        boolean[] answer = sehatHUB.updateVaccine(sehatHUB.getVaccinee());

        // First Name
        if (fname.getText().isEmpty())
        {
            FnameLabel.setText("Field Required");
            FnameLabel.setTextFill(javafx.scene.paint.Color.RED);
            valid = false;
        } 
        else
        {
            // Validation check
            if(answer[0]){
                FnameLabel.setText("✔");
                FnameLabel.setTextFill(javafx.scene.paint.Color.GREEN);
            }else{
                FnameLabel.setText("Incorrect Format");
                FnameLabel.setTextFill(javafx.scene.paint.Color.RED);
                valid = false;
            }
        }

        // Last Name
        if (lname.getText().isEmpty())
        {
            LnameLabel.setText("Field Required");
            LnameLabel.setTextFill(javafx.scene.paint.Color.RED);
            valid = false;
        } 
        else
        {
            // Validation check
            if(answer[1]){
                LnameLabel.setText("✔");
                LnameLabel.setTextFill(javafx.scene.paint.Color.GREEN);
            }else{
                LnameLabel.setText("Incorrect Format");
                LnameLabel.setTextFill(javafx.scene.paint.Color.RED);
                valid = false;
            }
        }

        // Date of Birth
        if (dob.getValue() == null) 
        {
            DobLabel.setText("Field Required");
            DobLabel.setTextFill(javafx.scene.paint.Color.RED);
            valid = false;
        } 
        else
        {
            // Validation check
            if(answer[5]){
                DobLabel.setText("✔");
                DobLabel.setTextFill(javafx.scene.paint.Color.GREEN);
            }else{
                DobLabel.setText("DOB cannot be greater");
                DobLabel.setTextFill(javafx.scene.paint.Color.RED);
                valid = false;
            }
        }

        // Gender
        if (GenderComboBox.getValue() == null) 
        {
            GenderLabel.setText("Field Required");
            GenderLabel.setTextFill(javafx.scene.paint.Color.RED);
            valid = false;
        } 
        else 
        {
            // Validation Check
            if(answer[3]){
                GenderLabel.setText("✔");
                GenderLabel.setTextFill(javafx.scene.paint.Color.GREEN);
            }else{
                GenderLabel.setText("Incorrect Option");
                GenderLabel.setTextFill(javafx.scene.paint.Color.RED);
                valid = false;
            }
        }

        // Email
        if (email.getText().isEmpty())
        {
            EmailLabel.setText("Field Required");
            EmailLabel.setTextFill(javafx.scene.paint.Color.RED);
            valid = false;
        } 
        else 
        {
            // Validation check
            if(answer[7]){
                EmailLabel.setText("✔");
                EmailLabel.setTextFill(javafx.scene.paint.Color.GREEN);
            }else{
                EmailLabel.setText("Incorrect Format");
                EmailLabel.setTextFill(javafx.scene.paint.Color.RED);
                valid = false;
            }
        }

        // Phone Number
        if (userPhoneNo.getText().isEmpty())
        {
            PhoneLabel.setText("Field Required");
            PhoneLabel.setTextFill(Color.RED);
            valid = false;
        }
        else
        {
            // Validation check
            if(answer[4]){
                PhoneLabel.setText("✔");
                PhoneLabel.setTextFill(Color.GREEN);
            }else{
                PhoneLabel.setText("Invalid Phone Number");
                PhoneLabel.setTextFill(Color.RED);
                valid = false;
            }
        }

        //  all fields are valid proceed with account creation
        if (valid) {
            loadPage("vaccineePage.fxml");
        }
    }

    private void loadPage(String fxmlFile) 
    {
        try
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();

            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        }
    }
}
