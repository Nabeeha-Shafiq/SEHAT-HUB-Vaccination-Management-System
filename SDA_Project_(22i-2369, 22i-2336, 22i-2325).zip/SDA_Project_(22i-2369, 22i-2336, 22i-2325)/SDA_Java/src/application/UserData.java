package application;

public class UserData {
    private String username;
    private String userId;
    private String vaccine;
    private String center;
    private String symptom;
    private String additionalDetail;

    public UserData(String username, String userId, String vaccine, String center, String symptom, String additionalDetail) {
        this.username = username;
        this.userId = userId;
        this.vaccine = vaccine;
        this.center = center;
        this.symptom = symptom;
        this.additionalDetail = additionalDetail;
    }

    public String getUsername() {
        return username;
    }

    public String getUserId() {
        return userId;
    }

    public String getVaccine() {
        return vaccine;
    }

    public String getCenter() {
        return center;
    }

    public String getSymptom() {
        return symptom;
    }

    public String getAdditionalDetail() {
        return additionalDetail;
    }

    public String toCSV() {
        return username + "," + userId + "," + vaccine + "," + center + "," + symptom + "," + additionalDetail;
    }
}
