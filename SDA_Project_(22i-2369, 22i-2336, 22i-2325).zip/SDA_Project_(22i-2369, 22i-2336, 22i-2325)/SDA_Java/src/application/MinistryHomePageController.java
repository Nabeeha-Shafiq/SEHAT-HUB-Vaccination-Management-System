package application;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import javafx.stage.Popup;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;

public class MinistryHomePageController
{

    @FXML
    private Button SendNotif, sideEffectRport, trackProgress, backButton;

    @FXML
    private ImageView bellIcon;

    @FXML
    private TextArea notificationBox;

    @FXML
    private Text careText;

    private Popup notificationPopup;

    @FXML
    public void initialize() 
    {
    	SendNotif.setOnAction(event -> loadPage("MinistrySendNotification.fxml"));
        sideEffectRport.setOnAction(event -> loadPage("MinistryRecvSideEffectReport.fxml"));
        trackProgress.setOnAction(event -> loadPage("MinistryTrackProgressPage.fxml"));
        backButton.setOnAction(event -> loadPage("MinistryPage.fxml"));

        bellIcon.setOnMouseClicked(event -> toggleNotifications());

        displayHealthcareMessage("#Welcome to Ministry of Health Dashboard! Stay healthy and care for others...");
    }

    private void loadPage(String fxmlFile)
    {
        try
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();

            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } 
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    private void toggleNotifications() 
    {
        if (notificationPopup == null) 
        {
            notificationPopup = new Popup();

            TextArea notifications = new TextArea("You have 2 new notifications:\n- Appointment confirmed for Nov 16\n- New training session available.");
            notifications.setWrapText(true);
            notifications.setEditable(false);
            notifications.setPrefSize(200, 150);

            Button closeButton = new Button("X");
            closeButton.setStyle("-fx-background-color: transparent; -fx-text-fill: red; -fx-font-size: 16px; -fx-padding: 0;");
            closeButton.setOnAction(event -> notificationPopup.hide());

            StackPane.setAlignment(closeButton, javafx.geometry.Pos.TOP_RIGHT);
            StackPane closeButtonContainer = new StackPane(closeButton);

            StackPane popupContent = new StackPane();
            popupContent.getChildren().addAll(notifications, closeButtonContainer);
            notificationPopup.getContent().add(popupContent);
        }

        if (notificationPopup.isShowing())
        {
            notificationPopup.hide();
        } 
        else
        {
            notificationPopup.show(bellIcon, bellIcon.getScene().getWindow().getX() + bellIcon.getLayoutX(),
                    bellIcon.getScene().getWindow().getY() + bellIcon.getLayoutY() + 30);
        }
    }

    private void displayHealthcareMessage(String message)
    {
        careText.setText(""); 
        final int[] charIndex = {0};

        Timeline timeline = new Timeline(new KeyFrame(Duration.millis(100), event ->
        {
            if (charIndex[0] < message.length())
            {
                careText.setText(careText.getText() + message.charAt(charIndex[0]));
                charIndex[0]++;
            }
        }));
        
        timeline.setCycleCount(message.length());
        timeline.setOnFinished(event -> displayHealthcareMessage(message));

        timeline.play();
    }
}
