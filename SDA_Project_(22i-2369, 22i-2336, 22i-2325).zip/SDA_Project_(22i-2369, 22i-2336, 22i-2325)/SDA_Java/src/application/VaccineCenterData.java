package application;
public class VaccineCenterData
{
    private String centerName;
    private String vaccineeName;
    private String vaccineName;
    private int dosesCompleted;
    private int dosesDue;

    public VaccineCenterData(String centerName, String vaccineeName, String vname, int dosesCompleted, int dosesDue)
    {
        this.centerName = centerName;
        this.vaccineeName = vaccineeName;
        this.vaccineName=vname;
        this.dosesCompleted = dosesCompleted;
        this.dosesDue = dosesDue;
    }

    public String getCenterName()
    {
        return centerName;
    }

    public String getVaccineeName()
    {
        return vaccineeName;
    }

    public int getDosesCompleted() 
    {
        return dosesCompleted;
    }

    public int getDosesDue()
    {
        return dosesDue;
    }

    public String getVaccineName()
    {
        return vaccineName;
    }

    public String getTotal() {
        return dosesCompleted + " / " + (dosesCompleted + dosesDue);
    }
}
