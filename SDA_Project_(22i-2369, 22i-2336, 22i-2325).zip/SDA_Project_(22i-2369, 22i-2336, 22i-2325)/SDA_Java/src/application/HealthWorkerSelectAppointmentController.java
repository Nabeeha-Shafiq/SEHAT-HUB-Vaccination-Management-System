package application;

import backend.Center;
import backend.SehatHUB;
import javafx.scene.control.Button;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public class HealthWorkerSelectAppointmentController
{
    // referenced to SEHATHUB
    private SehatHUB sehatHUB;

    @FXML
    private Button ViewApptButton;

    @FXML
    private Button cancelApptButton;

    @FXML
    private ComboBox<String> centerComboBox;

    @FXML
    private ComboBox<String> vaccineComboBox;

    @FXML
    private ComboBox<String> vaccineeComboBox;

    @FXML
    private TableView<Appointment> appointmentTableView;

    @FXML
    private TableColumn<Appointment, Integer> IDColumn;

    @FXML
    private TableColumn<Appointment, String> dateColumn;

    @FXML
    private TableColumn<Appointment, String> timeColumn;

    @FXML
    private TableColumn<Appointment, String> availabilityColumn;

    @FXML
    private Button makeApptButton;

    // list to store appointments from Appointment jav file
    private final ObservableList<Appointment> appointments = FXCollections.observableArrayList();

    public void setSehatHUB(SehatHUB sehathub) throws SQLException {
        this.sehatHUB = sehathub;

        // function for adding centers added here
        List<String> centers_list = sehatHUB.getCenters();
        centerComboBox.getItems().addAll(centers_list);

        // function for adding all the Vaccines
        List<String> vaccineList = sehatHUB.getVaccineList();
        vaccineComboBox.getItems().addAll(vaccineList);

        // function for adding all the Vaccinees who missed their appointment
        List<String> vaccineeList = sehatHUB.getVaccineeList();
        vaccineeComboBox.getItems().addAll(vaccineeList);

        IDColumn.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        timeColumn.setCellValueFactory(new PropertyValueFactory<>("time"));
        availabilityColumn.setCellValueFactory(new PropertyValueFactory<>("availability"));

        appointmentTableView.setItems(appointments);

        vaccineeComboBox.setOnAction(this::filterAppointments);
        centerComboBox.setOnAction(this::filterAppointments);
        vaccineComboBox.setOnAction(this::filterAppointments);

        // disable the Make Appointment button until appt selected
        makeApptButton.setDisable(true);

        // ennable the button if a valid appointment is selected
        appointmentTableView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) ->
        {
            if (newValue != null && "Available".equalsIgnoreCase(newValue.getAvailability()))
            {
                makeApptButton.setDisable(false);
            }
            else
            {
                makeApptButton.setDisable(true);
            }
        });
    }

    @FXML
    public void initialize()
    {
        sehatHUB = new SehatHUB();

        // WANIA CALL FUNCTION HERE TO PROVIDE DTA TO CHOOSE FROM CENTER AND VACCINES
        //centerComboBox.setItems(FXCollections.observableArrayList("Center A", "Center B", "Center C"));
        //vaccineComboBox.setItems(FXCollections.observableArrayList("Vaccine X", "Vaccine Y", "Vaccine Z"));

    }

    //  on selected center and vaccine
    private void filterAppointments(ActionEvent event) {

        try{
        String selectedCenter = centerComboBox.getValue();
        String selectedVaccine = vaccineComboBox.getValue();
        String selectedVaccinee = vaccineeComboBox.getValue();

        if (selectedCenter != null && selectedVaccine != null) {
            // extract the center ID and Vaccine ID here!
            int centerID = 0;
            if (!(selectedCenter == null)) {
                int commaIndex = selectedCenter.indexOf(',');
                centerID = Integer.parseInt(selectedCenter.substring(0, commaIndex));
            }

            int vaccineID = 0;
            if (!(selectedVaccine == null)) {
                int commaIndex = selectedVaccine.indexOf(',');
                vaccineID = Integer.parseInt(selectedVaccine.substring(0, commaIndex));
            }

            int vaccineeID = 0;
            if (!(selectedVaccinee == null)) {
                int commaIndex = selectedVaccine.indexOf(',');
                vaccineeID = Integer.parseInt(selectedVaccinee.substring(0, commaIndex));
            }

            sehatHUB.setVaccinee(sehatHUB.getVaccinee(vaccineeID));

            appointments.setAll(fetchAppointments(centerID, vaccineID));
        }
        }catch (SQLException e){
            e.printStackTrace();
        }
    }

    // Fetching appointments based on selected center and vaccine
    private ObservableList<Appointment> fetchAppointments(int centerID, int vaccineID)
    {
        // call the appropiate functions here
        Center selectedCenter = new Center();
        selectedCenter = selectedCenter.getCenter(centerID);

        // we have to extract the appointments from it
        List<application.Appointment> appointment;
        appointment = sehatHUB.getAppointments(selectedCenter, vaccineID);

        return FXCollections.observableArrayList(appointment);
    }

    @FXML
    private void handleMakeAppointment(ActionEvent event) 
    {
        Appointment selectedAppointment = appointmentTableView.getSelectionModel().getSelectedItem();

        if (selectedAppointment == null || !"Available".equalsIgnoreCase(selectedAppointment.getAvailability()))
        {
            showAlert("Select an appointment", "Please select an available appointment to proceed.");
        } 
        else
        {
            System.out.println("Appointment booked: " + selectedAppointment);
            showAlert("Appointment Booked", "Your appointment ID: " + selectedAppointment.getAppointmentID() + " for Vaccinee: " + sehatHUB.getVaccinee().getUserID() + "- " + sehatHUB.getVaccinee().getUserFName() + " " + sehatHUB.getVaccinee().getUserLName() + ", on " + selectedAppointment.getDate() + " at " + selectedAppointment.getTime() + " is successfully booked.");
             
            // WANIA FROM HERE FETCH THE MADE APPOINTMENT DATA AND STORE INTO YOUR FUNCTION OR WHATEVER IT BE
            sehatHUB.enterAppointment(selectedAppointment, sehatHUB.getVaccinee());

        }
    }

    @FXML
    private void handleCancelAppointment(ActionEvent event)
    {
        
        loadPage("HealthWorkerViewAppointment.fxml",sehatHUB);
    }

    @FXML
    private void handleViewAppointment(ActionEvent event)
    {
      
       loadPage("HealthWorkerViewAppointment.fxml",sehatHUB);
    }


    private void loadPage(String fxmlFile, SehatHUB sehathub)
    {
        try {

            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();

            Object controller = loader.getController();
            if(controller instanceof HealthWorkerViewAppointmentController){
                ((HealthWorkerViewAppointmentController) controller).setSehatHUB(sehathub);
            }
            if(controller instanceof HealthWorkerHomepageController){
                ((HealthWorkerHomepageController) controller).setSehatHUB(sehathub);
            }

            Stage stage = (Stage) makeApptButton.getScene().getWindow();
            stage.setScene(new Scene(root));
        }
        catch (IOException e)
        {
            e.printStackTrace();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private void loadPage(String fxmlFile)
    {
        try {
           
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();
            Stage stage = (Stage) makeApptButton.getScene().getWindow();
            stage.setScene(new Scene(root));
        }
        catch (IOException e)
        {
            e.printStackTrace();
           
        }
    }

    
    private void showAlert(String title, String content)
    {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    @FXML
    private void handleBackButton(ActionEvent event) 
    {
        loadPage("/application/HealthWorkerHomePage.fxml", sehatHUB);
       
    }
}
