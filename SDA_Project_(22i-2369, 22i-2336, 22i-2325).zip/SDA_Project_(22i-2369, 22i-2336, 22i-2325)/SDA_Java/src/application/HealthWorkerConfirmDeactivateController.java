package application;

import backend.SehatHUB;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class HealthWorkerConfirmDeactivateController {

    // references to SehatHUB
    private SehatHUB sehatHUB = new SehatHUB();

    @FXML
    private TextField username;

    @FXML
    private PasswordField password;

    @FXML
    private PasswordField confirmPassword;

    @FXML
    private CheckBox youSureCheckbox;

    @FXML
    private Button deactivateButton;

    @FXML
    private Button backButton;

    public void setSehatHUB(SehatHUB sehathub){
        this.sehatHUB = sehathub;
    }

    @FXML
    public void handleDeactivateButton(ActionEvent event)
    {
    	// WANIA STORE THE USERNAME AND PASSWOORD TO DEACTIVATE FROM HERE IN YOUR FUNCTIONS
        String userNameInput = username.getText().trim();
        String passwordInput = password.getText().trim();
        String confirmPasswordInput = confirmPassword.getText().trim();
        boolean isCheckBoxSelected = youSureCheckbox.isSelected();

        int status = sehatHUB.Login_Healthworker(userNameInput,passwordInput);
        
        if (userNameInput.isEmpty() || passwordInput.isEmpty() || confirmPasswordInput.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please fill in all fields.");
            return;
        }

        if (!passwordInput.equals(confirmPasswordInput)) {
            showAlert(Alert.AlertType.ERROR, "Error", "Passwords do not match.");
            return;
        }

        if (!isCheckBoxSelected) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please confirm that you want to proceed.");
            return;
        }

        if(status == 2){
            showAlert(Alert.AlertType.ERROR, "Error", "Incorrect Username");
            return;
        }

        if(status == 3){
            boolean result = sehatHUB.deleteAccount(sehatHUB.getHealthworker());
            if(result) {
                // If all validations are correct, show a success message and navigate to HealthWorkerPage.fxml
                showAlert(Alert.AlertType.INFORMATION, "Success", "Your account has been deactivated.");
            }
        }



        try {
            Parent root = FXMLLoader.load(getClass().getResource("/application/HealthWorkerPage.fxml"));
            Stage stage = (Stage) deactivateButton.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to load HealthWorkerPage.");
        }
    }


    @FXML
    public void handleBackButton(ActionEvent event)
    {
        try 
        {
            Parent root = FXMLLoader.load(getClass().getResource("/application/HealthWorkerManageAccountPage.fxml"));
            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.setScene(new Scene(root));
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
            
        }
    }
    
 
    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait(); // Wait for the user to close the alert
    }

} 