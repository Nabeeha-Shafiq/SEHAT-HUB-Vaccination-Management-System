package application;

import backend.SehatHUB;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Button;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

public class HealthWorkerManageAccountController
{
    // references to SehatHUB
    private SehatHUB sehatHUB = new SehatHUB();

    @FXML
    private Button backButton;

    @FXML
    private Hyperlink deactivateAccLink;

    @FXML
    private Hyperlink emailLink;

    @FXML
    private Hyperlink editLink;

    public void setSehatHUB(SehatHUB sehathub){
        this.sehatHUB = sehathub;
    }

    @FXML
    public void handleBackButton(ActionEvent event)
    {
        try
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/HealthWorkerHomePage.fxml"));
            Parent root = loader.load();

            Object controller = loader.load();
            if(controller instanceof HealthWorkerHomepageController){
                ((HealthWorkerHomepageController) controller).setSehatHUB(sehatHUB);
            }

            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.setScene(new Scene(root));
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    // compose email
    @FXML
    public void handleEmailLink(ActionEvent event)
    {
        try 
        {
            Desktop desktop = Desktop.getDesktop();
            URI mailto = new URI("mailto:sehathub2024@gmail.com");
            desktop.mail(mailto);
        } 
        catch (IOException | URISyntaxException e) 
        {
            e.printStackTrace();
        }
    }



    @FXML
    public void handleEditLink(ActionEvent event)
    {
        Stage loadingStage = new Stage();
        ProgressIndicator progressIndicator = new ProgressIndicator();
        Scene loadingScene = new Scene(progressIndicator, 100, 100);
        loadingStage.setScene(loadingScene);
        loadingStage.setTitle("Loading...");
        loadingStage.show();

        new Thread(() ->
        {
            try 
            {
                Thread.sleep(2000); 

                Platform.runLater(() -> 
                {
                    loadingStage.close();
                    try 
                    {
                        FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/HealthWorkerUpdatePage.fxml"));
                        Parent root = loader.load();

                        Object controller = loader.getController();
                        if(controller instanceof HealthWorkerUpdateController){
                            ((HealthWorkerUpdateController) controller).setSehatHUB(this.sehatHUB);
                        }

                        Stage stage = (Stage) editLink.getScene().getWindow();
                        stage.setScene(new Scene(root));
                    } 
                    catch (IOException e)
                    {
                        e.printStackTrace();
                    }
                });
            } 
            catch (InterruptedException e)
            {
                e.printStackTrace();
            }
        }).start();
    }

   
    @FXML
    public void handleDeactivateLink(ActionEvent event)
    {
        try 
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("HealthWorkerConfirmDelete.fxml"));
            Parent root = loader.load();

            Object controller = loader.getController();
            if(controller instanceof HealthWorkerConfirmDeactivateController){
                ((HealthWorkerConfirmDeactivateController) controller).setSehatHUB(this.sehatHUB);
            }

            Stage stage = (Stage) deactivateAccLink.getScene().getWindow();
            stage.setScene(new Scene(root));
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        }
    }
}
