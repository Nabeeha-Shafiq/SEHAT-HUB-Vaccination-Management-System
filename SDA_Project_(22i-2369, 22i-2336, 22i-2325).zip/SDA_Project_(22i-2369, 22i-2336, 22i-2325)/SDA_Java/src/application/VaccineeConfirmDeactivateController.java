package application;

import backend.SehatHUB;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.SQLException;

public class VaccineeConfirmDeactivateController 
{
    private SehatHUB sehatHUB = new SehatHUB();

    @FXML
    private Button backButton;

    @FXML
    private Button accDeactivate;

    @FXML
    private TextField username;

    @FXML
    private PasswordField password;

    @FXML
    private PasswordField confirmPassword;

    @FXML
    private CheckBox youSureCheckBox;

    @FXML
    public void handleBackButton(ActionEvent event) 
    {
        try
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/VaccineeManageAccountPage.fxml"));
            Parent root = loader.load() ;

            Object controller = loader.getController();
            if(controller instanceof VaccineeManageAccountController){
                ((VaccineeManageAccountController) controller).setSehatHUB(this.sehatHUB);
            }

            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.setScene(new Scene(root));
        } 
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    public void setSehatHUB(SehatHUB sehathub){
        this.sehatHUB = sehathub;
    }

    //  Deactivate Account Button
    @FXML
    public void handleAccDeactivate(ActionEvent event) throws SQLException {  // WANIA STORE THE USERNAME AND PASSWOORD TO DEACTIVATE FROM HERE IN YOUR FUNCTIONS
        String userNameInput = username.getText().trim();
        String passwordInput = password.getText().trim();
        String confirmPasswordInput = confirmPassword.getText().trim();
        boolean isCheckBoxSelected = youSureCheckBox.isSelected();

        int status = sehatHUB.Login_Vaccinee(userNameInput, passwordInput);

        // Validate inputs
        if (userNameInput.isEmpty() || passwordInput.isEmpty() || confirmPasswordInput.isEmpty())
        {
            showAlert(AlertType.ERROR, "Error", "Please fill in all fields.");
            return;
        }

        if (!passwordInput.equals(confirmPasswordInput))
        {
            showAlert(AlertType.ERROR, "Error", "Passwords do not match.");
            return;
        }

        if (!isCheckBoxSelected)
        {
            showAlert(AlertType.ERROR, "Error", "Please confirm that you want to proceed.");
            return;
        }

        if(status == 2){
            showAlert(Alert.AlertType.ERROR, "Error", "Incorrect Username");
            return;
        }

        if(status == 3){
            boolean checker = sehatHUB.childrenlinked(sehatHUB.getVaccinee());
            if(!checker) {
                boolean result = sehatHUB.deleteVaccinee(sehatHUB.getVaccinee());
                if (result) {
                    // If all validations are correct, show a success message and navigate to HealthWorkerPage.fxml
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Your account has been deactivated.");
                }
            }else{
                showAlert(Alert.AlertType.ERROR, "Error", "Cannot Deactiviate account when Descendent account is linked");
                return;
            }
        }

        try 
        {
            Parent root = FXMLLoader.load(getClass().getResource("/application/VaccineePage.fxml"));
            Stage stage = (Stage) accDeactivate.getScene().getWindow();
            stage.setScene(new Scene(root));
        } 
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    // show an alert dialog
    private void showAlert(AlertType alertType, String title, String message)
    {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
