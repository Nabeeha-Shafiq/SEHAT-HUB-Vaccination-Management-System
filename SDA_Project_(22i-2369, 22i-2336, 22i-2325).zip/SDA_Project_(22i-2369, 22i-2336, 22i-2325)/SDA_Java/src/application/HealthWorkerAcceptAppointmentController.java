package application;

import backend.SehatHUB;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class HealthWorkerAcceptAppointmentController 
{
    // referenced to SEHATHUB
    private SehatHUB sehatHUB;

    @FXML
    private Label DateTimeLabel, CenterLabel;

    @FXML
    private Button backButton1;

    @FXML
    private Button acceptApptButton;

    @FXML
    private ComboBox<String> vaccineComboBox;

    @FXML
    private TableView<VaccineeData> appointmentsTable;

    @FXML
    private TableColumn<VaccineeData, Integer> appointmentIDColumn;

    @FXML
    private TableColumn<VaccineeData, String> vaccineeNameColumn;

    @FXML
    private TableColumn<VaccineeData, Integer> vaccineeIdColumn;

    @FXML
    private TableColumn<VaccineeData, String> appointmentTimeColumn;

    @FXML
    private TableColumn<VaccineeData, String> statusColumn;

    private final ObservableList<VaccineeData> vaccineeDataList = FXCollections.observableArrayList();

    public void setSehatHUB(SehatHUB sehathub) throws SQLException {
        this.sehatHUB = sehathub;

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1), event -> {
            LocalDateTime now = LocalDateTime.now();
            DateTimeLabel.setText(now.format(formatter)); // Set the current date and time
        }));

        timeline.setCycleCount(Timeline.INDEFINITE); // Keep running indefinitely
        timeline.play();

        CenterLabel.setText(sehatHUB.getCenterLine(sehatHUB.getHealthworker().getCenterID()));

        // WANINA HERE APPLY THE LOGIC TO CLL UR FUNCTION TO LOAD DATA
        // BTW THERES A VACCINEE DATA .JAVA CLASS FROM WHERE IGETTING THE GETTER AND SETTER SO CHECK IT
        // function for adding all the Vaccines
        List<String> vaccineList = sehatHUB.getVaccineList();
        vaccineComboBox.getItems().addAll(vaccineList);

        appointmentIDColumn.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
        vaccineeNameColumn.setCellValueFactory(new PropertyValueFactory<>("vaccineeName"));
        vaccineeIdColumn.setCellValueFactory(new PropertyValueFactory<>("vaccineeId"));
        appointmentTimeColumn.setCellValueFactory(new PropertyValueFactory<>("appointmentTime"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));

        // listener for ComboBox change events to update the table
        vaccineComboBox.valueProperty().addListener((observable, oldValue, newValue) -> {
            try {
                loadAppointments();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        });

        //  data loading
        loadAppointments();
    }

    @FXML
    public void initialize()
    {
        sehatHUB = new SehatHUB();
    }

    // Populate the table based on ComboBox selections
    private void loadAppointments() throws SQLException {
        //  previous data clear
        vaccineeDataList.clear();

        // Get selected center and vaccine
        String selectedVaccine = vaccineComboBox.getValue();
        int vaccineID = 0;
        if(!(selectedVaccine == null)){
            int commaIndex = selectedVaccine.indexOf(',');
            vaccineID = Integer.parseInt(selectedVaccine.substring(0,commaIndex));
        }

        System.out.println("Selected Vaccine: " + selectedVaccine);
        List<VaccineeData> vaccineeDataList = new ArrayList<>();

        // S data population logic
        if (selectedVaccine != null)
        {
            // call function filter out the missed appointments into the missed appointment table
            sehatHUB.filterMissedAppointment(sehatHUB.getHealthworker().getCenterID(),vaccineID);

            // call the function of extracting the pending appointment currently on that day.
            // we have to extract the appointments from it
            vaccineeDataList = sehatHUB.getVaccineeDataList(sehatHUB.getHealthworker().getCenterID(),vaccineID);
        } 
        else
        {
            System.out.println("No center or vaccine selected.");
        }

        System.out.println("Size of vaccineeDataList: " + vaccineeDataList.size());

        ObservableList<VaccineeData> newVaccineeDataList = FXCollections.observableArrayList(vaccineeDataList);

        appointmentsTable.setItems(newVaccineeDataList);
    }

    @FXML
    private void handleAcceptAppointment(ActionEvent event) 
    {
        // here get the selected vaccinee data from the table
        VaccineeData selectedVaccinee = appointmentsTable.getSelectionModel().getSelectedItem();

        String selectedVaccine = vaccineComboBox.getValue();
        int vaccineID = 0;
        if(!(selectedVaccine == null)){
            int commaIndex = selectedVaccine.indexOf(',');
            vaccineID = Integer.parseInt(selectedVaccine.substring(0,commaIndex));
        }

        if (selectedVaccinee != null) 
        {
            // updating here the status of the selected vaccinee to "Complete"
            selectedVaccinee.setStatus("Complete");

            appointmentsTable.refresh();

            // call function here to transfer the entry from pendingAppointments to completedAppointments
            sehatHUB.addCompletedAppointment(selectedVaccinee.getAppointmentID(), selectedVaccinee.getVaccineeId());

            // also to reduce the dose numbers
            sehatHUB.reduceDose(selectedVaccinee.getVaccineeId(),vaccineID);

            // add vaccinee to table of visited vacciness at center
            sehatHUB.addVisitedVaccinee(sehatHUB.getHealthworker().getCenterID(), selectedVaccinee.getVaccineeId(), selectedVaccinee.getAppointmentID());

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Appointment Accepted");
            alert.setHeaderText(null);
            alert.setContentText("The appointment has been accepted and marked as complete.");
            alert.showAndWait();
        } 
        else
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Please select a vaccinee to accept the appointment.");
            alert.showAndWait();
        }
    }

    @FXML
    private void handleBackButton(ActionEvent event) throws IOException 
    {
        Stage stage = (Stage) backButton1.getScene().getWindow();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("HealthWorkerHomePage.fxml"));
        Parent root = loader.load();

        Object controller = loader.getController();
        if(controller instanceof HealthWorkerHomepageController){
            ((HealthWorkerHomepageController) controller).setSehatHUB(this.sehatHUB);
        }

        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}
