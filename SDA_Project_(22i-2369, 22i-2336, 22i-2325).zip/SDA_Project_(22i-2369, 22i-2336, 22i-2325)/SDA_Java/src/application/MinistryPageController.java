package application;

import backend.SehatHUB;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.Parent;
import java.io.IOException;

public class MinistryPageController
{

    // reference to SehatHUB
    private SehatHUB sehatHUB;

    @FXML
    private Button loginButton;
    @FXML
    private Button backButton;
    @FXML
    private TextField Ausername;
    @FXML
    private PasswordField Apassword;
    @FXML
    private Label usernameFeedbackLabel;
    @FXML
    private Label passwordFeedbackLabel;

    // i already assigned a fixed admin login detail here ( can change later on accordingly to our logic)
   // private static final String VALID_USERNAME = "admin";
   // private static final String VALID_PASSWORD = "123";

    @FXML
    public void initialize()
    {
    	backButton.setOnAction(event -> loadNextPage("mainpage.fxml"));
    	//loginButton.setOnAction(event -> loadNextPage("MinistryHomepage.fxml")); // remove this nd uncomment below code
        loginButton.setOnAction(event -> handleLogin());
        
    }

    private void handleLogin()
    {
        String enteredUsername = Ausername.getText();
        String enteredPassword = Apassword.getText();

        usernameFeedbackLabel.setText("");
        passwordFeedbackLabel.setText("");

        boolean isValid = true;

        if (!enteredUsername.equals("MOH"))
        {
            usernameFeedbackLabel.setText("Incorrect username.");
            isValid = false;
        }
        else
        {
            usernameFeedbackLabel.setText("Correct");
            usernameFeedbackLabel.setStyle("-fx-text-fill: green;");
        }


        if (!enteredPassword.equals("MOH"))
        {
            passwordFeedbackLabel.setText("Incorrect password.");
            isValid = false;
        }
        else
        {
            passwordFeedbackLabel.setText("Correct");
            passwordFeedbackLabel.setStyle("-fx-text-fill: green;");
        }


        if (isValid)
        {
            loadNextPage("MinistryHomepage.fxml");
        }
    }

    private void loadNextPage(String fxmlFile)
    {
        try 
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();

            Stage stage = (Stage) loginButton.getScene().getWindow();
            
            stage.setScene(new Scene(root));
            stage.show();
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        }
    }
}
