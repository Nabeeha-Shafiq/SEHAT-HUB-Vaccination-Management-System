package application;

import backend.SehatHUB;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class HealthWorkerTrackProgressController
{
    // references to SehatHUB
    private SehatHUB sehatHUB;

    @FXML
    private Button backButton;

    @FXML
    private Button generateReportButton;

    @FXML
    private TableView<VaccineCenterData> tableView;

    @FXML
    private TableColumn<VaccineCenterData, String> centerColumn;

    @FXML
    private TableColumn<VaccineCenterData, String> vaccineeColumn;

    @FXML
    private TableColumn<VaccineCenterData, Integer> dosesCompletedColumn;

    @FXML
    private TableColumn<VaccineCenterData, Integer> dosesDueColumn;

    @FXML
    private TableColumn<VaccineCenterData, String> totalColumn;

    private final ObservableList<VaccineCenterData> vaccineCenterDataList = FXCollections.observableArrayList();

    public void setSehatHUB(SehatHUB sehathub){
        this.sehatHUB = sehathub;
        loadVaccinationData();
    }

    @FXML
    public void initialize() {
        sehatHUB = new SehatHUB();
        // meine uper phenk diya hai!!!
    }

    private void loadVaccinationData() {
        //NNNNNNNNNNNNNNNNNNNNNNNNNN
        // Replace with actual ID obtained from the session or context
        tableView.setItems(sehatHUB.getHealthWorkerVaccinationData(sehatHUB.getHealthworker().getUserID()));
        tableView.getColumns().get(0).setCellValueFactory(new PropertyValueFactory<>("centerName"));
        tableView.getColumns().get(1).setCellValueFactory(new PropertyValueFactory<>("vaccineeName"));
        tableView.getColumns().get(2).setCellValueFactory(new PropertyValueFactory<>("vaccineName"));
        tableView.getColumns().get(3).setCellValueFactory(new PropertyValueFactory<>("dosesCompleted"));
        tableView.getColumns().get(4).setCellValueFactory(new PropertyValueFactory<>("dosesDue"));
        tableView.getColumns().get(5).setCellValueFactory(new PropertyValueFactory<>("total"));
    }

    @FXML
    public void handleBackButton(ActionEvent event)
    {
        try
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/HealthWorkerHomePage.fxml"));
            Parent root = loader.load();

            Object controller = loader.getController();
            if(controller instanceof HealthWorkerHomepageController){
                ((HealthWorkerHomepageController) controller).setSehatHUB(this.sehatHUB);
            }

            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.setScene(new Scene(root));
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        }
    }

    @FXML
    public void handleGenerateReport(ActionEvent event)
    {
        try 
        {
            // FILE NAME AND PATH
            String filePath = "VaccineReport.csv";

            BufferedWriter writer = new BufferedWriter(new FileWriter(filePath));

            // WRITE CSV HEADER
            writer.write("Center Name,Vaccinee Name,Doses Completed,Doses Due,Total");
            writer.newLine();

            // WRITE TABLE DATA TO CSV
            for (VaccineCenterData data : vaccineCenterDataList)
            {
                String line = data.getCenterName() + "," +
                              data.getVaccineeName() + "," +
                              data.getDosesCompleted() + "," +
                              data.getDosesDue() + "," +
                              data.getTotal();
                writer.write(line);
                writer.newLine();
            }
           
            writer.close();

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Report Generated");
            alert.setHeaderText(null);
            alert.setContentText("The report has been successfully generated as a CSV file.");
            alert.showAndWait();

            System.out.println("Report generated successfully: " + filePath);

        }
        catch (IOException e) 
        {
            e.printStackTrace();

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("An error occurred while generating the report.");
            alert.showAndWait();
        }
    }
}
