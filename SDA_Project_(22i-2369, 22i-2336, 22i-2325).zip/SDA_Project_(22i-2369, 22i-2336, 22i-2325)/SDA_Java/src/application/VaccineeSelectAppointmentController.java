package application;

import backend.Center;
import backend.SehatHUB;
import backend.Vaccine;
import backend.Vaccinee;
import javafx.scene.control.Button;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class VaccineeSelectAppointmentController
{
    // referenced to SEHATHUB
    private SehatHUB sehatHUB;

    @FXML
    private Button ViewApptButton;

    @FXML
    private Button cancelApptButton;

    @FXML
    private ComboBox<String> centerComboBox;

    @FXML
    private ComboBox<String> vaccineComboBox;

    @FXML
    private TableView<Appointment> appointmentTableView;

    @FXML
    private TableColumn<Appointment, Integer> IDColumn;

    @FXML
    private TableColumn<Appointment, String> dateColumn;

    @FXML
    private TableColumn<Appointment, String> timeColumn;

    @FXML
    private TableColumn<Appointment, String> availabilityColumn;

    @FXML
    private Button makeApptButton;

    // list to store appointments from Appointment jav file
    private ObservableList<Appointment> appointments = FXCollections.observableArrayList();

    public void setSehatHUB(SehatHUB sehathub){
        this.sehatHUB = sehathub;

        // function for adding centers added here
        List<String> centers_list = sehatHUB.getCenters();
        centerComboBox.getItems().addAll(centers_list);

        // function for adding vaccines here according to the Vaccinee
        List<String> vaccineList = sehatHUB.getVaccineList(sehatHUB.getVaccinee().getUserID());
        vaccineComboBox.getItems().addAll(vaccineList);

        IDColumn.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        timeColumn.setCellValueFactory(new PropertyValueFactory<>("time"));
        availabilityColumn.setCellValueFactory(new PropertyValueFactory<>("availability"));

        centerComboBox.setOnAction(this::filterAppointments);
        vaccineComboBox.setOnAction(this::filterAppointments);

        appointmentTableView.setItems(appointments);

        // disable the Make Appointment button untill appt selected
        makeApptButton.setDisable(true);

        // enable the button if a valid appointment is selected
        appointmentTableView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) ->
        {
            if (newValue != null && "Available".equalsIgnoreCase(newValue.getAvailability()))
            {
                makeApptButton.setDisable(false);
            }
            else
            {
                makeApptButton.setDisable(true);
            }
        });
    }

    @FXML
    public void initialize()
    {
        sehatHUB = new SehatHUB();

        // WANIA CALL FUNCTION HERE TO PROVIDE DTA TO CHOOSE FROM CENTER AND VACCINES
        //centerComboBox.setItems(FXCollections.observableArrayList("Center A", "Center B", "Center C"));
        //vaccineComboBox.setItems(FXCollections.observableArrayList("Vaccine X", "Vaccine Y", "Vaccine Z"));

    }

    //  on selected center and vaccine
    private void filterAppointments(ActionEvent event)
    {
        String selectedCenter = centerComboBox.getValue();
        String selectedVaccine = vaccineComboBox.getValue();

        if (selectedCenter != null && selectedVaccine != null) 
        {
            // extract the center ID and Vaccine ID here!
            int centerID = 0;
            if(!(selectedCenter == null)){
                int commaIndex = selectedCenter.indexOf(',');
                centerID = Integer.parseInt(selectedCenter.substring(0,commaIndex));
            }

            int vaccineID = 0;
            if(!(selectedVaccine == null)){
                int commaIndex = selectedVaccine.indexOf(',');
                vaccineID = Integer.parseInt(selectedVaccine.substring(0,commaIndex));
            }

            // pass the ids of vaccine and center over
            appointments.setAll(fetchAppointments(centerID, vaccineID));
        }
    }

    // Fetching appointments based on selected center and vaccine
    private ObservableList<Appointment> fetchAppointments(int centerID, int vaccineID)
    {
        Center selectedCenter = new Center();
        selectedCenter = selectedCenter.getCenter(centerID);

        // we have to extract the appointments from it
        List<application.Appointment> appointment;
        appointment = sehatHUB.getAppointments(selectedCenter, vaccineID);

        return FXCollections.observableArrayList(appointment);
    }

    @FXML
    private void handleMakeAppointment(ActionEvent event) 
    {
        Appointment selectedAppointment = appointmentTableView.getSelectionModel().getSelectedItem();

        if (selectedAppointment == null || !"Available".equalsIgnoreCase(selectedAppointment.getAvailability()))
        {
            showAlert("Select an appointment", "Please select an available appointment to proceed.");
        } 
        else
        {
            System.out.println("Appointment booked: " + selectedAppointment);
            showAlert("Appointment Booked", "Your appointment ID: " + selectedAppointment.getAppointmentID() + ", on " + selectedAppointment.getDate() + " at " + selectedAppointment.getTime() + " is successfully booked.");
             
            // over here we add the appoinment into the system
            // change the appointment reserved from 0 to 1
            // add into table Vaccinee_pendingAppointment

            sehatHUB.enterAppointment(selectedAppointment, sehatHUB.getVaccinee());

        }
    }

    @FXML
    private void handleCancelAppointment(ActionEvent event)
    {
        
        loadPage("VaccineeViewAppointment.fxml",sehatHUB);
    }

    @FXML
    private void handleViewAppointment(ActionEvent event)
    {
      
       loadPage("VaccineeViewAppointment.fxml",sehatHUB);
    }

    private void loadPage(String fxmlFile, SehatHUB sehathub)
    {
        try {

            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();

            Object controller = loader.getController();
            if(controller instanceof VaccineeHomePageController){
                ((VaccineeHomePageController) controller).setSehatHUB(sehathub);
            }
            if(controller instanceof VaccineeViewAppointmentController){
                ((VaccineeViewAppointmentController) controller).setSehatHUB(sehathub);
            }

            Stage stage = (Stage) makeApptButton.getScene().getWindow();
            stage.setScene(new Scene(root));
        }
        catch (IOException e)
        {
            e.printStackTrace();

        }
    }

    private void loadPage(String fxmlFile)
    {
        try {
           
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();
            Stage stage = (Stage) makeApptButton.getScene().getWindow();
            stage.setScene(new Scene(root));
        }
        catch (IOException e)
        {
            e.printStackTrace();
           
        }
    }

    
    private void showAlert(String title, String content)
    {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    @FXML
    private void handleBackButton(ActionEvent event) 
    {
        loadPage("/application/VaccineeHomePage.fxml",this.sehatHUB);
       
    }
}
