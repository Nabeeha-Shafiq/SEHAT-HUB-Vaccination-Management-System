package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.collections.FXCollections;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;
import java.io.IOException;
import java.sql.SQLException;

import backend.SehatHUB;
import backend.VaccineeDAO;

public class VaccineReportSideEffectsController
{

    @FXML
    private ComboBox<String> VaccineComboBox;

    @FXML
    private ComboBox<String> SymptomsComboBox;

    @FXML
    private ComboBox<String> CenterComboBOx;

    @FXML
    private TextArea AdditionalTextField;

    @FXML
    private Button SubmitButton;

    @FXML
    private Button backButton;
    private SehatHUB sehatHub;

    public void setSehatHub(SehatHUB sehathub){
        this.sehatHub = sehathub;
    }

    @FXML
    public void initialize() throws SQLException {
        sehatHub=new SehatHUB();
//        VaccineComboBox.setItems(FXCollections.observableArrayList("Pfizer", "Moderna", "AstraZeneca", "Sinovac"));
//
//
//        SymptomsComboBox.setItems(FXCollections.observableArrayList("Fever", "Fatigue", "Headache", "Pain at injection site", "Nausea"));
//
//
//        CenterComboBOx.setItems(FXCollections.observableArrayList("Center A", "Center B", "Center C", "Center D"));

        VaccineComboBox.setItems(FXCollections.observableArrayList(sehatHub.fetchVaccineNames()));
        SymptomsComboBox.setItems(FXCollections.observableArrayList(sehatHub.fetchSymptoms()));
        CenterComboBOx.setItems(FXCollections.observableArrayList(sehatHub.fetchCenterNames()));

    }

    @FXML
    private void handleSubmit(ActionEvent event)
    {
        try
        {
            System.out.println("Submit button clicked!");

            String selectedVaccine = VaccineComboBox.getValue();
            String selectedSymptom = SymptomsComboBox.getValue();
            String selectedCenter = CenterComboBOx.getValue();
            String additionalDetails = AdditionalTextField.getText();

            if (selectedVaccine == null || selectedSymptom == null || selectedCenter == null)
            {
                showAlert("Missing Information", "Please fill in all required fields: Vaccine, Symptom, and Center.");
                return;
            }

            VaccineeDAO obj=new VaccineeDAO();
            int vaccineID = obj.fetchVaccineIDByName(selectedVaccine);
            //NNNNNNNNNNNNNNNNNNNNNNNNNNNNNN actual logic here
            int vaccineeID = 1;


            sehatHub.reportVaccineSideEffect(vaccineID, vaccineeID, selectedSymptom, additionalDetails);
            String message = "Report Summary:\n"
                    + "- Vaccine: " + selectedVaccine + "\n"
                    + "- Symptom: " + selectedSymptom + "\n"
                    + "- Center: " + selectedCenter + "\n"
                    + (additionalDetails.isEmpty() ? "" : "- Additional Details: " + additionalDetails);

            showAlert("Report Submitted", "The side effects have been forwarded to the Ministry of Health and Health Management Center.\n\n" + message);

            VaccineComboBox.getSelectionModel().clearSelection();
            SymptomsComboBox.getSelectionModel().clearSelection();
            CenterComboBOx.getSelectionModel().clearSelection();
            AdditionalTextField.clear();
        }
        catch (Exception e)
        {
            e.printStackTrace();
            showAlert("Error", "An error occurred: " + e.getMessage());
        }
    }


    @FXML
    private void handleBackButton(ActionEvent event)
    {
        loadPage("/application/VaccineeHomePage.fxml", this.sehatHub);
    }

    private void loadPage(String fxmlFile,SehatHUB sehatHub)
    {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();

            Object controller = loader.getController();
            if(controller instanceof VaccineeHomePageController){
                ((VaccineeHomePageController) controller).setSehatHUB(sehatHub);
            }

            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.setScene(new Scene(root));
        }
        catch (IOException e)
        {
            e.printStackTrace();
            showAlert("Navigation Error", "Failed to load the requested page: " + fxmlFile);
        }
    }


    private void loadPage(String fxmlFile)
    {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();

            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.setScene(new Scene(root));
        }
        catch (IOException e)
        {
            e.printStackTrace();
            showAlert("Navigation Error", "Failed to load the requested page: " + fxmlFile);
        }
    }


    private void showAlert(String title, String content)
    {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
