package application;

import java.io.IOException;
import java.util.List;

import backend.SehatHUB;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class VaccineeViewAppointmentController 
{
    private SehatHUB sehatHUB;

    @FXML
    private TableView<Appointment> appointmentTableView;

    @FXML
    private TableColumn<Appointment, Integer> IDColumn;

    @FXML
    private TableColumn<Appointment, String> dateColumn;

    @FXML
    private TableColumn<Appointment, String> timeColumn;

    @FXML
    private TableColumn<Appointment, String> availabilityColumn;

    @FXML
    private Button cancelApptButton;

    @FXML
    private Button backButton1;

    private List<backend.Appointment> appointmentList;

    public void setSehatHUB(SehatHUB sehathub) {
        this.sehatHUB = sehathub;

        IDColumn.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        timeColumn.setCellValueFactory(new PropertyValueFactory<>("time"));
        availabilityColumn.setCellValueFactory(new PropertyValueFactory<>("availability"));

        // wania this is  mock data (replace with actual data retrieval from database or function)
        appointmentList = FXCollections.observableArrayList();

        ObservableList<Appointment> newAppointmentList = FXCollections.observableArrayList(sehatHUB.getAppointmentList(sehatHUB.getVaccinee().getVaccineeID()));

        // Settng data to the table
        appointmentTableView.setItems(newAppointmentList);
    }

    @FXML
    public void initialize()
    {
        sehatHUB = new SehatHUB();
    }

    @FXML
    private void handleCancelAppointment(ActionEvent event)
    {
        Appointment selectedAppointment = appointmentTableView.getSelectionModel().getSelectedItem();

        if (selectedAppointment == null) 
        {
            showAlert("No Selection", "Please select an appointment to cancel.");
            return;
        }

        // here it be remove appointment from list
        appointmentList.remove(selectedAppointment);

        // remove the appointment from pending appointment change the reserved to unreserved
        sehatHUB.removeAppointment(selectedAppointment.getAppointmentID());

     
        showAlert("Appointment Canceled", "The selected appointment has been canceled.");
    }
    private void loadPage(String fxmlFile)
    {
        try {
           
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();

            Stage stage = (Stage) backButton1.getScene().getWindow();
            stage.setScene(new Scene(root));
        }
        catch (IOException e)
        {
            e.printStackTrace();
           
        }
    }

    @FXML
    private void handleBackButton(ActionEvent event)
    {
        
    	loadPage("/application/VaccineeHomePage.fxml");
    }

    private void showAlert(String title, String content)
    {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}