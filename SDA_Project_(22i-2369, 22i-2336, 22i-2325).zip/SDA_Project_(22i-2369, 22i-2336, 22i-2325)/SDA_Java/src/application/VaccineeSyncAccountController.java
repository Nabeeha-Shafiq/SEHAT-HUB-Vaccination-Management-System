package application;

import backend.SehatHUB;
import backend.Vaccinee;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.List;

public class VaccineeSyncAccountController 
{
    private SehatHUB sehatHUB;

    @FXML
    private Button backButton;

    @FXML
    private Button addDescedant;

    @FXML
    private TableView<Descendant> DescedantTable;

    @FXML
    private TableColumn<Descendant, String> usernameColumn;

    @FXML
    private TableColumn<Descendant, String> fullnameColumn;

    @FXML
    private TableColumn<Descendant, String> ageColumn;

    private ObservableList<Descendant> descendants;

    public void setSehatHUB(SehatHUB sehathub){
        this.sehatHUB = sehathub;

        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));
        fullnameColumn.setCellValueFactory(new PropertyValueFactory<>("fullname"));
        ageColumn.setCellValueFactory(new PropertyValueFactory<>("age"));

        List<Descendant> children = sehatHUB.getchildrenStrings(sehatHUB.getVaccinee());

        descendants = FXCollections.observableArrayList(children);

        DescedantTable.setItems(descendants);
    }

    @FXML
    public void initialize()
    {
        sehatHUB = new SehatHUB();
    }

    @FXML
    private void handleAddDescedant(ActionEvent event)
    {
        try
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/VaccineeSignupPage.fxml"));
            Scene scene = new Scene(loader.load());

            Object controller = loader.getController();
            if(controller instanceof VaccineeSignupController){
                ((VaccineeSignupController) controller).setSehatHUB(this.sehatHUB);
                ((VaccineeSignupController) controller).setchild(1);
            }

            Stage stage = (Stage) addDescedant.getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleBackButton(ActionEvent event)
    
    {
        try 
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/VaccineeHomePage.fxml"));
            Scene scene = new Scene(loader.load());

            Object controller = loader.getController();
            if(controller instanceof VaccineeHomePageController){
                ((VaccineeHomePageController) controller).setSehatHUB(this.sehatHUB);
            }

            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}
