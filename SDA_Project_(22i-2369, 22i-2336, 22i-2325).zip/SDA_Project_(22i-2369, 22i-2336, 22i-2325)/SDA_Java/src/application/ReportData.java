//package application;
//
//public class ReportData {
//    private String centerName;
//    private String healthWorkerName;
//    private String vaccineeName;
//    private String vaccineeID;
//    private String vaccineName;
//    private int dosesCompleted;
//
//    public ReportData(String centerName, String healthWorkerName, String vaccineeName, String vaccineeID, String vaccineName, int dosesCompleted) {
//        this.centerName = centerName;
//        this.healthWorkerName = healthWorkerName;
//        this.vaccineeName = vaccineeName;
//        this.vaccineeID = vaccineeID;
//        this.vaccineName = vaccineName;
//        this.dosesCompleted = dosesCompleted;
//    }
//
//    // Getters
//}


package application;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class ReportData {
    private SimpleStringProperty centerName;
    private SimpleStringProperty healthWorkerName;
    private SimpleStringProperty vaccineeName;
    private SimpleStringProperty vaccineeID;
    private SimpleStringProperty vaccineName;
    private SimpleIntegerProperty dosesCompleted;

    public ReportData(String centerName, String healthWorkerName, String vaccineeName, String vaccineeID, String vaccineName, int dosesCompleted) {
        this.centerName = new SimpleStringProperty(centerName);
        this.healthWorkerName = new SimpleStringProperty(healthWorkerName);
        this.vaccineeName = new SimpleStringProperty(vaccineeName);
        this.vaccineeID = new SimpleStringProperty(vaccineeID);
        this.vaccineName = new SimpleStringProperty(vaccineName);
        this.dosesCompleted = new SimpleIntegerProperty(dosesCompleted);
    }

    public SimpleStringProperty centerNameProperty() {
        return centerName;
    }

    public SimpleStringProperty healthWorkerNameProperty() {
        return healthWorkerName;
    }

    public SimpleStringProperty vaccineeNameProperty() {
        return vaccineeName;
    }

    public SimpleStringProperty vaccineeIDProperty() {
        return vaccineeID;
    }

    public SimpleStringProperty vaccineNameProperty() {
        return vaccineName;
    }

    public SimpleIntegerProperty dosesCompletedProperty() {
        return dosesCompleted;
    }
    
    
}
