package application;

import backend.SehatHUB;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.Parent;
import javafx.stage.Stage;
import javafx.scene.paint.Color;

import java.io.IOException;
import java.util.List;

public class HealthWorkerSignUpController
{
    // referenced to SEHATHUB
    private SehatHUB sehatHUB;
    @FXML
    private Button createAccount;
    @FXML
    private Button backButton;
    @FXML
    private TextField HFname, HLname, HPhone, HEmail, HLicense, HUsername;
    @FXML
    private PasswordField HPasscode;
    @FXML
    private DatePicker HDOB;
    @FXML
    private ComboBox<String> Hgender, chooseCenter;

    @FXML
    private Label FnameLabel, LnameLabel, DobLabel, genderLabel, phoneLabel, emailLabel, liscenseLabel, usernameLabel, passwordLabel, centerLabel1;

    @FXML
    public void initialize()
    {
        sehatHUB = new SehatHUB();
        Hgender.getItems().addAll("Male", "Female", "Others");

        // function for adding centers added here
        List<String> centers_list = sehatHUB.getCenters();

        chooseCenter.getItems().addAll(centers_list);

        createAccount.setOnAction(event -> validateCheck());
        backButton.setOnAction(event -> loadPage("HealthWorkerPage.fxml"));
    }

    private void validateCheck()
    {
        boolean valid = true;

        // create instance of Healthworker first

        String center_line = chooseCenter.getValue();
        int centerID = 0;
        if(!(center_line == null)){
            int commaIndex = center_line.indexOf(',');
            centerID = Integer.parseInt(center_line.substring(0,commaIndex));
        }

        sehatHUB.addHealthworker(HUsername.getText(),HPasscode.getText(),HFname.getText(),HLname.getText(),HDOB.getValue(),Hgender.getValue(),HPhone.getText(),HLicense.getText(),HEmail.getText(),centerID);
        boolean[] answer = sehatHUB.SignUp_Healthworker(sehatHUB.getHealthworker());

        // First Name
        if (HFname.getText().isEmpty())
        {
            FnameLabel.setText("Field Required");
            FnameLabel.setTextFill(Color.RED);
            valid = false;
        }
        else
        {
            // Validation Check
            if(answer[0]){
                FnameLabel.setText("✔");
                FnameLabel.setTextFill(Color.GREEN);
            }else{
                FnameLabel.setText("Incorrect Format");
                FnameLabel.setTextFill(Color.RED);
                valid = false;
            }
        }

        // Last Name
        if (HLname.getText().isEmpty())
        {
            LnameLabel.setText("Field Required");
            LnameLabel.setTextFill(Color.RED);
            valid = false;
        }
        else
        {
            // Validation check
            if(answer[1]){
                LnameLabel.setText("✔");
                LnameLabel.setTextFill(Color.GREEN);
            }else{
                LnameLabel.setText("Incorrect Format");
                LnameLabel.setTextFill(Color.RED);
                valid = false;
            }
        }

        // Date of Birth
        if (HDOB.getValue() == null)
        {
            DobLabel.setText("Field Required");
            DobLabel.setTextFill(Color.RED);
            valid = false;
        }
        else
        {
            // Validation Check
            if(answer[5]){
                DobLabel.setText("✔");
                DobLabel.setTextFill(Color.GREEN);
            }else{
                DobLabel.setText("Must be atleast 18 years old");
                DobLabel.setTextFill(Color.RED);
                valid = false;
            }
        }

        // Gender
        if (Hgender.getValue() == null)
        {
            genderLabel.setText("Field Required");
            genderLabel.setTextFill(Color.RED);
            valid = false;
        }
        else
        {
            // Validation Check
            if(answer[3]){
                genderLabel.setText("✔");
                genderLabel.setTextFill(Color.GREEN);
            }else{
                genderLabel.setText("Incorrect Option");
                genderLabel.setTextFill(Color.RED);
                valid = false;
            }
        }

        // Phone Number
        if (HPhone.getText().isEmpty())
        {
            phoneLabel.setText("Field Required");
            phoneLabel.setTextFill(Color.RED);
            valid = false;
        }
        else
        {
            // Validation Check
            if(answer[4]){
                phoneLabel.setText("✔");
                phoneLabel.setTextFill(Color.GREEN);
            }else{
                phoneLabel.setText("Invalid Phone Number");
                phoneLabel.setTextFill(Color.RED);
                valid = false;
            }
        }

        // Email
        if (HEmail.getText().isEmpty())
        {
            emailLabel.setText("Field Required");
            emailLabel.setTextFill(Color.RED);
            valid = false;
        }
        else
        {
            // Validation Check
            if(answer[7]){
                emailLabel.setText("✔");
                emailLabel.setTextFill(Color.GREEN);
            }else{
                emailLabel.setText("Incorrect Format");
                emailLabel.setTextFill(Color.RED);
                valid = false;
            }
        }

        // License
        if (HLicense.getText().isEmpty())
        {
            liscenseLabel.setText("Field Required");
            liscenseLabel.setTextFill(Color.RED);
            valid = false;
        }
        else
        {
            // Validation Check
            if(answer[8]){
                liscenseLabel.setText("✔");
                liscenseLabel.setTextFill(Color.GREEN);
            }else{
                liscenseLabel.setText("Must be 10 digits");
                liscenseLabel.setTextFill(Color.RED);
                valid = false;
            }

        }

        // Username
        if (HUsername.getText().isEmpty())
        {
            usernameLabel.setText("Field Required");
            usernameLabel.setTextFill(Color.RED);
            valid = false;
        }
        else
        {
            // Validation Check
            if(answer[2]){
                usernameLabel.setText("✔");
                usernameLabel.setTextFill(Color.GREEN);
            }else{
                usernameLabel.setText("Incorrect Format");
                usernameLabel.setTextFill(Color.RED);
                valid = false;
            }
            if(!answer[10]){
                usernameLabel.setText("Username is taken");
                usernameLabel.setTextFill(Color.RED);
                valid = false;
            }
        }

        // Password
        if (HPasscode.getText().isEmpty())
        {
            passwordLabel.setText("Field Required");
            passwordLabel.setTextFill(Color.RED);
            valid = false;
        }
        else
        {
            // Validation Check
            if(answer[6]){
                passwordLabel.setText("✔");
                passwordLabel.setTextFill(Color.GREEN);
            }else{
                passwordLabel.setText("Must be 5 digits long");
                passwordLabel.setTextFill(Color.GREEN);
                valid = false;
            }
        }

        // Choose Center
        if (chooseCenter.getValue() == null)
        {
            centerLabel1.setText("Field Required");
            centerLabel1.setTextFill(Color.RED);
            valid = false;
        }
        else
        {
            // Validation Check
            if(answer[9]){
                centerLabel1.setText("✔");
                centerLabel1.setTextFill(Color.GREEN);
            }else{
                centerLabel1.setText("Not Available");
                centerLabel1.setTextFill(Color.RED);
                valid = false;
            }
        }

        // Proceed if all fields are valid
        if (valid) {
            loadPage("HealthWorkerPage.fxml");
        }
    }

    private void loadPage(String fxmlFile)
    {
        try
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();
            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}
