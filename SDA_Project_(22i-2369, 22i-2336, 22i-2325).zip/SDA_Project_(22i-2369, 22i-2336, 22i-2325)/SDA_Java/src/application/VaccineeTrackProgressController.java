//package application;
//
//import javafx.collections.FXCollections;
//import javafx.collections.ObservableList;
//import javafx.event.ActionEvent;
//import javafx.fxml.FXML;
//import javafx.scene.chart.PieChart;
//import javafx.scene.control.Alert;
//import javafx.scene.control.Button;
//import javafx.stage.Stage;
//import java.io.IOException;
//import javafx.fxml.FXMLLoader;
//
//public class VaccineeTrackProgressController
//{
//
//    @FXML
//    private PieChart progressChart;
//
//    @FXML
//    private Button generateReportButton;
//
//    @FXML
//    private Button backButton;
//
//    @FXML
//    public void initialize() {
//        // replace with actual data input llogichere BEAAAAA
//        int dosesCompleted = 1;
//        int dosesPending = 1;
//
//
//        int totalDoses = dosesCompleted + dosesPending;
//
//
//        ObservableList<PieChart.Data> progressData = FXCollections.observableArrayList(
//        		//implement here
//            new PieChart.Data("Doses Completed (" + calculatePercentage(dosesCompleted, totalDoses) + ")", dosesCompleted),
//            new PieChart.Data("Doses Pending (" + calculatePercentage(dosesPending, totalDoses) + ")", dosesPending)
//        );
//
//        progressChart.setData(progressData);
//        progressChart.setTitle("Vaccination Progress");
//
//        // percentage labels
//        progressData.forEach(data ->
//            data.nameProperty().bind(
//                javafx.beans.binding.Bindings.concat(
//                    data.getName(),
//                    String.format(" (%.1f%%)", (data.getPieValue() / totalDoses) * 100)
//                )
//            )
//        );
//    }
//
//    @FXML
//    private void handleGenerateReport(ActionEvent event)
//    {
//        // (replace with actual report generation logic or function here wania)
//        int dosesCompleted = 1;
//        int dosesPending = 1;
//
//        String report = String.format("""
//            Vaccination Progress Report:
//            - Doses Completed: %d
//            - Doses Pending: %d
//            """, dosesCompleted, dosesPending);
//
//        //  report
//        Alert alert = new Alert(Alert.AlertType.INFORMATION);
//        alert.setTitle("Vaccination Progress Report");
//        alert.setHeaderText(null);
//        alert.setContentText(report);
//        alert.showAndWait();
//    }
//
//    @FXML
//    private void handleBackButton(ActionEvent event)
//    {
//
//        try
//        {
//            Stage stage = (Stage) backButton.getScene().getWindow();
//            stage.getScene().setRoot(FXMLLoader.load(getClass().getResource("/application/VaccineeHomePage.fxml")));
//        }
//        catch (IOException e)
//        {
//            e.printStackTrace();
//
//        }
//    }
//
//
//     // helper method to calculate percentage
//
//    private String calculatePercentage(int value, int total)
//    {
//        double percentage = ((double) value / total) * 100;
//        return String.format("%.1f%%", percentage);
//    }
//}
//CORRRECTLY WORKS FOR ONE VACCINE BUT TRIES TO MAKE ONE CHART FOR ALL VACCINE NOT PRETTY
//package application;
////
//import javafx.collections.FXCollections;
//import javafx.collections.ObservableList;
//import javafx.event.ActionEvent;
//import javafx.fxml.FXML;
//import javafx.scene.chart.PieChart;
//import javafx.scene.control.Alert;
//import javafx.scene.control.Button;
//import javafx.scene.layout.VBox;
//import javafx.stage.Stage;
//import java.io.IOException;
//
//import backend.SehatHUB;
//import javafx.fxml.FXMLLoader;
//
//public class VaccineeTrackProgressController {
//
//    @FXML
//    private PieChart progressChart;
//
//    @FXML
//    private Button generateReportButton;
//    @FXML
//    private VBox chartContainer;
//    @FXML
//    private Button backButton;
//
//    private SehatHUB sehatHubController = new SehatHUB();
//
//    @FXML
//    public void initialize() {
//        int vaccineeID = 1; // Replace with dynamic vaccinee ID from session/context
//        try {
//            ObservableList<PieChart.Data> progressData = sehatHubController.getVaccinationProgress(vaccineeID);
//            progressChart.setData(progressData);
//            progressChart.setTitle("Vaccination Progress");
//
//            int totalDoses = progressData.stream().mapToInt(data -> (int) data.getPieValue()).sum();
//            progressData.forEach(data ->
//                data.nameProperty().bind(
//                    javafx.beans.binding.Bindings.concat(
//                        data.getName(),
//                        String.format(" (%.1f%%)", (data.getPieValue() / totalDoses) * 100)
//                    )
//                )
//            );
//        } catch (Exception e) {
//            e.printStackTrace();
//            showAlert("Error", "Failed to load vaccination progress.", Alert.AlertType.ERROR);
//        }
//    }
//
//    @FXML
//    private void handleGenerateReport(ActionEvent event) {
//        int vaccineeID = 1; // Replace with dynamic vaccinee ID
//        try {
//            String report = sehatHubController.generateVaccinationReport(vaccineeID);
//            showAlert("Vaccination Progress Report", report, Alert.AlertType.INFORMATION);
//        } catch (Exception e) {
//            e.printStackTrace();
//            showAlert("Error", "Failed to generate vaccination report.", Alert.AlertType.ERROR);
//        }
//    }
//
//    @FXML
//    private void handleBackButton(ActionEvent event) {
//        try {
//            Stage stage = (Stage) backButton.getScene().getWindow();
//            stage.getScene().setRoot(FXMLLoader.load(getClass().getResource("/application/VaccineeHomePage.fxml")));
//        } catch (IOException e) {
//            e.printStackTrace();
//            showAlert("Error", "Failed to go back to the previous page.", Alert.AlertType.ERROR);
//        }
//    }
//
//    private void showAlert(String title, String content, Alert.AlertType alertType) {
//        Alert alert = new Alert(alertType);
//        alert.setTitle(title);
//        alert.setHeaderText(null);
//        alert.setContentText(content);
//        alert.showAndWait();
//    }
//}
//


package application;

import backend.SehatHUB;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;

import java.io.IOException;

public class VaccineeTrackProgressController {

    @FXML
    private VBox chartContainer; // VBox to hold multiple PieCharts dynamically.
    @FXML
    private Button backButton;
    @FXML
    private Button generateReportButton;

    private SehatHUB sehatHubController = new SehatHUB();

    public void setSehatHUB(SehatHUB sehathub){
        this.sehatHubController = sehathub;

        // Replace with dynamic vaccinee ID from session/context
        try {
            // Fetch data for all vaccines for this vaccinee.
            ObservableList<VaccineProgress> progressDataList = sehatHubController.getVaccinationProgress(sehatHubController.getVaccinee().getUserID());

            // Dynamically create a PieChart for each vaccine.
            for (VaccineProgress progressData : progressDataList) {
                addPieChartForVaccine(progressData);
            }
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load vaccination progress.", Alert.AlertType.ERROR);
        }
    }

    @FXML
    public void initialize() {
        sehatHubController = new SehatHUB();
    }

    /**
     * Creates and adds a PieChart to the VBox for a given vaccine's progress.
     *
     * @param progressData VaccineProgress object containing the vaccine's name and doses data.
     */
//    private void addPieChartForVaccine(VaccineProgress progressData) {
//        // Create PieChart data for completed and pending doses.
//        ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList(
//            new PieChart.Data("Completed", progressData.getDosesCompleted()),
//            new PieChart.Data("Pending", progressData.getDosesPending())
//        );
//
//        // Create a PieChart and set its data.
//        PieChart pieChart = new PieChart(pieChartData);
//        pieChart.setTitle(progressData.getVaccineName());
//        pieChart.setLegendVisible(true);
//        pieChart.setLabelsVisible(true);
//
//        // Add percentage labels to the chart.
//        int totalDoses = progressData.getDosesCompleted() + progressData.getDosesPending();
//        pieChartData.forEach(data ->
//            data.nameProperty().bind(
//                javafx.beans.binding.Bindings.concat(
//                    data.getName(),
//                    String.format(" (%.1f%%)", (data.getPieValue() / totalDoses) * 100)
//                )
//            )
//        );
//
//        // Add the PieChart to the VBox.
//        chartContainer.getChildren().add(pieChart);
//    }


    @FXML
    private void addPieChartForVaccine(VaccineProgress progressData) {
        // Create PieChart data for completed and pending doses
        ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList(
                new PieChart.Data("Completed: " + progressData.getDosesCompleted(), progressData.getDosesCompleted()),
                new PieChart.Data("Pending: " + progressData.getDosesPending(), progressData.getDosesPending())
        );

        // Create PieChart
        PieChart pieChart = new PieChart(pieChartData);
        pieChart.setTitle(progressData.getVaccineName()); // Set vaccine name as title
        pieChart.setLegendVisible(true);
        pieChart.setLabelsVisible(true);

        // Calculate total doses
        int totalDoses = progressData.getDosesCompleted() + progressData.getDosesPending();

        // Add percentage labels to the chart slices
        pieChartData.forEach(data -> {
            data.nameProperty().bind(
                    javafx.beans.binding.Bindings.concat(
                            data.getName(), // Existing label
                            String.format(" (%.1f%%)", (data.getPieValue() / totalDoses) * 100) // Add percentage
                    )
            );
        });

        // Add the PieChart to the VBox
        chartContainer.getChildren().add(pieChart);
    }

    @FXML
    private void handleGenerateReport(ActionEvent event) {
        try {
            ObservableList<VaccineProgress> vaccinationProgressList = sehatHubController.getVaccinationProgress(sehatHubController.getVaccinee().getUserID());

            StringBuilder reportBuilder = new StringBuilder("Vaccination Progress Report:\n");

            // Loop through all vaccine progress entries
            for (VaccineProgress progress : vaccinationProgressList) {
                reportBuilder.append(String.format(
                        "- Vaccine Name: %s\n  Doses Completed: %d\n  Doses Pending: %d\n\n",
                        progress.getVaccineName(),
                        progress.getDosesCompleted(),
                        progress.getDosesPending()
                ));
            }

            // Show the report in an alert dialog
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Vaccination Progress Report");
            alert.setHeaderText(null);
            alert.setContentText(reportBuilder.toString());
            alert.showAndWait();
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error", "Failed to generate vaccination report.", Alert.AlertType.ERROR);
        }
    }

    private void showAlert(String title, String content, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

//    @FXML
//    private void handleGenerateReport(ActionEvent event) {
//        int vaccineeID = 1; // Replace with dynamic vaccinee ID from session/context
//        try {
//            // Fetch detailed vaccine progress data from the system controller
//            ObservableList<VaccineProgress> vaccinationProgressList = sehatHubController.getVaccinationProgress(vaccineeID);
//
//            // Build the report string using fetched data
//            StringBuilder reportBuilder = new StringBuilder("Vaccination Progress Report:\n\n");
//            vaccinationProgressList.forEach(vaccineProgress -> {
//                reportBuilder.append(String.format("%s:\n", vaccineProgress.getVaccineName()));
//                reportBuilder.append(String.format(" - Doses Completed: %d\n", vaccineProgress.getDosesCompleted()));
//                reportBuilder.append(String.format(" - Doses Pending: %d\n", vaccineProgress.getDosesPending()));
//                reportBuilder.append("\n");  // Add spacing between entries
//            });
//
//            // Show the generated report in an alert dialog
//            showAlert("Vaccination Progress Report", reportBuilder.toString(), Alert.AlertType.INFORMATION);
//        } catch (Exception e) {
//            e.printStackTrace();
//            showAlert("Error", "Failed to generate vaccination report.", Alert.AlertType.ERROR);
//        }
//    }

//    private void showAlert(String title, String content, Alert.AlertType alertType) {
//        Alert alert = new Alert(alertType);
//        alert.setTitle(title);
//        alert.setHeaderText(null);
//        alert.setContentText(content);
//        alert.showAndWait();
//    }

    @FXML
    private void handleBackButton(ActionEvent event) {
        try {
            Stage stage = (Stage) backButton.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/VaccineeHomePage.fxml"));
            Parent root = loader.load();

            Object controller = loader.getController();
            if(controller instanceof VaccineeHomePageController){
                ((VaccineeHomePageController) controller).setSehatHUB(this.sehatHubController);
            }

            stage.getScene().setRoot(root);

        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to go back to the previous page.", Alert.AlertType.ERROR);
        }
    }

//
//    @FXML
//    private void handleGenerateReport(ActionEvent event) {
//        int vaccineeID = 1; // Replace with dynamic vaccinee ID
//        try {
//            String report = sehatHubController.generateVaccinationReport(vaccineeID);
//            showAlert("Vaccination Progress Report", report, Alert.AlertType.INFORMATION);
//        } catch (Exception e) {
//            e.printStackTrace();
//            showAlert("Error", "Failed to generate vaccination report.", Alert.AlertType.ERROR);
//        }
//    }
//    private void showAlert(String title, String content, Alert.AlertType alertType) {
//        Alert alert = new Alert(alertType);
//        alert.setTitle(title);
//        alert.setHeaderText(null);
//        alert.setContentText(content);
//        alert.showAndWait();
//    }
}
