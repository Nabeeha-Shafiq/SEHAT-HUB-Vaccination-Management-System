package application;

import backend.SehatHUB;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
//import javafx.scene.control.Text;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class VaccineeUserManualController
{
    private SehatHUB sehatHUB;

    @FXML
    private ComboBox<String> languageComboBox;

    @FXML
    private Text WelcomeInstruction;

    @FXML
    private Text userInstruction;

    @FXML
    private Text ManageInstruction;

    @FXML
    private Text loginheading;

    @FXML
    private Text manageaccheading;

    @FXML
    private Text BookApptHeading;

    @FXML
    private Text BookApptInstruction;

    @FXML
    private Text CancelApptHeading;

    @FXML
    private Text CancelApptInstructions;

    @FXML
    private Text UserSUpportHeading;

    @FXML
    private Text UserSupportInstruction;

    public void setSehatHUB(SehatHUB sehathub){
        this.sehatHUB = sehathub;
    }

    @FXML
    public void initialize()
    {
        this.sehatHUB = new SehatHUB();
        languageComboBox.getItems().addAll("English", "اردو", "العربية", "Français", "日本語");
        languageComboBox.setOnAction(this::handleLanguageChange);
    }

    private void handleLanguageChange(ActionEvent event)
    {
        String selectedLanguage = languageComboBox.getValue();

        switch (selectedLanguage)
        {
            case "English":
                setTextToEnglish();
                break;
            case "اردو":
                setTextToUrdu();
                break;
            case "العربية":
                setTextToArabic();
                break;
            case "Français":
                setTextToFrench();
                break;
            case "日本語":
                setTextToJapanese();
                break;
        }
    }

    private void setTextToEnglish()
    {
        WelcomeInstruction.setText("Welcome to the Vaccinee Portal! Here’s how to use the system effectively:");
        userInstruction.setText("Use your registered credentials to log in and access your personalized dashboard.");
        ManageInstruction.setText("Update account / deactivate your account from the 'Manage Account' section --> Deactivate / Customer Support.");
        loginheading.setText("#Login:");
        manageaccheading.setText("#Manage Account:");
        BookApptHeading.setText("#Book Appointment:");
        BookApptInstruction.setText("Select Vaccine type --> Center --> Available Appointments --> Date/Time.");
        CancelApptHeading.setText("#Cancel Appointment:");
        CancelApptInstructions.setText("Select Appointment --> Reason --> Reschedule --> Cancel.");
        UserSUpportHeading.setText("#User Support:");
        UserSupportInstruction.setText("For any issues, contact support via the 'Help' section.");
    }

    private void setTextToUrdu()
    {
        WelcomeInstruction.setText("ویکسینی پورٹل میں خوش آمدید! نظام کو مؤثر طریقے سے استعمال کرنے کا طریقہ یہ ہے:");
        userInstruction.setText("اپنی رجسٹرڈ تفصیلات استعمال کریں اور اپنا ذاتی ڈیش بورڈ تک رسائی حاصل کریں۔");
        ManageInstruction.setText("اکاؤنٹ اپ ڈیٹ کریں / اپنے اکاؤنٹ کو غیر فعال کریں 'مینج اکاؤنٹ' سیکشن سے --> غیر فعال کریں / کسٹمر سپورٹ۔");
        loginheading.setText("#لاگ ان:");
        manageaccheading.setText("#اکاؤنٹ مینیج کریں:");
        BookApptHeading.setText("#ملاقات کی بکنگ:");
        BookApptInstruction.setText("ویکسین کی قسم منتخب کریں --> سینٹر --> دستیاب ملاقاتیں --> تاریخ / وقت۔");
        CancelApptHeading.setText("#ملاقات منسوخ کریں:");
        CancelApptInstructions.setText("ملاقات منتخب کریں --> وجہ --> دوبارہ شیڈول کریں --> منسوخ کریں۔");
        UserSUpportHeading.setText("#صارف کی مدد:");
        UserSupportInstruction.setText("کسی بھی مسئلے کے لیے، 'مدد' سیکشن کے ذریعے سپورٹ سے رابطہ کریں۔");
    }

    private void setTextToArabic()
    {
        WelcomeInstruction.setText("مرحبًا بكم في بوابة التطعيم! إليك كيفية استخدام النظام بشكل فعال:");
        userInstruction.setText("استخدم بيانات اعتمادك المسجلة لتسجيل الدخول والوصول إلى لوحة القيادة المخصصة الخاصة بك.");
        ManageInstruction.setText("قم بتحديث الحساب / تعطيل حسابك من قسم 'إدارة الحساب' --> تعطيل / دعم العملاء.");
        loginheading.setText("#تسجيل الدخول:");
        manageaccheading.setText("#إدارة الحساب:");
        BookApptHeading.setText("#حجز موعد:");
        BookApptInstruction.setText("حدد نوع اللقاح --> المركز --> المواعيد المتاحة --> التاريخ / الوقت.");
        CancelApptHeading.setText("#إلغاء الموعد:");
        CancelApptInstructions.setText("حدد الموعد --> السبب --> إعادة الجدولة --> الإلغاء.");
        UserSUpportHeading.setText("#دعم المستخدم:");
        UserSupportInstruction.setText("لأي مشاكل، اتصل بالدعم عبر قسم 'المساعدة'.");
    }
    
    private void setTextToFrench()
    {
        WelcomeInstruction.setText("Bienvenue sur le portail Vaccinee ! Voici comment utiliser le système efficacement :");
        userInstruction.setText("Utilisez vos identifiants enregistrés pour vous connecter et accéder à votre tableau de bord personnalisé.");
        ManageInstruction.setText("Mettez à jour votre compte / désactivez votre compte depuis la section 'Gérer le compte' --> Désactiver / Support client.");
        loginheading.setText("#Connexion :");
        manageaccheading.setText("#Gérer le compte :");
        BookApptHeading.setText("#Prendre un rendez-vous :");
        BookApptInstruction.setText("Sélectionnez le type de vaccin --> Centre --> Rendez-vous disponibles --> Date/Heure.");
        CancelApptHeading.setText("#Annuler un rendez-vous :");
        CancelApptInstructions.setText("Sélectionnez le rendez-vous --> Raison --> Replanifier --> Annuler.");
        UserSUpportHeading.setText("#Assistance utilisateur :");
        UserSupportInstruction.setText("Pour tout problème, contactez le support via la section 'Aide'.");
    }

    private void setTextToJapanese()
    {
        WelcomeInstruction.setText("ワクチンポータルへようこそ！システムを効果的に使用する方法は以下の通りです：");
        userInstruction.setText("登録された資格情報を使用してログインし、個別のダッシュボードにアクセスします。");
        ManageInstruction.setText("アカウントを更新/非アクティブ化するには、「アカウント管理」セクションから --> 非アクティブ化/カスタマーサポート。");
        loginheading.setText("#ログイン：");
        manageaccheading.setText("#アカウント管理：");
        BookApptHeading.setText("#予約を取る：");
        BookApptInstruction.setText("ワクチンの種類を選択 --> センター --> 利用可能な予約 --> 日時。");
        CancelApptHeading.setText("#予約をキャンセルする：");
        CancelApptInstructions.setText("予約を選択 --> 理由 --> 再スケジュール --> キャンセル。");
        UserSUpportHeading.setText("#ユーザーサポート：");
        UserSupportInstruction.setText("問題がある場合は、「ヘルプ」セクションからサポートに連絡してください。");
    }

    @FXML
    private void handleBackButton(ActionEvent event) 
    {
        try 
        {
            javafx.fxml.FXMLLoader loader = new javafx.fxml.FXMLLoader(getClass().getResource("VaccineeHomepage.fxml"));
            javafx.scene.Parent root = loader.load();

            Object controller = loader.getController();
            if(controller instanceof VaccineeHomePageController){
                ((VaccineeHomePageController) controller).setSehatHUB(this.sehatHUB);
            }

            Stage stage = (Stage) languageComboBox.getScene().getWindow();
            stage.getScene().setRoot(root);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}
