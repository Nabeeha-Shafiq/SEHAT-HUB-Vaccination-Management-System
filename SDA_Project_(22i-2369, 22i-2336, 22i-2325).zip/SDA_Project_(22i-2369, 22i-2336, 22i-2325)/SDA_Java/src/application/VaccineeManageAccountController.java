package application;

import backend.SehatHUB;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Button;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

public class VaccineeManageAccountController
{
    // sehatHUB controller referenced
    private SehatHUB sehatHUB = new SehatHUB();

    @FXML
    private Button backButton;

    @FXML
    private Hyperlink deactivateLink;

    @FXML
    private Hyperlink emailLink;

    @FXML
    private Hyperlink updatelink;

    public void setSehatHUB(SehatHUB sehathub){
        this.sehatHUB = sehathub;
    }
  
    @FXML
    public void handleBackButton(ActionEvent event) 
    {
        try
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/VaccineeHomePage.fxml"));
            Parent root = loader.load();

            Object controller = loader.getController();
            if(controller instanceof VaccineeHomePageController){
                ((VaccineeHomePageController) controller).setSehatHUB(this.sehatHUB);
            }
            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.setScene(new Scene(root));

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //  to compose email
    @FXML
    public void handleEmailLink(ActionEvent event)
    {
        try 
        {
            Desktop desktop = Desktop.getDesktop();
            URI mailto = new URI("mailto:sehathub2024@gmail.com");
            desktop.mail(mailto);
        } 
        catch (IOException | URISyntaxException e)
        {
            e.printStackTrace();
        }
    }

    //  loading bar then navigate to VaccinePage.fxml
    
    @FXML
    public void handleUpdateLink(ActionEvent event)
    {
        Stage loadingStage = new Stage();
        ProgressIndicator progressIndicator = new ProgressIndicator();
        Scene loadingScene = new Scene(progressIndicator, 100, 100);
        loadingStage.setScene(loadingScene);
        loadingStage.setTitle("Loading...");
        loadingStage.show();

        new Thread(() ->
        {
            try 
            {
                Thread.sleep(2000); 
                Platform.runLater(() -> 
                {
                    loadingStage.close(); 
                    try 
                    {
                        // HERE IT GOES TO VACCINEE UPDATE SIGNUP PAGE , CALL THE FUNCTION ACCORDINGLY
                        FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/VaccineeUpdatePage.fxml"));
                        Parent root = loader.load();

                        Object controller = loader.getController();
                        if(controller instanceof VaccineeUpdateController){
                            ((VaccineeUpdateController) controller).setSehatHUB(this.sehatHUB);
                        }

                        Stage stage = (Stage) updatelink.getScene().getWindow();
                        stage.setScene(new Scene(root));
                    } 
                    catch (IOException e)
                    {
                        e.printStackTrace();
                    }
                });
            }
            catch (InterruptedException e)
            {
                e.printStackTrace();
            }
        }).start();
    }

    //  vaccineconfirmdelete.fxml
    @FXML
    public void handleDeactivateLink(ActionEvent event)
    {
        try
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/VaccineeConfirmDeactivate.fxml"));
            Parent root = loader.load();

            Object controller = loader.getController();
            if(controller instanceof VaccineeConfirmDeactivateController){
                ((VaccineeConfirmDeactivateController) controller).setSehatHUB(this.sehatHUB);
            }

            Stage stage = (Stage) deactivateLink.getScene().getWindow();
            stage.setScene(new Scene(root));
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        }
    }
}
