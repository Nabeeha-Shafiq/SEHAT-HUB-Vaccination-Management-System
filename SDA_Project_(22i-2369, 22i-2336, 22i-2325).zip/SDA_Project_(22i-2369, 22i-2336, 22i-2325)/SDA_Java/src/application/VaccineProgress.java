package application;

public class VaccineProgress{
    private String vaccineName;
    private int dosesCompleted;
    private int dosesPending;

    public VaccineProgress(String vaccineName, int dosesCompleted, int dosesPending) {
        this.vaccineName = vaccineName;
        this.dosesCompleted = dosesCompleted;
        this.dosesPending = dosesPending;
    }

    public String getVaccineName() {
        return vaccineName;
    }

    public int getDosesCompleted() {
        return dosesCompleted;
    }

    public int getDosesPending() {
        return dosesPending;
    }
}
