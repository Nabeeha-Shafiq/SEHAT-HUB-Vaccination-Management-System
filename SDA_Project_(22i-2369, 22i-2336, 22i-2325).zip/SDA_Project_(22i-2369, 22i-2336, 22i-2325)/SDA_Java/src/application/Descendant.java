package application;

public class Descendant {
    private String username;
    private String fullname;
    private int age; // Added appointment status field

    // Constructor
    public Descendant(){}

    public Descendant(String username, String fullname, int age) {
        this.username = username;
        this.fullname = fullname;
        this.age = age;
    }

    // Getters and Setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getAge() {
        return age;
    }

    public String getFullname() {
        return fullname;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }
}

