//package application;
//
//import javafx.collections.FXCollections;
//import javafx.collections.ObservableList;
//import javafx.fxml.FXML;
//import javafx.fxml.FXMLLoader;
//import javafx.scene.Parent;
//import javafx.scene.Scene;
//import javafx.scene.control.*;
//import javafx.stage.FileChooser;
//import javafx.stage.Stage;
//
//import java.io.FileWriter;
//import java.io.IOException;
//
//public class MinistryTrackProgressController
//{
//
//    @FXML
//    private ComboBox<String> centerComboBox;
//
//    @FXML
//    private ComboBox<String> AgeComboBox;
//
//    @FXML
//    private TableView<ProgressData> progressTable;
//
//    @FXML
//    private TableColumn<ProgressData, String> centerNameColumn;
//
//    @FXML
//    private TableColumn<ProgressData, String> healthWorkerColumn;
//
//    @FXML
//    private TableColumn<ProgressData, String> vaccineeNameColumn;
//
//    @FXML
//    private TableColumn<ProgressData, String> vaccineeIDColumn;
//
//    @FXML
//    private TableColumn<ProgressData, String> doseStatusColumn;
//
//    @FXML
//    private TableColumn<ProgressData, String> dateTimeColumn;
//
//    @FXML
//    private Button generateReportButton;
//
//    @FXML
//    private Button backButton;
//
//    private ObservableList<ProgressData> allData;
//    private ObservableList<ProgressData> filteredData;
//
//    @FXML
//    public void initialize()
//    {
//
//        //comboboxes
//        centerComboBox.setItems(FXCollections.observableArrayList("Center A", "Center B", "Center C"));
//        AgeComboBox.setItems(FXCollections.observableArrayList("Under 1-10", "10-15", "15-18", "18+"));
//
//        //  table columns
//        centerNameColumn.setCellValueFactory(data -> data.getValue().centerNameProperty());
//        healthWorkerColumn.setCellValueFactory(data -> data.getValue().healthWorkerProperty());
//        vaccineeNameColumn.setCellValueFactory(data -> data.getValue().vaccineeNameProperty());
//        vaccineeIDColumn.setCellValueFactory(data -> data.getValue().vaccineeIDProperty());
//        doseStatusColumn.setCellValueFactory(data -> data.getValue().doseStatusProperty());
//        dateTimeColumn.setCellValueFactory(data -> data.getValue().dateTimeProperty());
//
//
//        allData = FXCollections.observableArrayList(
//                new ProgressData("Center A", "Dr. Anaya", "Nabs", "001", "2/2", "2024-11-21 10:00", 8),
//                new ProgressData("Center A", "Dr. Anaya", "Rose", "002", "1/2", "2024-11-20 14:00", 12),
//                new ProgressData("Center B", "Dr. John", "Mike", "003", "2/2", "2024-11-19 10:00", 17),
//                new ProgressData("Center C", "Dr. Sarah", "Emma", "004", "1/2", "2024-11-18 14:00", 21)
//        );
//
//
//        progressTable.setItems(allData);
//
//
//        centerComboBox.setOnAction(event -> filterData());
//
//
//        AgeComboBox.setOnAction(event -> filterData());
//    }
//
//    private void filterData()
//    {
//        String selectedCenter = centerComboBox.getValue();
//        String selectedAgeGroup = AgeComboBox.getValue();
//
//        filteredData = FXCollections.observableArrayList(allData);
//
//        // filter by center
//        if (selectedCenter != null)
//        {
//            filteredData.removeIf(data -> !data.getCenterName().equals(selectedCenter));
//        }
//
//        // filter by age group
//        if (selectedAgeGroup != null)
//        {
//            switch (selectedAgeGroup)
//            {
//                case "Under 1-10":
//                    filteredData.removeIf(data -> data.getAge() > 10);
//                    break;
//                case "10-15":
//                    filteredData.removeIf(data -> data.getAge() < 10 || data.getAge() > 15);
//                    break;
//                case "15-18":
//                    filteredData.removeIf(data -> data.getAge() < 15 || data.getAge() > 18);
//                    break;
//                case "18+":
//                    filteredData.removeIf(data -> data.getAge() < 18);
//                    break;
//            }
//        }
//
//
//        progressTable.setItems(filteredData);
//    }
//
//    @FXML
//    public void handleGenerateReport()
//    {
//        FileChooser fileChooser = new FileChooser();
//        fileChooser.setTitle("Save Progress Report");
//        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV Files", "*.csv"));
//
//        Stage stage = (Stage) generateReportButton.getScene().getWindow();
//        var file = fileChooser.showSaveDialog(stage);
//
//        if (file != null)
//        {
//            System.out.println("File selected: " + file.getAbsolutePath());
//            try (FileWriter writer = new FileWriter(file))
//            {
//                writer.write("Center Name,Health Worker,Vaccinee Name,Vaccinee ID,Dose Status,Date & Time,Age\n");
//
//                if (filteredData == null || filteredData.isEmpty())
//                {
//                    showAlert("No Data", "There is no data to generate the report.");
//                    return;
//                }
//
//                for (ProgressData data : filteredData)
//                {
//                    writer.write(data.toCSV() + "\n");
//                }
//
//                showAlert("Report Generated", "Report has been successfully generated.");
//            }
//            catch (IOException e)
//            {
//                showAlert("Error", "Failed to generate the report.");
//                e.printStackTrace();
//            }
//        }
//        else
//        {
//            System.out.println("No file selected.");
//        }
//    }
//
//    @FXML
//    public void handleBackButton()
//    {
//        try
//        {
//            Parent homePage = FXMLLoader.load(getClass().getResource("MinistryHomePage.fxml"));
//            Stage stage = (Stage) backButton.getScene().getWindow();
//            stage.setScene(new Scene(homePage));
//            stage.setTitle("Ministry Home Page");
//            stage.show();
//        }
//        catch (IOException e)
//        {
//            e.printStackTrace();
//            showAlert("Error", "Failed to load Ministry Home Page.");
//        }
//    }
//
//    private void showAlert(String title, String message)
//    {
//        Alert alert = new Alert(Alert.AlertType.INFORMATION);
//        alert.setTitle(title);
//        alert.setContentText(message);
//        alert.showAndWait();
//    }
//}
package application;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import backend.SehatHUB;

import java.io.FileWriter;
import java.io.IOException;

public class MinistryTrackProgressController {

    @FXML
    private ComboBox<String> centerComboBox;

    @FXML
    private ComboBox<String> AgeComboBox;

    @FXML
    private TableView<ReportData> progressTable;

    @FXML
    private TableColumn<ReportData, String> centerNameColumn;

    @FXML
    private TableColumn<ReportData, String> healthWorkerColumn;

    @FXML
    private TableColumn<ReportData, String> vaccineeNameColumn;

    @FXML
    private TableColumn<ReportData, String> vaccineeIDColumn;

    @FXML
    private TableColumn<ReportData, String> vaccineNameColumn;

    @FXML
    private TableColumn<ReportData, String> dosesCompletedColumn;

    @FXML
    private Button generateReportButton;

    @FXML
    private Button backButton;

    private SehatHUB sehatHub;
    private ObservableList<ReportData> allData;

    @FXML
    public void initialize() {
        sehatHub = new SehatHUB();

        // Fetching and setting up data for the table
        allData = sehatHub.getHealthWorkerVaccinationData();
        progressTable.setItems(allData);

        // Initializing combobox selections
        //centerComboBox.setItems(FXCollections.observableArrayList("Center A", "Center B", "Center C"));
        //AgeComboBox.setItems(FXCollections.observableArrayList("BCG", "Hepatitis B", "Polio Vaccine", "Measles"));
        centerComboBox.setItems(FXCollections.observableArrayList(sehatHub.getCenterNames()));
        AgeComboBox.setItems(FXCollections.observableArrayList(sehatHub.getVaccineNames()));
        // Setup table columns bindings
        centerNameColumn.setCellValueFactory(cellData -> cellData.getValue().centerNameProperty());
        healthWorkerColumn.setCellValueFactory(cellData -> cellData.getValue().healthWorkerNameProperty());
        vaccineeNameColumn.setCellValueFactory(cellData -> cellData.getValue().vaccineeNameProperty());
        vaccineeIDColumn.setCellValueFactory(cellData -> cellData.getValue().vaccineeIDProperty());
        vaccineNameColumn.setCellValueFactory(cellData -> cellData.getValue().vaccineNameProperty());
        dosesCompletedColumn.setCellValueFactory(cellData -> cellData.getValue().dosesCompletedProperty().asString());

        // Set filter handlers
        centerComboBox.setOnAction(event -> filterData());
        AgeComboBox.setOnAction(event -> filterData());
    }

    private void filterData() {
        String selectedCenter = centerComboBox.getValue();
        ObservableList<ReportData> filteredData = allData.filtered(data ->
                (selectedCenter == null || data.centerNameProperty().getValue().equals(selectedCenter)) &&
                        (AgeComboBox.getValue() == null || data.vaccineNameProperty().getValue().equals(AgeComboBox.getValue())) // This is just an example
        );
        progressTable.setItems(filteredData);
    }

    @FXML
    public void handleGenerateReport() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save Progress Report");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV Files", "*.csv"));
        Stage stage = (Stage) generateReportButton.getScene().getWindow();
        var file = fileChooser.showSaveDialog(stage);

        if (file != null) {
            try (FileWriter writer = new FileWriter(file)) {
                writer.write("Center Name,Health Worker,Vaccinee Name,Vaccinee ID,Vaccine Name,Doses Completed\n");

                for (ReportData data : progressTable.getItems()) {
                    String line = String.format("%s,%s,%s,%s,%s,%d\n",
                            data.centerNameProperty().getValue(),
                            data.healthWorkerNameProperty().getValue(),
                            data.vaccineeNameProperty().getValue(),
                            data.vaccineeIDProperty().getValue(),
                            data.vaccineNameProperty().getValue(),
                            data.dosesCompletedProperty().getValue());
                    writer.write(line);
                }

                showAlert("Report Generated", "Report has been successfully generated.");
            } catch (IOException e) {
                showAlert("Error", "Failed to generate the report.");
                e.printStackTrace();
            }
        } else {
            System.out.println("No file selected.");
        }

    }

    @FXML
    public void handleBackButton() {
        try {
            Parent homePage = FXMLLoader.load(getClass().getResource("MinistryHomePage.fxml"));
            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.setScene(new Scene(homePage));
            stage.setTitle("Ministry Home Page");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load Ministry Home Page.");
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

