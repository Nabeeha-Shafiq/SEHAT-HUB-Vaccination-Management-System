package application;

public class VaccineeData 
{
    private int appointmentID;
    private String vaccineeName;
    private int vaccineeId;
    private String appointmentTime;
    private String status;

    public VaccineeData(){}

    public VaccineeData(int appointmentID, String vaccineeName, int vaccineeId, String appointmentTime, String status)
    {
        this.appointmentID = appointmentID;
        this.vaccineeName = vaccineeName;
        this.vaccineeId = vaccineeId;
        this.appointmentTime = appointmentTime;
        this.status = status;
    }

    public int getAppointmentID() {
        return appointmentID;
    }

    public void setAppointmentID(int appointmentID) {
        this.appointmentID = appointmentID;
    }


    public String getVaccineeName()
    {
        return vaccineeName;
    }

    public void setVaccineeName(String vaccineeName)
    {
        this.vaccineeName = vaccineeName;
    }

    public int getVaccineeId()
    {
        return vaccineeId;
        
    }

    public void setVaccineeId(int vaccineeId) 
    {
        this.vaccineeId = vaccineeId;
    }

    public String getAppointmentTime() {
        return appointmentTime;
    }

    public void setAppointmentTime(String appointmentTime) {
        this.appointmentTime = appointmentTime;
    }

    public String getStatus()
    {
        return status;
    }

    public void setStatus(String status) 
    {
        this.status = status;
    }
}
