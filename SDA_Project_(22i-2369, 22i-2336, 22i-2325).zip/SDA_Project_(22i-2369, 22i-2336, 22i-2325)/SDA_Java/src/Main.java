import java.time.LocalDate;

import backend.HealthWorker;
import backend.SehatHUB;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import static javafx.application.Application.launch;

public class Main extends Application{
    public static void main(String[] args) {

        launch(args);
        SehatHUB obj = new SehatHUB();
        //Vaccinee vaccinee = new Vaccinee("wania123","wan1234","wania", "naeem", LocalDate.parse("2003-05-02"),"Female","1234567890","wania@gmail.com");
        //HealthWorker healthworker = new HealthWorker("wania123","wan1234","wania", "naeem", LocalDate.parse("2003-05-02"),"Female","1234567890","12345","wania@gmail.com",1);

        //System.out.println(LocalDate.now());

        //System.out.println(obj.)
        //System.out.println(obj.SignUp_Vaccinee(vaccinee));
        //System.out.println(obj.Login_Vaccinee("wania1","wan12"));

    }

    @Override
    public void start(Stage primaryStage)
    {
        try
        {
            Parent root = FXMLLoader.load(getClass().getResource("/application/mainpage.fxml"));
            primaryStage.setTitle("SEHAT");
            primaryStage.setScene(new Scene(root));
            primaryStage.show();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}